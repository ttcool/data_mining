# -*- coding: UTF-8 -*-

import copy
import urllib
import base64
from decimal import Decimal
import datetime

import MySQLdb
from MySQLdb.cursors import DictCursor
from pymongo import MongoClient
from bson.errors import InvalidStringData

from settings import database_list, con_bdp, MONGODB_CONFIG

bdp_tables = []
trans_columns_map = {}
trans_table = []


def get_mongodb_db():
    MONGODB_CONFIG["password"] = urllib.quote_plus(MONGODB_CONFIG["password"])
    if MONGODB_CONFIG["replicaSet"]:
        client = MongoClient('mongodb://%(user)s:%(password)s@%(host)s/%(db)s' % MONGODB_CONFIG,
                             replicaSet=MONGODB_CONFIG['replicaSet'])
    else:
        client = MongoClient('mongodb://%(user)s:%(password)s@%(host)s:%(port)s/%(db)s' % MONGODB_CONFIG)

    return getattr(client, MONGODB_CONFIG["db"])


def get_mysql_conn():
    connection = MySQLdb.connect(host=con_bdp[0], user=con_bdp[1], passwd=con_bdp[2], db=con_bdp[3], port=con_bdp[4],
                                 cursorclass=DictCursor, charset="utf8")

    return connection


def get_collection_name(database, table):
    return "stg" + "__" + database + "__" + table


def get_transform_info(cur):
    """MySQL column type transform to mongodb, ex: blob, decimal"""
    trans_sql = 'SELECT CONCAT(table_schema, "__", table_name) AS table_name, ' \
                'CONCAT(table_schema, "__", table_name, "__", column_name) AS column_name, column_type' \
                ' FROM bdp_metadata.bdp_columns' \
                ' WHERE column_type LIKE "%blob" OR column_type LIKE "decimal%" OR column_type="date"'
    cur.execute(trans_sql)
    trans_data = cur.fetchall()
    for td in trans_data:
        trans_columns_map[td["column_name"]] = td["column_type"]
        trans_table.append(td["table_name"])

    return trans_table, trans_columns_map


def transform_column(data, full_table_name):
    """dict of database record"""
    for col in data.keys():
        full_column = full_table_name + "__" + col
        if full_column in trans_columns_map.keys():
            if trans_columns_map[full_column].startswith("decimal"):
                if isinstance(data[col], Decimal):
                    data[col] = float(data[col])
            elif trans_columns_map[full_column].endswith("blob"):
                if data[col]:
                    data[col] = base64.b64encode(data[col])
            elif isinstance(data[col], datetime.date):
                data[col] = str(data[col])

    return data


def transform_data(data, full_table_name):
    """data need transform
    :param data: list or dict data for insert or update to mongodb
    :param full_table_name: database__table
    """
    if full_table_name in trans_table:
        if isinstance(data, (list, tuple)):
            # data = map(transform_column, data)
            data = [transform_column(d, full_table_name) for d in data]
        elif isinstance(data, dict):
            data = transform_column(data, full_table_name)

    return data


def insert_business_data(cur, db, sql, bt_coll_name, full_table_name):
    cur.execute(sql)
    bt_data = cur.fetchall()
    bt_coll = getattr(db, bt_coll_name)
    try:
        data = transform_data(copy.deepcopy(bt_data), full_table_name)
        bt_coll.insert_many(list(data))
    except InvalidStringData, e:
        print "ERROR Insert collection:%s, Error:%s" % (bt_coll_name, e.args)
    except Exception, e:
        print "ERROR Insert collection:%s, Error:%s" % (bt_coll_name, e.args)


def init_business_data(db, cur):
    for bt in bdp_tables:
        bt_coll_name = get_collection_name(bt[0], bt[1])
        full_table_name = "%s__%s" % (bt[0], bt[1])
        print "Begin insert collection:", bt_coll_name
        data_count_sql = "SELECT COUNT(*) AS cnt FROM %s.%s" % (bt[0], bt[1])
        cur.execute(data_count_sql)
        data_count = cur.fetchone().get("cnt", 0)
        if data_count == 0:
            print "Ignore empty collection:", bt_coll_name
            continue
        elif data_count < 10000:
            sql = "SELECT * FROM %s.%s" % (bt[0], bt[1])
            insert_business_data(cur, db, sql, bt_coll_name, full_table_name)
        else:
            for i in range(0, data_count, 10000):
                sql = "SELECT * FROM %s.%s LIMIT %s, 10000" % (bt[0], bt[1], i)
                insert_business_data(cur, db, sql, bt_coll_name, full_table_name)

        print "Done insert collection:", bt_coll_name


def init_metadata(db, cur):
    # init bdp_schema collections
    bdp_schema_coll = getattr(db, 'bdp_schema')
    bdp_schema_coll.insert_one(dict(
        schema_name='bdp_data',
        character_set='utf8',
        collation_name='',
        schema_status=0,
        rename_from='',
        comment='',
        created_time=0,
        updated_time=0
    ))
    print "Done insert collection:", "bdp_schema"

    # init bdp_tables collections
    bdp_tables_coll = getattr(db, 'bdp_tables')
    bdp_tables_sql = 'SELECT table_schema, table_name, table_status, rename_from, comment, created_time, updated_time' \
                     ' FROM bdp_metadata.bdp_tables'
    cur.execute(bdp_tables_sql)
    bdp_tables_data = cur.fetchall()
    for dtd in bdp_tables_data:
        if dtd["table_schema"] in database_list:
            bdp_tables.append((dtd["table_schema"], dtd["table_name"]))
        dtd["table_name"] = get_collection_name(dtd["table_schema"], dtd["table_name"])
        dtd["table_schema"] = "bdp_data"
    bdp_tables_coll.insert_many(list(bdp_tables_data))
    print "Done insert collection:", "bdp_tables"

    # init bdp_columns collections
    bdp_columns_coll = getattr(db, 'bdp_columns')
    bdp_columns_sql = 'SELECT table_schema, table_name, column_name, column_status, rename_from, column_type, ' \
                      'is_nullable, column_key, comment, created_time, updated_time' \
                      ' FROM bdp_metadata.bdp_columns'
    cur.execute(bdp_columns_sql)
    bdp_columns_data = cur.fetchall()
    for dcd in bdp_columns_data:
        dcd["table_name"] = get_collection_name(dcd["table_schema"], dcd["table_name"])
        dcd["table_schema"] = "bdp_data"

    bdp_columns_coll.insert_many(list(bdp_columns_data))
    print "Done insert collection:", "bdp_columns"


def main():
    # init metadata, mongodb data from mysql origin
    db = get_mongodb_db()
    conn = get_mysql_conn()
    cur = conn.cursor()
    get_transform_info(cur)
    init_metadata(db, cur)
    init_business_data(db, cur)
    cur.close()
    conn.close()


if __name__ == '__main__':
    main()
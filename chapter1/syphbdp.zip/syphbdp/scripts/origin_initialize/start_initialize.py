# -*- coding: UTF-8 -*-

import os
import time
import datetime
import MySQLdb

from settings import *

time_unix = int(time.time()*1000)
time_now = datetime.datetime.now().strftime('%y-%m-%d %H:%M:%S')

schema_source_columns = "SCHEMA_NAME,DEFAULT_CHARACTER_SET_NAME,DEFAULT_COLLATION_NAME"
schema_query_where = ' SCHEMA_NAME NOT IN ("mysql", "information_schema", "bdp_metadata", "performance_schema", ' \
                     '"maxwell")'
schema_from_table = "SCHEMATA"

table_source_columns = "TABLE_NAME,TABLE_SCHEMA"
table_query_where = ' TABLE_SCHEMA NOT IN ("mysql", "information_schema", "bdp_metadata", "performance_schema", ' \
                     '"maxwell")'
table_from_table = "TABLES"

column_source_columns = "COLUMN_NAME,TABLE_SCHEMA,TABLE_NAME,COLUMN_TYPE,COLUMN_KEY,IS_NULLABLE"
column_query_where = ' TABLE_SCHEMA NOT IN ("mysql", "information_schema", "bdp_metadata", "performance_schema", ' \
                     '"maxwell")'
column_from_table = "COLUMNS"

db_list = []
for db in database_list:
    db_list.append('"' + str(db) + '"')
bdp_table_source_columns = "table_name,table_schema"
bdp_table_query_where = "table_schema in (%s)" % ','.join(db_list)
bdp_table_from_table = "bdp_tables"


def sql_query(source_col, from_tb, query_w, conn):
    con = MySQLdb.connect(host=conn[0], user=conn[1], passwd=conn[2], db=conn[3], port=conn[4])
    cursor = con.cursor()
    if query_w:
        sql = "SELECT " + source_col + " FROM " + from_tb + ' WHERE ' + query_w
    else:
        sql = "SELECT " + source_col + " FROM " + from_tb
    results = []
    try:
        cursor.execute(sql)
        results = cursor.fetchall()
    except MySQLdb.Error, e:
        print "Execute SQL:%s Error: %s" % (sql, e.args)
    con.close()

    return results


def sql_insert(dist_tb, dist_col, insert_values, conn):
    con = MySQLdb.connect(host=conn[0], user=conn[1], passwd=conn[2], db=conn[3], port=conn[4])
    cursor = con.cursor()
    count = 0
    if len(insert_values) != 0:
        for value in insert_values:
            count += 1
            sql = "INSERT INTO " + dist_tb + "(" + dist_col + ")" + " VALUES" + value.__str__()
            try:
                cursor.execute(sql)
                if count > 1000:
                    con.commit()
                    count = 0
            except MySQLdb.Error, e:
                print "Execute SQL:%s Error: %s" % (sql, e.args)
                con.rollback()
        else:
            con.commit()
        con.close()


def sql_alter(alter_sql_list, conn):
    con = MySQLdb.connect(host=conn[0], user=conn[1], passwd=conn[2], db=conn[3], port=conn[4])
    cursor = con.cursor()
    if len(alter_sql_list) != 0:
        for sql in alter_sql_list:
            if not sql:
                continue
            print sql
            try:
                cursor.execute(sql)
                con.commit()
            except MySQLdb.Error, e:
                print "Execute SQL:%s Error: %s" % (sql, e.args)
                con.rollback()
        con.close()


def insert_bdp_schema():
    # query all databases,maybe be need filter
    print "insert bdp_schema"
    schema_query_results = sql_query(schema_source_columns, schema_from_table, schema_query_where, con_info_schema)
    schema_results = []
    for i in schema_query_results:
        i = i + (0, '', '', str(time_unix), 0)
        schema_results.append(i)
    schema_dist_columns = "schema_name, character_set, collation_name, schema_status, rename_from, comment, " \
                          "created_time, updated_time"
    sql_insert('bdp_schema', schema_dist_columns, schema_results, con_bdp)


def insert_bdp_tables():
    print "insert bdp_tables"
    table_query_results = sql_query(table_source_columns, table_from_table, table_query_where, con_info_schema)
    table_results = []
    for i in table_query_results:
        i = i + (0, '', '', str(time_unix), 0)
        table_results.append(i)
    table_dist_columns = "table_name,table_schema,table_status,rename_from,comment,created_time,updated_time"
    sql_insert('bdp_tables', table_dist_columns, table_results, con_bdp)


def insert_bdp_columns():
    print "insert bdp_columns"
    column_query_results = sql_query(column_source_columns, column_from_table, column_query_where, con_info_schema)
    column_results = []
    for i in column_query_results:
        j = list(i)
        if j[5] == 'YES':
            del j[5]
            j.append(1)
        else:
            del j[5]
            j.append(0)
        j = j + [0, '', '', str(time_unix), 0]
        column_results.append(tuple(j))
    column_dist_columns = "column_name,table_schema,table_name,column_type,column_key,is_nullable,column_status," \
                          "rename_from,comment,created_time,updated_time"
    sql_insert('bdp_columns', column_dist_columns, column_results, con_bdp)


def alter_bdp():
    print "add bdp_updated_time bdp_status"
    bdp_table_query_results = sql_query(bdp_table_source_columns, bdp_table_from_table, bdp_table_query_where, con_bdp)
    bdp_table_list = []
    for i in bdp_table_query_results:
        sql_bdp_updated_time = "ALTER TABLE " + i[1] + "." + i[0] \
                               + " ADD bdp_updated_time bigint(13) DEFAULT 0"
        sql_bdp_status = 'ALTER TABLE ' + i[1] + '.' + i[0] + ' ADD bdp_status tinyint DEFAULT 0'
        bdp_table_list.append(sql_bdp_updated_time)
        bdp_table_list.append(sql_bdp_status)

        columns_str = ' COLUMN_KEY, COLUMN_NAME'
        columns_filter = 'TABLE_NAME= "%s" AND TABLE_SCHEMA = "%s"' % (i[0], i[1])
        columns = sql_query(columns_str, column_from_table, columns_filter, con_info_schema)
        primary_cols = []
        for col in columns:
            if col[0] in ("PRI", "UNI"):
                primary_cols.append(col[1])
        if primary_cols:
            primary_cols.append('bdp_updated_time')
            primary_cols.append('bdp_status')
            sql_add_primary = 'ALTER TABLE %s.%s DROP PRIMARY KEY, ADD PRIMARY KEY (%s)' \
                              % (i[1], i[0], ','.join(primary_cols))
            bdp_table_list.append(sql_add_primary)

        # delete table unique index
        _index_filter = 'TABLE_SCHEMA="%s" AND TABLE_NAME="%s" AND CONSTRAINT_TYPE="UNIQUE"' % (i[1], i[0])
        _index = sql_query("CONSTRAINT_NAME", "TABLE_CONSTRAINTS", _index_filter, con_info_schema)
        for _ind in _index:
            sql_delete_uni = "ALTER  TABLE %s.%s  DROP  INDEX %s" % (i[1], i[0], _ind[0])
            bdp_table_list.append(sql_delete_uni)

    sql_alter(bdp_table_list, con_bdp)


def create_bdp():
    print "create database:bdp_metadata, tables:bdp_columns, bdp_schema, bdp_tables"
    script_dir = os.path.dirname(__file__)
    _sql = open(os.path.join(script_dir, 'schema.sql')).read()
    sql_list = _sql.strip("\n").strip("\r").split(";")
    if not sql_list[-1]:
        del sql_list[-1]
    sql_alter(sql_list, con_info_schema)


def main():
    create_bdp()
    insert_bdp_schema()
    insert_bdp_tables()
    insert_bdp_columns()
    alter_bdp()

if __name__ == '__main__':
    main()








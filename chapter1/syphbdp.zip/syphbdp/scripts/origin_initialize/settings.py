# -*- coding: UTF-8 -*-

# config databases bdp_metadata
con_bdp = ['192.168.1.198', 'dev', '123456', 'bdp_metadata', 3306]

# config mysql information_schema
con_info_schema = ['192.168.1.198', 'dev', '123456', 'information_schema', 3306]

# config origin initialize include db
database_list = ['ybrhh1', 'ybrtest01', 'bizybr', 'consoleybr', 'core09', 'coreybr', 'taskybr']

# mongodb config
MONGODB_CONFIG = {
    'host': '192.168.1.100:27017,192.168.1.101:27017,192.168.1.101:27018',
    'port': 27017,
    'user': 'bdp',
    'password': '123456',
    'db': 'bdp_data',
    'replicaSet': 'rs0'
}
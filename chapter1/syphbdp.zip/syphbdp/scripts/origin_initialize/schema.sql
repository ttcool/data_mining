CREATE DATABASE IF NOT EXISTS bdp_metadata default charset utf8 COLLATE utf8_general_ci;

DROP TABLE IF EXISTS bdp_metadata.bdp_schema;
CREATE TABLE bdp_metadata.bdp_schema(
schema_name varchar(128) NOT NULL,
character_set  varchar(32) NOT NULL,
collation_name  varchar(64) NOT NULL,
schema_status  tinyint NOT NULL,
rename_from varchar(128),
comment varchar(128),
created_time bigint(13) DEFAULT 0,
updated_time bigint(13) DEFAULT 0,
PRIMARY KEY (`schema_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS bdp_metadata.bdp_tables;
CREATE TABLE bdp_metadata.bdp_tables(
table_name varchar(128) NOT NULL ,
table_schema  varchar(128) NOT NULL ,
table_status  tinyint NOT NULL,
rename_from varchar(128),
comment varchar(128),
created_time bigint(13) DEFAULT 0,
updated_time bigint(13) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS bdp_metadata.bdp_columns;
CREATE TABLE bdp_metadata.bdp_columns(
column_name varchar(128) NOT NULL ,
table_schema  varchar(128) NOT NULL ,
table_name  varchar(128) NOT NULL,
column_status  tinyint NOT NULL,
rename_from varchar(128),
column_type longtext NOT NULL,
is_nullable tinyint  NOT NULL DEFAULT 1,
column_key varchar(3) NOT NULL DEFAULT '',
comment varchar(128),
created_time bigint(13) DEFAULT 0,
updated_time bigint(13) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


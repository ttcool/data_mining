# -*- coding:utf-8 -*-

import os
from datetime import datetime, timedelta

from airflow.models import DAG
from airflow.operators.python_operator import PythonOperator

from setting import ORIGIN_LOG_DIR

seven_days_ago = datetime.combine(datetime.today() - timedelta(days=0),
                                  datetime.min.time())
args = {
    'owner': 'ybr',
    'start_date': seven_days_ago,
    'depends_on_past': False,
    'retries': 0,
    'retry_delay': timedelta(minutes=5),
}

origin_check = DAG(
        dag_id='origin_check',
        default_args=args,
        schedule_interval='30 23 * * *')


def execute_check(log_dir, **kwargs):
    _today = datetime.now().strftime('%Y-%m-%d')
    if not log_dir.endswith("/"):
        log_dir += '/*'
    else:
        log_dir += '*'
    cmd = 'cat %s |grep "%s" |grep "ERROR"' % (log_dir, _today)
    process = os.popen(cmd)
    output = process.read()
    process.close()
    if output:
        raise Exception('Origin has ERROR')


run_check = PythonOperator(
    task_id='run_check',
    provide_context=True,
    python_callable=execute_check,
    op_kwargs={'log_dir': ORIGIN_LOG_DIR},
    dag=origin_check)


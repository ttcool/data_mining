# -*- coding: UTF-8 -*-

import os
import sys
BASE_DIR = os.path.dirname(os.path.dirname(__file__))
sys.path.append(BASE_DIR)
from conf.settings import MYSQL_CONFIG, ODS_target_DATABASE, ORIGIN_LOG_DIR
from vendor.connection.mysql import MysqlClass
from vendor.public.exception import MyException
from vendor.constants.COMMON import BDP_STATUS

BUSINESS = BDP_STATUS["BUSINESS"]
UPDATED = BDP_STATUS["UPDATED"]
DELETED = BDP_STATUS["DELETED"]
DATABASES = MYSQL_CONFIG["origin"]
TARGET_DB = ODS_target_DATABASE
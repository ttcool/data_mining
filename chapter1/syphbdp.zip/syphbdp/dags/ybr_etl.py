# -*- coding:utf-8 -*-
from datetime import datetime, timedelta
from airflow.models import DAG
from airflow.operators.python_operator import PythonOperator
from etl_extract.airflow_etl import etl_handle
from dags.setting import *
seven_days_ago = datetime.combine(datetime.today() - timedelta(days=0),
                                  datetime.min.time())
args = {
    'owner': 'ybr',
    'start_date': seven_days_ago,
    'depends_on_past': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}
mysql = MysqlClass(mysql_config=DATABASES)
target_tb_sql = "SELECT id,target_tb_name from %s.ETL_CFG" % TARGET_DB
theme_tb_sql = "SELECT theme,target_tb_name from %s.ETL_THEME_TABLE" % TARGET_DB
target_tb_name = mysql.sql_execute(target_tb_sql)
theme_table = mysql.sql_execute(theme_tb_sql)
theme_table = dict(
    [('%s.%s' % (TARGET_DB, i["target_tb_name"].encode('utf8')), i["theme"].encode('utf8')) for i in theme_table])
target_tables = [(i["id"], i["target_tb_name"].encode('utf8')) for i in target_tb_name]
schedule_interval = '39 18 * * *'
# dag = DAG(
#         dag_id='ybr',
#         default_args=args,
#         schedule_interval=schedule_interval)
protocol_theme = DAG(
        dag_id='protocol_theme',
        default_args=args,
        schedule_interval=schedule_interval)
wind_control_theme = DAG(
        dag_id='wind_control_theme',
        default_args=args,
        schedule_interval=schedule_interval)
participant_theme = DAG(
        dag_id='participant_theme',
        default_args=args,
        schedule_interval=schedule_interval)
event_theme = DAG(
        dag_id='event_theme',
        default_args=args,
        schedule_interval=schedule_interval)
financial_theme = DAG(
        dag_id='financial_theme',
        default_args=args,
        schedule_interval=schedule_interval)
product_theme = DAG(
        dag_id='product_theme',
        default_args=args,
        schedule_interval=schedule_interval)

for ids, target_tb_name in target_tables:
    task = PythonOperator(
        task_id=target_tb_name.split('.')[-1],
        python_callable=etl_handle,
        op_kwargs={"target_tb": "(%s)" % ids},
        dag=eval(theme_table.get(target_tb_name))
        # dag=dag
    )
# -*- coding:utf-8 -*-
from datetime import datetime, timedelta
from airflow.models import DAG
from airflow.operators.python_operator import PythonOperator
from etl_extract.etl_mongo import etl_mongo_handle
from vendor.connection.mongo import db

etl_target_tb_sync_time_coll = getattr(db, "ETL_TARGET_TB_SYNC_TIME")

def get_etl_dict(collection):
    result = []
    dict = collection.find({},{"_id":0})
    
    if dict.count()!=0:
        print dict.count()
        for i in dict:
            print i
            result.append(i)
    return result

#目标表同步时间字典
target_tb_sync_time_dict = get_etl_dict(etl_target_tb_sync_time_coll)

seven_days_ago = datetime.combine(datetime.today() - timedelta(days=0),datetime.min.time())

args = {
    'owner': 'ybr',
    'start_date': seven_days_ago,
    'depends_on_past': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

schedule_interval = '*/30 * * * *'

protocol_mongo_theme = DAG(
        dag_id='protocol_mongo_theme',
        default_args=args,
        schedule_interval=schedule_interval)
risk_control_mongo_theme = DAG(
        dag_id='risk_control_mongo_theme',
        default_args=args,
        schedule_interval=schedule_interval)
participant_mongo_theme = DAG(
        dag_id='participant_mongo_theme',
        default_args=args,
        schedule_interval=schedule_interval)
event_mongo_theme = DAG(
        dag_id='event_mongo_theme',
        default_args=args,
        schedule_interval=schedule_interval)
financial_mongo_theme = DAG(
        dag_id='financial_mongo_theme',
        default_args=args,
        schedule_interval=schedule_interval)
product_mongo_theme = DAG(
        dag_id='product_mongo_theme',
        default_args=args,
        schedule_interval=schedule_interval)

for i in  target_tb_sync_time_dict:
    mongo_etl_task = PythonOperator(
        task_id = i["target_tb_name"],
        python_callable = etl_mongo_handle,
        op_kwargs = {"target_tb":i["target_tb_name"]},
        dag = eval(i['theme_name'])
        )

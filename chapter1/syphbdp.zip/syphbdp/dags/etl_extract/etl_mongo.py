# -*- coding: UTF-8 -*-

"""
Created on 2017-2-23
@author: chentao
Project:ETL-mongo
"""

from pymongo import MongoClient
from pandas import Series,DataFrame,merge
from vendor.connection.mongo import db

import logging
import time
import datetime
import attr

log_filename = "logging_mongo_etl.log"
logging.basicConfig(filename=log_filename,filemode='w',level=logging.DEBUG)
etl_target_tb_sync_time_coll = getattr(db, "ETL_TARGET_TB_SYNC_TIME")
etl_enum_cfg_coll = getattr(db, "ETL_ENUM_CFG")
etl_cfg_coll = getattr(db, "ETL_CFG")

def get_etl_dict(collection):
    """:get_etl_dict  return dict"""
    result = []
    dict = collection.find({},{"_id":0})
    if dict.count()!=0:
        for i in dict:
            result.append(i)
    return result

target_tb_sync_time_dict = get_etl_dict(etl_target_tb_sync_time_coll)
""":target_tb_sync_time_dict  last sync time dict"""
etl_enum_cfg_dict = get_etl_dict(etl_enum_cfg_coll)
""":etl_enum_cfg_dict enum dict"""
etl_cfg_dict = get_etl_dict(etl_cfg_coll)
""":etl_cfg_dict etl config dict"""

def datetime_timestamp(dt):
     """dt string
     s datetime array"""
     s=time.mktime(datetime.datetime.strptime(dt,"%Y-%m-%d %H:%M:%S").timetuple())
     return s

def get_dataframe(query_dict):
    """:get_dataframe  get pandas DataFrame"""
    result=[]
    if query_dict.count()!=0:
        for i in query_dict:
            del i['_id'],i['bdp_updated_time']
            result.append(i)
    return DataFrame(result)

def get_merge_list(left,right,**kwargs):
    """:get_merge_list left and right DataFrame merge"""
    result = []
    try:
        if kwargs['on'] != "":
            data = merge(left,right,on=kwargs['on'],how=kwargs['how'])
        else:
            data = merge(left,right,left_on=kwargs['left_on'],right_on=kwargs['right_on'],how=kwargs['how'])
        for i in data.values:
            result_dict = {}
            for j in range(len(data.columns)):
                result_dict[data.columns[j]]=i[j]
            if result_dict['bdp_status_x'] + result_dict['bdp_status_y'] == 0.0:
                result_dict['bdp_status'] = 0
            else:
                result_dict['bdp_status'] = 1
            del result_dict['bdp_status_x'],result_dict['bdp_status_y']
            result.append(result_dict)

    except Exception as e:
        logging.error(e.message)
    return result

def get_join_result(join_list,query_field):
    """:get_join_result
    join_list: {left:'',right:'',on:'',left_on:'',right_on:'',how:''}
    query_field:{'bdp_updated_time':{'$gte':''}}
    """
    result = []
    left = getattr(db, join_list['left']).find(eval(query_field))
    right = getattr(db, join_list['right']).find(eval(query_field))
    on = join_list['on']
    how = join_list['how']
    left_on = join_list['left_on']
    right_on = join_list['right_on']

    if (left.count()==0)or(right.count()==0):
        return result

    left_dateframe = get_dataframe(left)
    right_dateframe = get_dataframe(right)

    result = get_merge_list(left_dateframe,right_dateframe,on=on,how=how,left_on=left_on,right_on=right_on)
    return result

class cal_handle():
    """is_cal"""
    def get_pty_user_work(self):
        """:get_pty_user_work return result"""
        self.result = []
        self.target_tb = 'ods__pty__user__work'
        self.last_sync_time = get_last_sync_time(self.target_tb)
        self.query_field ="{'bdp_updated_time':{'$gte':%s}}"%self.last_sync_time
        self.is_join = {'left':'db.stg__ybrhh1__t_client','right':'db.stg__ybrhh1__t_client_detailinfo','on':'CLIENT_ID','left_on':'','right_on':'','how':'inner','suffixes':"('_x','_y')"}
        join_result = get_join_result(self.is_join,self.query_field)
        if join_result == []:
            return self.result
        else:
            t_client_unit_result = getattr(db, 'stg__ybrhh1__t_client_unit').find(eval(self.query_field))
            if t_client_unit_result.count == 0:
                return self.result
            else:
                join_result_dataframe = get_dataframe(join_result)
                t_client_unit_result_dataframe = get_dataframe(t_client_unit_result)
                self.result = get_merge_list(join_result_dataframe,t_client_unit_result_dataframe,on='CLIENT_ID',left_on='',right_on='',how='inner')
                return self.result

def get_last_sync_time(target_tb):
    """:get_last_sync_time  last sync time"""
    last_sync_time = '1970-01-01 08:00:00'
    for sync_time in target_tb_sync_time_dict:
        if sync_time['target_tb_name'] == target_tb:
            last_sync_time = sync_time["last_sync_time"]
    last_sync_time = int(datetime_timestamp(last_sync_time))*1000
    return last_sync_time

def get_no_cal_result(is_join,query_field,source_tb_name):
    """get_no_cal_result  return no cal return"""
    result = []
    if len(is_join)!= 0:
        result = get_join_result(is_join,query_field)
        return result
    else:
        result_source = getattr(db, source_tb_name).find(eval(query_field))
        if  result_source.count() != 0:
            for source in result_source:
                del source['bdp_updated_time'],source['_id']
                result.append(source)
        return result

def etl_mongo_handle(target_tb):
    """:etl_handle main function"""
    last_sync_time = get_last_sync_time(target_tb)
    #query_field bdp_updated_time gte last sync time
    query_field ="{'bdp_updated_time':{'$gte':%s}}"%last_sync_time
    no_zero_num = 0
    insert_num = 0
    try:
        for i in etl_cfg_dict:
            result = []
            #bdp_status==0 list
            result_zero_list = []
            #bdp_status!=0 list
            result_no_zero_list = []

            source_tb_name = i['source_tb_name']
            source_columns = i['source_columns']
            target_columns = i['target_columns']
            is_join = i['is_join']
            is_cal = i['is_cal']
            if i['target_tb_name'] == target_tb:
                if is_cal =="":
                    result = get_no_cal_result(is_join,query_field,source_tb_name)
                else:
                    obj = cal_handle()
                    result=getattr(obj,is_cal)()

                #根据bdp_status是否为0分别存放
                if len(result)!=0:
                    for status_dict in result:
                        if status_dict['bdp_status']==0:
                            result_zero_list.append(status_dict)
                        else:
                            result_no_zero_list.append(status_dict)

            #删除目标表中与result_no_zero_list列表匹配的记录
            if len(result_no_zero_list)!= 0:
                for no_zero_dict in result_no_zero_list:
                    if no_zero_dict['bdp_status']:
                        del no_zero_dict['bdp_status']
                        getattr(db, target_tb).delete_many(no_zero_dict)

            #转换数据
            if len(result_zero_list)!= 0:
                no_zero_num = len(result_zero_list)
                insert_data = []
                for zero_dict in result_zero_list:
                    insert_dict = {}
                    #新增字段及默认值加入待插入字典
                    if len(i['is_add']) != 0:
                        for is_add_key,is_add_value in i['is_add'].items():
                            zero_dict[is_add_key] = is_add_value

                    #提取目标表需要的字段数据
                    for j in source_columns:
                        insert_dict[j] = zero_dict[j]
                        if len(target_columns)!=0:
                            for k,v in target_columns.items():
                                if k == j:
                                    del insert_dict[j]
                                    insert_dict[v] = zero_dict[j]

                    #枚举转换
                    for enum in etl_enum_cfg_dict:
                        """check insert_dict key"""
                        if enum['target_columns'] in insert_dict.keys():
                            if (enum['target_tb_name'] == target_tb)and(insert_dict[enum['target_columns']]==enum['source_value']):
                                del insert_dict[enum['target_columns']]
                                insert_dict[enum['target_columns']] = enum['target_value']
                    insert_data.append(insert_dict)
                    #记录写入目标表,写入前去重
                    db[target_tb].delete_many(insert_dict)
                insert_num = len(insert_data)
                db[target_tb].insert(insert_data)

        #更新ETL_TARGET_TB_SYNC_TIME last_sync_time
        #now_time = time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time()))
        today = datetime.datetime.today() - datetime.timedelta(hours=3)
        update_time = datetime.datetime(today.year, today.month, today.day, today.hour, today.minute, today.second)
        filer_tb = "{'target_tb_name':'%s'}"%target_tb
        sync_time = "{'$set':{'last_sync_time':'%s'}}"%update_time
        db['ETL_TARGET_TB_SYNC_TIME'].update(eval(filer_tb),eval(sync_time),upsert=True)
        logging.debug("%s|%d|%d|%s"%(target_tb,no_zero_num,insert_num,update_time))

    except Exception as e:
        logging.error(e.message)

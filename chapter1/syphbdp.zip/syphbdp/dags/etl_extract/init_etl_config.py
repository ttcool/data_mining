# -*- coding:utf-8 -*-
import MySQLdb
import pandas as pd
import sys, os
import json
import xlrd
from dags.etl_extract.setting import TARGET_DB, DATABASES

DATABASES["db"] = TARGET_DB


def sql_execute(sql):
    conn = MySQLdb.connect(**DATABASES)
    cursor = conn.cursor()
    try:
        res = cursor.execute(sql)
        cursor.close()
        conn.commit()
        conn.close()
    except Exception as e:
        error_list.append([sql, e.args[1]])

    return res


def init_create_target_table():
    path = os.path.dirname(os.path.dirname(__file__)) + "/excel_config/init_create_target_table.xlsx"
    sheets = xlrd.open_workbook(path).sheets()
    ex_sheet_count = len(sheets)
    for sheet_index in range(ex_sheet_count):
        theme = sheets[sheet_index].name
        df = pd.read_excel(path, sheetname=sheet_index, header=0, encoding='utf-8')
        df = df.fillna(value='')
        df_group = df.groupby([df["table"], df["table_comment"]], sort=False)
        for group_name, group_value in df_group:
            group_value = group_value.ix[:, 2:]
            group_value_field = list(group_value["field"])
            group_value = json.loads(group_value.T.to_json()).values()
            group_value.sort(key=lambda x: group_value_field.index(x["field"]))
            del_sql = "DROP TABLE IF EXISTS %s" % group_name[0]
            del_sync_time_sql = "delete from ETL_TARGET_TB_SYNC_TIME where target_tb_name='%s'" % group_name[0]
            del_theme_table_sql = "delete from ETL_THEME_TABLE where theme='%s' and target_tb_name='%s'" % (theme, group_name[0])
            sql_execute(del_sql)
            sql_execute(del_sync_time_sql)
            sql_execute(del_theme_table_sql)
            sql = "CREATE TABLE %s (" % group_name[0]
            field_sql = ''
            for i in group_value:
                field_sql = field_sql + i["field"] + " " + i["data_type"]
                if i["not_null"] != '':
                    field_sql = field_sql + " NOT NULL"
                if i["default"] != '':
                    if isinstance(i["default"], float):
                        if int(i["default"]) == i["default"]:
                            i["default"] = int(i["default"])
                    field_sql = field_sql + " DEFAULT %s" % i["default"]
                if i["auto_inc"] != '':
                    field_sql = field_sql + " AUTO_INCREMENT"
                if i["unique"] != '':
                    field_sql = field_sql + " UNIQUE KEY"
                if i["is_pk"] != '':
                    field_sql = field_sql + " PRIMARY KEY"
                field_sql = field_sql + " COMMENT '%s'" % i["comment"]
                if i != group_value[-1]:
                    field_sql = field_sql + ','

            sql1 = ") ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT '%s'" % group_name[1]
            sql = sql + field_sql + sql1
            sql_execute(sql)

            sync_time_sql = "INSERT INTO ETL_TARGET_TB_SYNC_TIME(target_db,target_tb_name,target_tb_comment) " \
                            "VALUES ('%s','%s','%s')" % (TARGET_DB, group_name[0], group_name[1])
            sql_execute(sync_time_sql)
            insert_theme_table_sql = "INSERT INTO ETL_THEME_TABLE(theme,target_tb_name,target_tb_comment) " \
                            "VALUES ('%s','%s','%s')" % (theme, group_name[0], group_name[1])
            sql_execute(insert_theme_table_sql)


def init_enum_table():
    sql = "TRUNCATE ETL_ENUM_CFG"
    sql_execute(sql)
    path = os.path.dirname(os.path.dirname(__file__)) + "/excel_config/init_enum_table.xlsx"
    ex_sheet_count = len(xlrd.open_workbook(path).sheets()) - 1
    for sheet_index in range(ex_sheet_count):
        df = pd.read_excel(path, sheetname=sheet_index, header=0, encoding='utf-8')
        df = df.fillna(value='')
        df = df.ix[:,
             ["source_db", "source_table", "source_field", "table", "target_field", "table_comment", "source_value",
              "target_value", "field_comment", "target_value_comment"]]
        tmp_list = json.loads(df.T.to_json()).values()
        for i in tmp_list:
            sql = """insert into ETL_ENUM_CFG(source_db,source_tb_name,source_columns,
                     source_value,target_tb_name,target_columns,target_value,
                     target_tb_comment,target_columns_comment,target_value_comment)
                     VALUES ('%s','%s',"%s",'%s','%s','%s','%s','%s','%s','%s')""" % (
                i["source_db"], i["source_table"], i["source_field"], i["source_value"],
                i["table"], i["target_field"], i["target_value"], i["table_comment"],
                i["field_comment"], i["target_value_comment"])
            sql_execute(sql)


def init_etl_config_table_hh():
    sql = "TRUNCATE ETL_CFG"
    sql_execute(sql)
    path = os.path.dirname(os.path.dirname(__file__)) + "/excel_config/init_etl_config_table_hh.xlsx"
    ex_sheet_count = len(xlrd.open_workbook(path).sheets())
    for sheet_index in range(ex_sheet_count):
        df = pd.read_excel(path, sheetname=sheet_index, header=0, encoding='utf-8')
        df = df.fillna(value='')
        df_group = df.groupby([df["table"], df["table_comment"]], sort=False)
        for group_name, group_value in df_group:
            group_value = group_value.ix[:,
                          ['field', "source_table", "source_field", 'query_field', "source_db", "is_enum",
                           "unique_key", "from_source_tb", "source_tb_name", "data_type"]]
            group_value = json.loads(group_value.T.to_json()).values()
            # print group_value
            target_columns = []
            source_columns = []
            source_columns_as = []
            enum_columns = []
            target_unique_key = []
            source_tb_names = set()
            target_columns_type = {}
            query_field = ''
            from_source_tb = ''
            source_tb_name = ''
            have_enum = 0
            for i in group_value:
                if i["field"]:
                    target_columns.append(i["field"])
                    i["data_type"] = i["data_type"].encode('utf8')
                    if i["data_type"].startswith('int'):
                        data_type = 'int'
                    elif i["data_type"].startswith('varchar') or i["data_type"].startswith('char'):
                        data_type = 'varchar'
                    elif i["data_type"].startswith('datetime'):
                        data_type = "datetime"
                    target_columns_type[i["field"].encode('utf8')] = data_type
                source_columns.append({i["source_field"]: [i["source_db"], i["source_table"], i["field"]]})
                if i["source_db"] and i["source_table"]:
                    source_tb_names.add('%s.%s' % (i["source_db"], i["source_table"]))
                if not query_field:
                    query_field = i["query_field"]
                if i["is_enum"]:
                    have_enum = 1
                    enum_columns.append('%s.%s.%s' % (i["source_db"], i["source_table"], i["field"]))
                if i["unique_key"]:
                    target_unique_key.append(i["field"])
                if i["from_source_tb"]:
                    from_source_tb = i["from_source_tb"]
                if i["source_tb_name"]:
                    source_tb_name = i["source_tb_name"]
            for i in source_columns:
                source_field = i.keys()[0]
                source_db = i.values()[0][0]
                source_table = i.values()[0][1]
                target_field = i.values()[0][2]
                if str(source_field).isdigit():
                    cl = """%s as '%s.%s.%s'""" % (
                        source_field, source_db, source_table, target_field)
                elif source_db and source_table:
                    if source_field in ('BDP_STATUS', "bdp_status"):
                        cl = """%s.%s.%s as '%s.%s.%s'""" % (
                            source_db, source_table, source_field, source_db, source_table, source_field)
                    else:
                        cl = """%s.%s.%s as '%s.%s.%s'""" % (
                            source_db, source_table, source_field, source_db, source_table, target_field)
                else:
                    cl = """%s""" % (source_field)
                source_columns_as.append(cl)

            target_columns = ','.join(target_columns)
            source_columns_as = ','.join(source_columns_as)
            source_tb_names = ','.join(source_tb_names)
            enum_columns = ','.join(enum_columns)
            target_unique_key = ','.join(target_unique_key)

            if not source_tb_name:
                source_tb_name = source_tb_names
            if not from_source_tb:
                from_source_tb = source_tb_name
            sql = """insert into ETL_CFG(source_tb_name, target_tb_name,source_columns,target_columns,
                      query_field,target_tb_comment,enum_columns,from_source_tb,target_unique_key)
                      VALUES ("%s","%s.%s","%s","%s","%s","%s","%s","%s","%s")""" \
                  % (source_tb_name, TARGET_DB, group_name[0], source_columns_as, target_columns_type,
                     query_field, group_name[1], enum_columns, from_source_tb, target_unique_key)
            sql_execute(sql)


if __name__ == '__main__':
    error_list = []
    init_create_target_table()
    print "---init_target_table_error---\n", error_list

    error_list = []
    init_enum_table()
    print "---init_enum_table_error----\n", error_list

    error_list = []
    init_etl_config_table_hh()
    print "---init_etl_config_hh_error---\n", error_list

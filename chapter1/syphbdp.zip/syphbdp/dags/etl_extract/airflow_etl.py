# -*- coding: UTF-8 -*-

import time
import datetime
import logging

from dags.setting import *

reload(sys)
sys.setdefaultencoding("utf-8")

DATABASES["db"] = TARGET_DB


def get_enum_dict():
    """
    :return: {'source_db.source_tb.target_columns':
                            {source_value:target_enum_value,source_value:target_enum_value ....},
            ........
            }
    """
    mysql = MysqlClass(mysql_config=DATABASES)
    enum_sql = "SELECT * FROM ETL_ENUM_CFG"
    enum_list = mysql.sql_execute(enum_sql)
    enum_dict = {}

    for i in enum_list:
        source_db = i["source_db"]
        source_tb_name = i["source_tb_name"]
        target_columns = i["target_columns"]
        source_value = i["source_value"]
        target_value = i["target_value"]
        tmp = "%s.%s.%s" % (source_db, source_tb_name, target_columns)
        if tmp in enum_dict:
            enum_dict[tmp][source_value] = target_value
        else:
            enum_dict.setdefault(tmp, {})[source_value] = target_value
    return enum_dict


def get_etl_sync_time_config():
    """
    :return: {'target_db.target_tb':last_sync_time,
                .....
            }
    """
    mysql = MysqlClass(mysql_config=DATABASES)
    sync_time_sql = "SELECT * FROM ETL_TARGET_TB_SYNC_TIME"
    sync_time_list = mysql.sql_execute(sync_time_sql)
    sync_time_dict = {}
    for i in sync_time_list:
        target_db = i["target_db"]
        target_tb_name = i["target_tb_name"]
        last_sync_time = i["last_sync_time"]
        sync_time_dict["%s.%s" % (target_db, target_tb_name,)] = last_sync_time
    return sync_time_dict


def etl_handle(target_tb):
    try:
        mysql = MysqlClass(mysql_config=DATABASES)
        enum_dict = get_enum_dict()
        last_sync_time_dict = get_etl_sync_time_config()

        # set_sql = """set sql_mode = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION'"""
        # mysql.sql_execute(set_sql)
        etl_config_sql = "SELECT * FROM ETL_CFG WHERE status=1 and id in %s ORDER BY id" % target_tb
        etl_config_list = mysql.sql_execute(etl_config_sql)
        for etl_config in etl_config_list:
            source_tb_list = etl_config["source_tb_name"].split(",")
            target_tb_name = etl_config["target_tb_name"]
            source_columns = etl_config["source_columns"]
            target_columns = eval(etl_config["target_columns"])
            query_field = etl_config["query_field"]
            enum_columns_list = etl_config["enum_columns"].split(",") if etl_config["enum_columns"] else []
            from_source_tb = etl_config["from_source_tb"]
            target_unique_key_list = etl_config["target_unique_key"].split(",")
            last_sync_time = last_sync_time_dict.get(target_tb_name)
            etl_sql = "SELECT %s FROM %s %s" % (source_columns, from_source_tb, query_field)
            args = tuple([last_sync_time for i in source_tb_list])
            etl_sql = etl_sql % args
            config_res = mysql.sql_execute(etl_sql)

            insert_list = []
            for row in config_res:
                logging.info("source_tb_list:%s target_tb_name:%s" % (source_tb_list, target_tb_name))
                logging.info("source_row:%s" % row)

                bdp_status_list = []
                if '%s.bdp_status' % source_tb_list[0] in row:
                    master_tb_row_status = row.pop('%s.bdp_status' % source_tb_list[0])
                else:
                    master_tb_row_status = BUSINESS

                if master_tb_row_status in (BUSINESS,):
                    for source_tb in source_tb_list[1:]:
                        bdp_status = '%s.bdp_status' % source_tb
                        if bdp_status in row:
                            bdp_status = row.pop(bdp_status)
                            if bdp_status in (BUSINESS, DELETED, None):
                                if bdp_status == DELETED:
                                    for key in row:
                                        if key.startswith(source_tb):
                                            row.update({key: None})
                            else:
                                bdp_status_list.append([source_tb, bdp_status])
                for enum_column in enum_columns_list:

                    v = enum_dict.get(enum_column, {}).get(row.get(enum_column, ''), '')

                    if v != '':
                        row[enum_column] = v
                    else:
                        row[enum_column] = None

                # col-->new_col  ===== source_db.source_tb.target_columns----->target_columns
                new_row = {}
                for col in row:
                    target_col = col.split('.')[-1]
                    if target_columns.get(target_col, '') in ('int', 'float'):
                        if row[col] != None:
                            try:
                                int(row[col])
                            except:
                                row[col] = None
                    elif target_columns.get(target_col, '') in ('datetime'):
                        tmp = str(row[col]).replace('/', '').replace('-', '').replace(':', '').replace(' ', '')
                        if not tmp.isdigit() or row[col] == '0000-00-00 00:00:00':
                            row[col] = None
                    new_row[target_col] = row[col]

                target_sql = 'FROM %s WHERE 1=1 ' % target_tb_name
                for key in target_unique_key_list:
                    target_sql += "AND %s='%s'" % (key, new_row[key])

                delete_target_sql = "DELETE " + target_sql
                res = mysql.sql_execute(delete_target_sql, query=False)

                if not bdp_status_list and master_tb_row_status not in (UPDATED, DELETED):
                    logging.info("target_row:%s" % new_row)
                    target_clo = ','.join(new_row.keys())
                    s_str = ('%s,' * len(new_row.keys())).rstrip(',')
                    insert_target_sql = "REPLACE INTO %s(%s) VALUES (%s)" % (target_tb_name, target_clo, s_str)
                    insert_list.append(new_row.values())
                if insert_list and len(insert_list) % 100 == 0:
                    mysql.sql_executemany(insert_target_sql, insert_list)
                    insert_list = []
            if insert_list:
                mysql.sql_executemany(insert_target_sql, insert_list)
            times = int(time.time()) - 5
            datetimes = datetime.datetime.fromtimestamp(times).strftime("%Y-%m-%d %H:%M:%S")
            etl_sync_time_config_sql = "UPDATE ETL_TARGET_TB_SYNC_TIME " \
                                       "SET last_sync_time=%s,last_sync_datetime='%s' " \
                                       "WHERE target_db='%s' AND target_tb_name='%s'" \
                                       % (times * 1000, datetimes, target_tb_name.split('.')[0],
                                          target_tb_name.split('.')[1])
            mysql.sql_execute(etl_sync_time_config_sql, query=False)
    except MyException as e:
        logging.error(e.message)
        raise MyException
    except Exception as e:
        logging.error(e.args)
        raise Exception


if __name__ == '__main__':
    etl_handle("(1,2,3,4,5,6,7,8,9,10,11)")
    # etl_handle("(1)")

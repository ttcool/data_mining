/*
SQLyog Ultimate v11.24 (32 bit)
MySQL - 5.6.28-0ubuntu0.15.10.1-log : Database - odsybr
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`odsybr` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `odsybr`;

/*Table structure for table `ETL_CFG` */

DROP TABLE IF EXISTS `ETL_CFG`;

CREATE TABLE `ETL_CFG` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `source_tb_name` varchar(1000) NOT NULL,
  `target_tb_name` varchar(1000) NOT NULL,
  `source_columns` varchar(3000) NOT NULL,
  `target_columns` varchar(2000) NOT NULL,
  `query_field` varchar(2000) NOT NULL,
  `target_tb_comment` varchar(500) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `enum_columns` varchar(1000) DEFAULT NULL,
  `from_source_tb` varchar(1000) NOT NULL,
  `target_unique_key` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COMMENT='ETL_CFG';

/*Data for the table `ETL_CFG` */

insert  into `ETL_CFG`(`id`,`source_tb_name`,`target_tb_name`,`source_columns`,`target_columns`,`query_field`,`target_tb_comment`,`status`,`enum_columns`,`from_source_tb`,`target_unique_key`) values (1,'ybrhh1.t_client,ybrhh1.t_client_detailinfo','odsybr.ODS_PTY_USER_INFO','ybrhh1.t_client_detailinfo.bdp_status as \'ybrhh1.t_client_detailinfo.bdp_status\',ybrhh1.t_client_detailinfo.HOUSE_TEL as \'ybrhh1.t_client_detailinfo.HOME_PHONE_NO\',ybrhh1.t_client.CLIENT_NAME as \'ybrhh1.t_client.NAME\',ybrhh1.t_client.CLIENT_ID as \'ybrhh1.t_client.USER_ID\',ybrhh1.t_client.IDCAR_ID as \'ybrhh1.t_client.CERT_NO\',ybrhh1.t_client.MARRIED as \'ybrhh1.t_client.MARRY_STATUS\',ybrhh1.t_client.ADDRESS as \'ybrhh1.t_client.ADDRESS\',ybrhh1.t_client.MOBILE as \'ybrhh1.t_client.MOBILE_NO\',ybrhh1.t_client.STATUS as \'ybrhh1.t_client.IS_DELETED\',ybrhh1.t_client.CREATE_DT as \'ybrhh1.t_client.CREATE_TIME\',ybrhh1.t_client_detailinfo.EMAIL as \'ybrhh1.t_client_detailinfo.EMAIL\',ybrhh1.t_client.bdp_status as \'ybrhh1.t_client.bdp_status\'','{\'CERT_NO\': \'varchar\', \'USER_ID\': \'varchar\', \'NAME\': \'varchar\', \'HOME_PHONE_NO\': \'varchar\', \'CREATE_TIME\': \'datetime\', \'MARRY_STATUS\': \'int\', \'MOBILE_NO\': \'varchar\', \'ADDRESS\': \'varchar\', \'IS_DELETED\': \'int\', \'EMAIL\': \'varchar\'}','where ybrhh1.t_client.bdp_updated_time>=%s or ybrhh1.t_client_detailinfo.bdp_updated_time>=%s','个人参与者基本信息',1,'ybrhh1.t_client.MARRY_STATUS','ybrhh1.t_client left join ybrhh1.t_client_detailinfo on ybrhh1.t_client.CLIENT_ID=ybrhh1.t_client_detailinfo.CLIENT_ID ','USER_ID'),(2,'ybrhh1.t_client','odsybr.ODS_PTY_USER_EDU','ybrhh1.t_client.EDUCATION as \'ybrhh1.t_client.EDUCATION\',ybrhh1.t_client.CLIENT_ID as \'ybrhh1.t_client.USER_ID\',ybrhh1.t_client.bdp_status as \'ybrhh1.t_client.bdp_status\',ybrhh1.t_client.CREATE_DT as \'ybrhh1.t_client.CREATE_TIME\'','{\'EDUCATION\': \'int\', \'USER_ID\': \'varchar\', \'CREATE_TIME\': \'datetime\'}','where ybrhh1.t_client.bdp_updated_time>=%s','个人参与者教育信息',1,'ybrhh1.t_client.EDUCATION','ybrhh1.t_client','USER_ID'),(3,'ybrhh1.t_client,ybrhh1.t_client_detailinfo,ybrhh1.t_client_unit','odsybr.ODS_PTY_USER_WORK','ybrhh1.t_client_unit.UNIT_TEL as \'ybrhh1.t_client_unit.COMPANY_PHONE_NO\',ybrhh1.t_client_unit.UNIT_TYPE as \'ybrhh1.t_client_unit.COMPANY_TYPE\',ybrhh1.t_client_unit.UNIT_ADDRESS as \'ybrhh1.t_client_unit.COMPANY_ADDRESS\',ybrhh1.t_client_unit.UNIT_CITY as \'ybrhh1.t_client_unit.CITY\',ybrhh1.t_client_detailinfo.DUTIES as \'ybrhh1.t_client_detailinfo.POSITION\',ybrhh1.t_client_detailinfo.bdp_status as \'ybrhh1.t_client_detailinfo.bdp_status\',ybrhh1.t_client.EARNINGS as \'ybrhh1.t_client.ANNUAL_INCOME\',ybrhh1.t_client.CLIENT_ID as \'ybrhh1.t_client.USER_ID\',ybrhh1.t_client_detailinfo.WORK_YEAR as \'ybrhh1.t_client_detailinfo.WORK_YEAR\',ybrhh1.t_client.bdp_status as \'ybrhh1.t_client.bdp_status\',ybrhh1.t_client_unit.UNIT_NAME as \'ybrhh1.t_client_unit.COMPANY_NAME\',ybrhh1.t_client_unit.UNIT_COUNTY as \'ybrhh1.t_client_unit.AREA\',ybrhh1.t_client_unit.UNIT_PROVINCE as \'ybrhh1.t_client_unit.PROVINCE\',ybrhh1.t_client_unit.bdp_status as \'ybrhh1.t_client_unit.bdp_status\'','{\'PROVINCE\': \'varchar\', \'CITY\': \'varchar\', \'COMPANY_PHONE_NO\': \'varchar\', \'ANNUAL_INCOME\': \'varchar\', \'AREA\': \'varchar\', \'COMPANY_TYPE\': \'int\', \'WORK_YEAR\': \'int\', \'USER_ID\': \'varchar\', \'COMPANY_NAME\': \'varchar\', \'COMPANY_ADDRESS\': \'varchar\', \'POSITION\': \'varchar\'}','where ybrhh1.t_client.bdp_updated_time>=%s or ybrhh1.t_client_detailinfo.bdp_updated_time>=%s or ybrhh1.t_client_unit.bdp_updated_time>=%s','个人参与者职业信息',1,'ybrhh1.t_client_unit.COMPANY_TYPE,ybrhh1.t_client_detailinfo.WORK_YEAR','ybrhh1.t_client left join ybrhh1.t_client_detailinfo on ybrhh1.t_client.CLIENT_ID=ybrhh1.t_client_detailinfo.CLIENT_ID left join ybrhh1.t_client_unit on ybrhh1.t_client.CLIENT_ID=ybrhh1.t_client_unit.CLIENT_ID ','USER_ID'),(4,'ybrhh1.t_client_kinfolk','odsybr.ODS_PTY_USER_CONTACT','ybrhh1.t_client_kinfolk.KINFOLK_MOBILE as \'ybrhh1.t_client_kinfolk.CONTACT_MOBILE_NO\',ybrhh1.t_client_kinfolk.KINFOLK_NAME as \'ybrhh1.t_client_kinfolk.CONTACT_NAME\',ybrhh1.t_client_kinfolk.CLIENT_ID as \'ybrhh1.t_client_kinfolk.USER_ID\',ybrhh1.t_client_kinfolk.KINFOLK_ID as \'ybrhh1.t_client_kinfolk.USER_CONTACT_ID\',ybrhh1.t_client_kinfolk.bdp_status as \'ybrhh1.t_client_kinfolk.bdp_status\',ybrhh1.t_client_kinfolk.FLAG as \'ybrhh1.t_client_kinfolk.DATA_FROM\',ybrhh1.t_client_kinfolk.RELATIVE as \'ybrhh1.t_client_kinfolk.CONTACT_RELATION\'','{\'USER_ID\': \'varchar\', \'CONTACT_MOBILE_NO\': \'varchar\', \'CONTACT_RELATION\': \'int\', \'CONTACT_NAME\': \'varchar\', \'DATA_FROM\': \'int\', \'USER_CONTACT_ID\': \'varchar\'}','where ybrhh1.t_client_kinfolk.bdp_updated_time>=%s','个人参与者联系人信息',1,'ybrhh1.t_client_kinfolk.CONTACT_RELATION','ybrhh1.t_client_kinfolk','USER_CONTACT_ID'),(5,'ybrhh1.t_client_bankcard','odsybr.ODS_PTY_USER_BINDCARD','ybrhh1.t_client_bankcard.BANK_CARD_NO as \'ybrhh1.t_client_bankcard.CARD_NO\',ybrhh1.t_client_bankcard.CLIENT_ID as \'ybrhh1.t_client_bankcard.USER_ID\',ybrhh1.t_client_bankcard.BANKCARD_ID as \'ybrhh1.t_client_bankcard.BIND_CARD_ID\',ybrhh1.t_client_bankcard.bdp_status as \'ybrhh1.t_client_bankcard.bdp_status\',ybrhh1.t_client_bankcard.CARD_TYPE as \'ybrhh1.t_client_bankcard.CARD_TYPE\',ybrhh1.t_client_bankcard.bchcde as \'ybrhh1.t_client_bankcard.BCHCDE\',ybrhh1.t_client_bankcard.CARD_MOBILE as \'ybrhh1.t_client_bankcard.PRE_MOBILE\',ybrhh1.t_client_bankcard.BANK_NO as \'ybrhh1.t_client_bankcard.BANK_ID\'','{\'USER_ID\': \'varchar\', \'PRE_MOBILE\': \'varchar\', \'BANK_ID\': \'varchar\', \'CARD_TYPE\': \'varchar\', \'BCHCDE\': \'varchar\', \'BIND_CARD_ID\': \'varchar\', \'CARD_NO\': \'varchar\'}','where ybrhh1.t_client_bankcard.bdp_updated_time>=%s','个人参与者绑卡信息',1,'','ybrhh1.t_client_bankcard','BIND_CARD_ID'),(6,'ybrhh1.t_client_detailinfo','odsybr.ODS_PTY_USER_ASSET','ybrhh1.t_client_detailinfo.HOUSE_BELONG as \'ybrhh1.t_client_detailinfo.OWNER_SHIP\',ybrhh1.t_client_detailinfo.HOUSE_CHARACTER as \'ybrhh1.t_client_detailinfo.HOUSE_PROPERTY\',ybrhh1.t_client_detailinfo.CLIENT_ID as \'ybrhh1.t_client_detailinfo.USER_ID\',ybrhh1.t_client_detailinfo.bdp_status as \'ybrhh1.t_client_detailinfo.bdp_status\'','{\'USER_ID\': \'varchar\', \'HOUSE_PROPERTY\': \'int\', \'OWNER_SHIP\': \'int\'}','where ybrhh1.t_client_detailinfo.bdp_updated_time>=%s','个人参与者资产信息',1,'ybrhh1.t_client_detailinfo.OWNER_SHIP,ybrhh1.t_client_detailinfo.HOUSE_PROPERTY','ybrhh1.t_client_detailinfo','USER_ID'),(7,'ybrhh1.t_manager,ybrhh1.t_manager_role','odsybr.ODS_PTY_ACCOUNT_MANAGER','ybrhh1.t_manager_role.bdp_status as \'ybrhh1.t_manager_role.bdp_status\',ybrhh1.t_manager_role.ROLE_DESC as \'ybrhh1.t_manager_role.ROLE_DESC\',ybrhh1.t_manager.MANAGER_ID as \'ybrhh1.t_manager.MANAGER_ID\',ybrhh1.t_manager.CHARGE_COUNTY as \'ybrhh1.t_manager.CHARGE_COUNTY\',ybrhh1.t_manager.CHARGE_CITY as \'ybrhh1.t_manager.CHARGE_CITY\',ybrhh1.t_manager_role.ROLE_NAME as \'ybrhh1.t_manager_role.ROLE_NAME\',ybrhh1.t_manager.bdp_status as \'ybrhh1.t_manager.bdp_status\',ybrhh1.t_manager.PASSWORD as \'ybrhh1.t_manager.PASSWORD\',ybrhh1.t_manager.MANAGER_NAME as \'ybrhh1.t_manager.MANAGER_NAME\',ybrhh1.t_manager.CHARGE_PROVINCE as \'ybrhh1.t_manager.CHARGE_PROVINCE\',ybrhh1.t_manager.MOBILE as \'ybrhh1.t_manager.MOBILE\'','{\'CHARGE_CITY\': \'varchar\', \'MOBILE\': \'varchar\', \'MANAGER_NAME\': \'varchar\', \'ROLE_DESC\': \'varchar\', \'ROLE_NAME\': \'varchar\', \'CHARGE_COUNTY\': \'varchar\', \'MANAGER_ID\': \'varchar\', \'PASSWORD\': \'varchar\', \'CHARGE_PROVINCE\': \'varchar\'}','where ybrhh1.t_manager.bdp_updated_time>=%s or ybrhh1.t_manager_role.bdp_updated_time>=%s','客户经理表',1,'',' ybrhh1.t_manager left join ybrhh1.t_manager_role on ybrhh1.t_manager.ROLE_ID=ybrhh1.t_manager_role.ROLE_ID ','MANAGER_ID'),(8,'ybrhh1.t_client','odsybr.ODS_PTY_USER_BIZ_RELATION','ybrhh1.t_client.CLIENT_ID as \'ybrhh1.t_client.USER_ID\',2 as \'ybrhh1.t_client.BIZ_TYPE\'','{\'BIZ_TYPE\': \'varchar\', \'USER_ID\': \'varchar\'}','where t_client.bdp_updated_time>=%s','参与者业务关联表',1,'','ybrhh1.t_client','USER_ID'),(9,'ybrhh1.t_client_accountinfo','odsybr.ODS_RIC_CREDIT_ENHANCE','ybrhh1.t_client_accountinfo.bdp_status as \'ybrhh1.t_client_accountinfo.bdp_status\',ybrhh1.t_client_accountinfo.JD_ACCOUNT as \'ybrhh1.t_client_accountinfo.JD_ACCOUNT\',ybrhh1.t_client_accountinfo.CLIENT_ID as \'ybrhh1.t_client_accountinfo.USER_ID\',ybrhh1.t_client_accountinfo.SECURITY_ACCOUNT as \'ybrhh1.t_client_accountinfo.SECURITY_ACCOUNT\',ybrhh1.t_client_accountinfo.JD_PWD as \'ybrhh1.t_client_accountinfo.JD_PWD\',ybrhh1.t_client_accountinfo.FUND_ACCOUNT as \'ybrhh1.t_client_accountinfo.FUND_ACCOUNT\',ybrhh1.t_client_accountinfo.SECURITY_PWD as \'ybrhh1.t_client_accountinfo.SECURITY_PWD\',ybrhh1.t_client_accountinfo.STATUS_ID as \'ybrhh1.t_client_accountinfo.OPERATOR_STATUS\',ybrhh1.t_client_accountinfo.FUND_PWD as \'ybrhh1.t_client_accountinfo.FUND_PWD\',ybrhh1.t_client_accountinfo.SERVICE_PWD as \'ybrhh1.t_client_accountinfo.OPERATOR_SERVICE_PWD\',ybrhh1.t_client_accountinfo.USER_ID as \'ybrhh1.t_client_accountinfo.OPERATOR_USER_ID\'','{\'OPERATOR_STATUS\': \'varchar\', \'USER_ID\': \'varchar\', \'FUND_ACCOUNT\': \'varchar\', \'SECURITY_ACCOUNT\': \'varchar\', \'JD_PWD\': \'varchar\', \'OPERATOR_SERVICE_PWD\': \'varchar\', \'OPERATOR_USER_ID\': \'varchar\', \'JD_ACCOUNT\': \'varchar\', \'FUND_PWD\': \'varchar\', \'SECURITY_PWD\': \'varchar\'}','where ybrhh1.t_client_accountinfo.bdp_updated_time>=%s','客户增信信息表',1,'','ybrhh1.t_client_accountinfo','USER_ID'),(10,'ybrhh1.t_appl','odsybr.ODS_EVT_APPLY','ybrhh1.t_appl.creditScore as \'ybrhh1.t_appl.CREDIT_SCORE\',ybrhh1.t_appl.creditRate as \'ybrhh1.t_appl.CREDIT_RATE\',ybrhh1.t_appl.Final_Decision as \'ybrhh1.t_appl.FINAL_DECISION\',ybrhh1.t_appl.creditDate as \'ybrhh1.t_appl.CREDIT_DATE\',ybrhh1.t_appl.CREATE_DT as \'ybrhh1.t_appl.CREATE_DATE\',ybrhh1.t_appl.Decision_Reason as \'ybrhh1.t_appl.DECISION_REASON\',ybrhh1.t_appl.bdp_status as \'ybrhh1.t_appl.bdp_status\',ybrhh1.t_appl.LAST_CHG_DT as \'ybrhh1.t_appl.UPDATE_DATE\',ybrhh1.t_appl.CLIENT_ID as \'ybrhh1.t_appl.USER_ID\',ybrhh1.t_appl.APPLY_CODE as \'ybrhh1.t_appl.APPLY_ID\',ybrhh1.t_appl.LIMIT as \'ybrhh1.t_appl.CREDIT_LIMIT\',ybrhh1.t_appl.CREDIT_CARD as \'ybrhh1.t_appl.CREDIT_CARD_NO\',ybrhh1.t_appl.PROCESS as \'ybrhh1.t_appl.PROCESS\',ybrhh1.t_appl.LIMIT_STATUS as \'ybrhh1.t_appl.IS_ACT_AMT\',ybrhh1.t_appl.LIMIT_START_DATE as \'ybrhh1.t_appl.LIMIT_START_DATE\',ybrhh1.t_appl.STATUS as \'ybrhh1.t_appl.IS_DELETED\',ybrhh1.t_appl.creditHighest as \'ybrhh1.t_appl.HIGHEST_CREDIT\',ybrhh1.t_appl.LIMIT_END_DATE as \'ybrhh1.t_appl.LIMIT_END_DATE\'','{\'IS_ACT_AMT\': \'int\', \'UPDATE_DATE\': \'datetime\', \'CREDIT_LIMIT\': \'varchar\', \'CREATE_DATE\': \'datetime\', \'CREDIT_CARD_NO\': \'varchar\', \'CREDIT_SCORE\': \'varchar\', \'DECISION_REASON\': \'varchar\', \'LIMIT_END_DATE\': \'datetime\', \'IS_DELETED\': \'int\', \'CREDIT_RATE\': \'varchar\', \'PROCESS\': \'int\', \'LIMIT_START_DATE\': \'datetime\', \'APPLY_ID\': \'varchar\', \'CREDIT_DATE\': \'datetime\', \'HIGHEST_CREDIT\': \'int\', \'USER_ID\': \'varchar\', \'FINAL_DECISION\': \'varchar\'}','where ybrhh1.t_appl.bdp_updated_time>=%s','进件事件表',1,'ybrhh1.t_appl.PROCESS','ybrhh1.t_appl','APPLY_ID'),(11,'ybrhh1.t_client_signrecord','odsybr.ODS_EVT_SIGNRECORD','ybrhh1.t_client_signrecord.ACTIVE_SERNO as \'ybrhh1.t_client_signrecord.ACTIVE_SERIAL_ID\',ybrhh1.t_client_signrecord.Ha_manager_id as \'ybrhh1.t_client_signrecord.HA_MANAGER_ID\',ybrhh1.t_client_signrecord.COUNTY as \'ybrhh1.t_client_signrecord.COUNTY\',ybrhh1.t_client_signrecord.ADDRESS as \'ybrhh1.t_client_signrecord.ADDRESS\',ybrhh1.t_client_signrecord.EXPLAINS as \'ybrhh1.t_client_signrecord.EXPLAINS\',ybrhh1.t_client_signrecord.SIGN_LAT as \'ybrhh1.t_client_signrecord.SIGN_LAT\',ybrhh1.t_client_signrecord.MANAGER_ID as \'ybrhh1.t_client_signrecord.MANAGER_ID\',ybrhh1.t_client_signrecord.DATETIME as \'ybrhh1.t_client_signrecord.DATETIME\',ybrhh1.t_client_signrecord.PROVINCE as \'ybrhh1.t_client_signrecord.PROVINCE\',ybrhh1.t_client_signrecord.CITY as \'ybrhh1.t_client_signrecord.CITY\',ybrhh1.t_client_signrecord.OCR_legality as \'ybrhh1.t_client_signrecord.OCR_LEGALITY\',ybrhh1.t_client_signrecord.ACTIVE_DT as \'ybrhh1.t_client_signrecord.ACTIVE_DATE\',ybrhh1.t_client_signrecord.Ha_manager_name as \'ybrhh1.t_client_signrecord.HA_MANAGER_NAME\',ybrhh1.t_client_signrecord.APPLICATION_NUMBER as \'ybrhh1.t_client_signrecord.APPLICATION_NUMBER\',ybrhh1.t_client_signrecord.SIGN_LON as \'ybrhh1.t_client_signrecord.SIGN_LON\',ybrhh1.t_client_signrecord.ACTIVATE_LAT as \'ybrhh1.t_client_signrecord.ACTIVATE_LAT\',ybrhh1.t_client_signrecord.PURPOSE as \'ybrhh1.t_client_signrecord.PURPOSE\',ybrhh1.t_client_signrecord.MSSIND as \'ybrhh1.t_client_signrecord.MSSIND\',ybrhh1.t_client_signrecord.APPLY_CODE as \'ybrhh1.t_client_signrecord.APPLY_ID\',ybrhh1.t_client_signrecord.MPORDER_ID as \'ybrhh1.t_client_signrecord.MPORDER_ID\',ybrhh1.t_client_signrecord.bdp_status as \'ybrhh1.t_client_signrecord.bdp_status\',ybrhh1.t_client_signrecord.CLIENT_ID as \'ybrhh1.t_client_signrecord.CLIENT_ID\',ybrhh1.t_client_signrecord.SIGN_ID as \'ybrhh1.t_client_signrecord.SIGN_ID\',ybrhh1.t_client_signrecord.SIGN_STATUS as \'ybrhh1.t_client_signrecord.SIGN_STATUS\',ybrhh1.t_client_signrecord.ACTIVATE_LON as \'ybrhh1.t_client_signrecord.ACTIVATE_LON\',ybrhh1.t_client_signrecord.ORDER_DATE as \'ybrhh1.t_client_signrecord.ORDER_DATE\',ybrhh1.t_client_signrecord.ORDER_ID as \'ybrhh1.t_client_signrecord.ORDER_ID\',ybrhh1.t_client_signrecord.CONTRACT_NO as \'ybrhh1.t_client_signrecord.CONTRACT_ID\',ybrhh1.t_client_signrecord.UPDATE_DT as \'ybrhh1.t_client_signrecord.UPDATE_DATE\',ybrhh1.t_client_signrecord.SIGNRE_DT as \'ybrhh1.t_client_signrecord.SIGNRE_DATE\',ybrhh1.t_client_signrecord.REQUEST_DT as \'ybrhh1.t_client_signrecord.REQUEST_DATE\'','{\'PROVINCE\': \'varchar\', \'ACTIVE_DATE\': \'varchar\', \'APPLY_ID\': \'varchar\', \'CLIENT_ID\': \'varchar\', \'SIGN_ID\': \'varchar\', \'UPDATE_DATE\': \'datetime\', \'OCR_LEGALITY\': \'varchar\', \'MSSIND\': \'int\', \'REQUEST_DATE\': \'varchar\', \'ORDER_ID\': \'varchar\', \'HA_MANAGER_NAME\': \'varchar\', \'ACTIVATE_LAT\': \'varchar\', \'SIGN_LAT\': \'varchar\', \'EXPLAINS\': \'varchar\', \'SIGN_LON\': \'varchar\', \'ACTIVATE_LON\': \'int\', \'DATETIME\': \'datetime\', \'COUNTY\': \'varchar\', \'ACTIVE_SERIAL_ID\': \'varchar\', \'SIGNRE_DATE\': \'varchar\', \'MANAGER_ID\': \'varchar\', \'SIGN_STATUS\': \'int\', \'HA_MANAGER_ID\': \'varchar\', \'CITY\': \'varchar\', \'APPLICATION_NUMBER\': \'varchar\', \'CONTRACT_ID\': \'varchar\', \'PURPOSE\': \'varchar\', \'ADDRESS\': \'varchar\', \'ORDER_DATE\': \'varchar\', \'MPORDER_ID\': \'varchar\'}','where ybrhh1.t_client_signrecord.bdp_updated_time>=%s','面签记录表',1,'ybrhh1.t_client_signrecord.SIGN_STATUS','ybrhh1.t_client_signrecord','SIGN_ID');

/*Table structure for table `ETL_ENUM_CFG` */

DROP TABLE IF EXISTS `ETL_ENUM_CFG`;

CREATE TABLE `ETL_ENUM_CFG` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `source_tb_name` varchar(50) NOT NULL,
  `target_tb_name` varchar(50) NOT NULL,
  `source_columns` varchar(50) NOT NULL,
  `source_db` varchar(50) NOT NULL,
  `target_columns` varchar(50) NOT NULL,
  `source_value` varchar(50) NOT NULL,
  `target_value` varchar(50) NOT NULL,
  `target_tb_comment` varchar(50) DEFAULT NULL,
  `target_columns_comment` varchar(50) DEFAULT NULL,
  `target_value_comment` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=475 DEFAULT CHARSET=utf8;

/*Data for the table `ETL_ENUM_CFG` */

insert  into `ETL_ENUM_CFG`(`id`,`source_tb_name`,`target_tb_name`,`source_columns`,`source_db`,`target_columns`,`source_value`,`target_value`,`target_tb_comment`,`target_columns_comment`,`target_value_comment`) values (1,'sellbiz_sell_vchr','ODS_EVT_SELL','SELL_TYPE','bizybr','SELL_EVENT_TYPE','1','1','卖出事件','卖出事件类型','转让单'),(2,'usercore_user_personal','ODS_PTY_USER_INFO','MARRY_STATUS','coreybr','MARRY_STATUS','0','1','个人参与者基本信息','婚姻状况','已婚'),(3,'sellbiz_sell_vchr','ODS_EVT_SELL','SELL_TYPE','bizybr','SELL_EVENT_TYPE','3','3','卖出事件','卖出事件类型','融资单'),(4,'sellbiz_sell_vchr','ODS_EVT_SELL','PRODUCT_TYPE','bizybr','PRODUCT_TYPE','0','1','卖出事件','投资产品类型','默认'),(5,'sellbiz_purchase_vchr','ODS_EVT_PURCHASE','PURCHASE_STATUS','bizybr','PURCHASE_STATUS','4','4','申购事件','申购单状态','部分成交，部分流标'),(6,'sellbiz_purchase_vchr','ODS_EVT_PURCHASE','PURCHASE_STATUS','bizybr','PURCHASE_STATUS','5','5','申购事件','申购单状态','全部流标'),(7,'sellbiz_sell_vchr','ODS_EVT_SELL','USER_ROLE','bizybr','USER_ROLE','0','1','卖出事件','用户角色','个人'),(8,'sellbiz_sell_vchr','ODS_EVT_SELL','USER_ROLE','bizybr','USER_ROLE','1','2','卖出事件','用户角色','机构'),(9,'sellbiz_sell_vchr','ODS_EVT_SELL','PRODUCT_TYPE','bizybr','PRODUCT_TYPE','8','2','卖出事件','投资产品类型','活期理财'),(10,'sellbiz_sell_vchr','ODS_EVT_SELL','PRODUCT_TYPE','bizybr','PRODUCT_TYPE','9','3','卖出事件','投资产品类型','定期理财'),(11,'usercore_user_register','ODS_EVT_REGISTER','STATUS','coreybr','USRE_STATUS','1','2','注册事件表','用户状态','冻结'),(12,'usercore_login_record','ODS_EVT_LOGIN','STATUS','coreybr','LOGIN_STATUS','0','1','登陆事件表','登录状态','成功'),(13,'usercore_user_register','ODS_EVT_REGISTER','USER_LEVEL','coreybr','USER_LEVEL','1','1','注册事件表','会员级别','普通会员'),(14,'usercore_user_register','ODS_EVT_REGISTER','STATUS','coreybr','USRE_STATUS','0','1','注册事件表','用户状态','正常'),(15,'usercore_user_register','ODS_EVT_REGISTER','SEC_LEVEL','coreybr','SEC_LEVEL','2','2','注册事件表','安全等级','中'),(16,'usercore_user_register','ODS_EVT_REGISTER','SEC_LEVEL','coreybr','SEC_LEVEL','3','3','注册事件表','安全等级','高'),(17,'usercore_user_register','ODS_EVT_REGISTER','IF_PAYPWD','coreybr','IS_PAYPWD','1','1','注册事件表','是否设置交易密码','已设置交易密码'),(18,'usercore_user_register','ODS_EVT_REGISTER','SEC_LEVEL','coreybr','SEC_LEVEL','1','1','注册事件表','安全等级','低'),(19,'usercore_user_register','ODS_EVT_REGISTER','IF_FIRSTBUY','coreybr','IS_FIRSTBUY','1','1','注册事件表','是否首次购买','是首次购买'),(20,'usercore_user_register','ODS_EVT_REGISTER','IF_PAYPWD','coreybr','IS_PAYPWD','0','0','注册事件表','是否设置交易密码','未设置交易密码'),(21,'sellbiz_sell_vchr','ODS_AGT_SELL_VCHR','PRODUCT_TYPE','bizybr','PRODUCT_TYPE','8','2','卖出单据','投资产品类型','活期理财'),(22,'sellbiz_sell_vchr','ODS_AGT_SELL_VCHR','PRODUCT_TYPE','bizybr','PRODUCT_TYPE','0','1','卖出单据','投资产品类型','默认'),(23,'sellbiz_sell_vchr','ODS_AGT_SELL_VCHR','SELL_TYPE','bizybr','SELL_TYPE','1','1','卖出单据','卖出单类型','转让单'),(24,'sellbiz_purchase_vchr','ODS_AGT_PURCHASE_VCHR','PURCHASE_STATUS','bizybr','IS_AUTO','1','1','申购单据','是否自动','是'),(25,'sellbiz_sell_vchr','ODS_AGT_SELL_VCHR','SELL_TYPE','bizybr','SELL_TYPE','3','3','卖出单据','卖出单类型','融资单'),(26,'sellbiz_sell_vchr','ODS_AGT_SELL_VCHR','SELL_TYPE','bizybr','SELL_TYPE','2','2','卖出单据','卖出单类型','回购单'),(27,'sellbiz_purchase_vchr','ODS_AGT_PURCHASE_VCHR','PURCHASE_STATUS','bizybr','PURCHASE_STATUS','4','4','申购单据','申购单状态','部分成交，部分流标'),(28,'sellbiz_purchase_vchr','ODS_AGT_PURCHASE_VCHR','PURCHASE_STATUS','bizybr','PURCHASE_STATUS','3','3','申购单据','申购单状态','全部成交'),(29,'sellbiz_purchase_vchr','ODS_AGT_PURCHASE_VCHR','PURCHASE_STATUS','bizybr','IS_AUTO','0','0','申购单据','是否自动','否'),(30,'sellbiz_purchase_vchr','ODS_AGT_PURCHASE_VCHR','PURCHASE_STATUS','bizybr','PURCHASE_STATUS','5','5','申购单据','申购单状态','全部流标'),(31,'asset_acct_info','ODS_AGT_ACCOUNT','OWNER_TYPE','bizybr','OWNER_TYPE','1','2','账户表','属主类型','企业'),(32,'asset_acct_info','ODS_AGT_ACCOUNT','OWNER_TYPE','bizybr','OWNER_TYPE','2','3','账户表','属主类型','平台账户'),(33,'asset_acct_info','ODS_AGT_ACCOUNT','OPEN_ORG_TYPE','bizybr','OPEN_ORG_TYPE','1','1','账户表','帐户开户机构类型','平台'),(34,'asset_acct_info','ODS_AGT_ACCOUNT','OPEN_ORG_TYPE','bizybr','OPEN_ORG_TYPE','2','2','账户表','帐户开户机构类型','银行'),(35,'asset_acct_info','ODS_AGT_ACCOUNT','STATUS','bizybr','STATUS','0','1','账户表','账户状态','正常'),(36,'asset_acct_info','ODS_AGT_ACCOUNT','STATUS','bizybr','STATUS','1','2','账户表','账户状态','关闭'),(37,'asset_acct_info','ODS_AGT_ACCOUNT','STATUS','bizybr','STATUS','2','3','账户表','账户状态','冻结'),(38,'','ODS_AGT_ACCOUNT','','','ACCOUNT_BIZ_TYPE','','1A','账户表','业务类型','P2P借款业务'),(39,'','ODS_AGT_ACCOUNT','','','ACCOUNT_BIZ_TYPE','','1B','账户表','业务类型','P2P投资业务'),(40,'','ODS_AGT_ACCOUNT','','','ACCOUNT_BIZ_TYPE','','2','账户表','业务类型','哈行信用卡业务'),(41,'t_appl','ODS_EVT_APPLY','Decision_Reason','ybrhh1','DECISION_REASON','A874','A1','进件事件表','原因描述代码','核准'),(42,'t_appl','ODS_EVT_APPLY','PROCESS','ybrhh1','PROCESS','1111111111','11','进件事件表','授信进度','面签完成'),(43,'t_appl','ODS_EVT_APPLY','PROCESS','ybrhh1','PROCESS','1111100000','6','进件事件表','授信进度','银行卡'),(44,'t_appl','ODS_EVT_APPLY','PROCESS','ybrhh1','PROCESS','1111000000','5','进件事件表','授信进度','联系人信息保存'),(45,'t_appl','ODS_EVT_APPLY','PROCESS','ybrhh1','PROCESS','1110000000','4','进件事件表','授信进度','公司信息保存'),(46,'t_appl','ODS_EVT_APPLY','PROCESS','ybrhh1','PROCESS','1100000000','3','进件事件表','授信进度','个人信息保存'),(47,'t_appl','ODS_EVT_APPLY','PROCESS','ybrhh1','PROCESS','1111111110','10','进件事件表','授信进度','预约面签'),(48,'t_appl','ODS_EVT_APPLY','PROCESS','ybrhh1','PROCESS','1111111100','9','进件事件表','授信进度','哈行终审通过'),(49,'t_appl','ODS_EVT_APPLY','PROCESS','ybrhh1','PROCESS','1111111000','8','进件事件表','授信进度','提交哈行授信成功'),(50,'t_appl','ODS_EVT_APPLY','PROCESS','ybrhh1','PROCESS','1111110000','7','进件事件表','授信进度','增信'),(51,'usercore_user_bindcards','ODS_PTY_USER_BINDCARD','STATUS','coreybr','BIND_STATUS','5','6','个人参与者绑卡信息','绑卡状态','绑卡处理中'),(52,'usercore_user_bindcards','ODS_PTY_USER_BINDCARD','STATUS','coreybr','BIND_STATUS','6','7','个人参与者绑卡信息','绑卡状态','解绑处理中'),(53,'usercore_user_bindcards','ODS_PTY_USER_BINDCARD','IS_DEFAULT','coreybr','IS_DEFAULT','1','1','个人参与者绑卡信息','是否默认','是'),(54,'usercore_user_bindcards','ODS_PTY_USER_BINDCARD','STATUS','coreybr','BIND_STATUS','0','1','个人参与者绑卡信息','绑卡状态','未绑定'),(55,'usercore_user_bindcards','ODS_PTY_USER_BINDCARD','CURRENCY','coreybr','CURRENCY','OTH','OTH','个人参与者绑卡信息','币种','其它'),(56,'usercore_user_bindcards','ODS_PTY_USER_BINDCARD','IS_DEFAULT','coreybr','IS_DEFAULT','0','0','个人参与者绑卡信息','是否默认','否'),(57,'usercore_user_bindcards','ODS_PTY_USER_BINDCARD','STATUS','coreybr','BIND_STATUS','3','4','个人参与者绑卡信息','绑卡状态','默认'),(58,'usercore_user_bindcards','ODS_PTY_USER_BINDCARD','STATUS','coreybr','BIND_STATUS','4','5','个人参与者绑卡信息','绑卡状态','验证码'),(59,'usercore_user_bindcards','ODS_PTY_USER_BINDCARD','STATUS','coreybr','BIND_STATUS','1','2','个人参与者绑卡信息','绑卡状态','已绑定'),(60,'usercore_user_bindcards','ODS_PTY_USER_BINDCARD','STATUS','coreybr','BIND_STATUS','2','3','个人参与者绑卡信息','绑卡状态','解绑'),(61,'usercore_user_accessory','ODS_PTY_USER_ACCESSORY','TYPE','coreybr','CERT_TYPE','2','3','个人参与者附件资料','附加证件类型','税务登记证代码'),(62,'usercore_user_accessory','ODS_PTY_USER_ACCESSORY','TYPE','coreybr','CERT_TYPE','1','2','个人参与者附件资料','附加证件类型','组织机构代码'),(63,'userbiz_house','ODS_PTY_USER_ASSET','OWNER_SHIP','bizybr','OWNER_SHIP','3','4','个人参与者资产信息','所有权','企业或企业股东'),(64,'userbiz_house','ODS_PTY_USER_ASSET','OWNER_SHIP','bizybr','OWNER_SHIP','2','3','个人参与者资产信息','所有权','本人或配偶的父母'),(65,'userbiz_house','ODS_PTY_USER_ASSET','OWNER_SHIP','bizybr','OWNER_SHIP','1','2','个人参与者资产信息','所有权','成年子女'),(66,'userbiz_house','ODS_PTY_USER_ASSET','OWNER_SHIP','bizybr','OWNER_SHIP','0','1','个人参与者资产信息','所有权','本人或者配偶'),(67,'usercore_user_accessory','ODS_PTY_USER_ACCESSORY','TYPE','coreybr','CERT_TYPE','0','1','个人参与者附件资料','附加证件类型','营业执照代码'),(68,'userbiz_house','ODS_PTY_USER_ASSET','HOUSE_PROPERTY','bizybr','HOUSE_PROPERTY','1','2','个人参与者资产信息','房屋性质','住宅'),(69,'userbiz_house','ODS_PTY_USER_ASSET','HOUSE_PROPERTY','bizybr','HOUSE_PROPERTY','0','1','个人参与者资产信息','房屋性质','商用'),(70,'userbiz_house','ODS_PTY_USER_ASSET','OWNER_SHIP','bizybr','OWNER_SHIP','4','99','个人参与者资产信息','所有权','其它'),(71,'t_appl','ODS_EVT_APPLY','PROCESS','ybrhh1','PROCESS','0000000000','1','进件事件表','授信进度','初始状态'),(72,'t_appl','ODS_EVT_APPLY','PROCESS','ybrhh1','PROCESS','1000000000','2','进件事件表','授信进度','授权信息'),(73,'t_appl','ODS_EVT_APPLY','LIMIT_STATUS','ybrhh1','IS_ACT_AMT','0','0','进件事件表','是否实际额度','预授信额度'),(74,'t_appl','ODS_EVT_APPLY','LIMIT_STATUS','ybrhh1','IS_ACT_AMT','1','1','进件事件表','是否实际额度','实际额度'),(75,'t_client_detailinfo','ODS_PTY_USER_ASSET','HOUSE_CHARACTER','ybrhh1','HOUSE_PROPERTY','2','3','个人参与者资产信息','房屋性质','商住两用'),(76,'t_client_detailinfo','ODS_PTY_USER_ASSET','HOUSE_CHARACTER','ybrhh1','HOUSE_PROPERTY','3','99','个人参与者资产信息','房屋性质','其它'),(77,'t_client_detailinfo','ODS_PTY_USER_ASSET','HOUSE_BELONG','ybrhh1','OWNER_SHIP','6','99','个人参与者资产信息','所有权','其它'),(78,'t_client_detailinfo','ODS_PTY_USER_ASSET','HOUSE_CHARACTER','ybrhh1','HOUSE_PROPERTY','1','2','个人参与者资产信息','房屋性质','住宅'),(79,'t_client_detailinfo','ODS_PTY_USER_ASSET','HOUSE_BELONG','ybrhh1','OWNER_SHIP','4','4','个人参与者资产信息','所有权','企业或企业股东'),(80,'t_client_detailinfo','ODS_PTY_USER_ASSET','HOUSE_BELONG','ybrhh1','OWNER_SHIP','5','5','个人参与者资产信息','所有权','租赁'),(81,'sellbiz_purchase_vchr','ODS_EVT_PURCHASE','PURCHASE_STATUS','bizybr','PURCHASE_STATUS','3','3','申购事件','申购单状态','全部成交'),(82,'sellbiz_purchase_vchr','ODS_EVT_PURCHASE','PURCHASE_STATUS','bizybr','PURCHASE_STATUS','2','2','申购事件','申购单状态','部分成交'),(83,'sellbiz_purchase_vchr','ODS_EVT_PURCHASE','PRODUCT_TYPE','bizybr','PRODUCT_TYPE','8','2','申购事件','投资产品类型','活期理财'),(84,'sellbiz_purchase_vchr','ODS_EVT_PURCHASE','PRODUCT_TYPE','bizybr','PRODUCT_TYPE','0','1','申购事件','投资产品类型','默认'),(85,'sellbiz_purchase_vchr','ODS_EVT_PURCHASE','PURCHASE_STATUS','bizybr','PURCHASE_STATUS','1','1','申购事件','申购单状态','申请未成交'),(86,'sellbiz_purchase_vchr','ODS_EVT_PURCHASE','PRODUCT_TYPE','bizybr','PRODUCT_TYPE','9','3','申购事件','投资产品类型','定期理财'),(87,'sellbiz_invest_vchr','ODS_EVT_INVEST','INVEST_STATUS','bizybr','INVEST_STATUS','7','8','投资事件','投资状态','支付处理中'),(88,'sellbiz_invest_vchr','ODS_EVT_INVEST','INVEST_STATUS','bizybr','INVEST_STATUS','6','7','投资事件','投资状态','支付失败'),(89,'sellbiz_purchase_vchr','ODS_EVT_PURCHASE','USER_ROLE','bizybr','USER_ROLE','1','2','申购事件','用户角色','机构'),(90,'sellbiz_purchase_vchr','ODS_EVT_PURCHASE','USER_ROLE','bizybr','USER_ROLE','0','1','申购事件','用户角色','个人'),(91,'sellbiz_sell_vchr','ODS_EVT_SELL','SELL_TYPE','bizybr','SELL_EVENT_TYPE','2','2','卖出事件','卖出事件类型','回购单'),(92,'usercore_user_personal','ODS_PTY_USER_INFO','SEX','coreybr','SEX','1','2','个人参与者基本信息','性别','女'),(93,'usercore_user_bindcards','ODS_PTY_USER_BINDCARD','CURRENCY','coreybr','CURRENCY','THB','THB','个人参与者绑卡信息','币种','泰铢'),(94,'usercore_user_bindcards','ODS_PTY_USER_BINDCARD','CURRENCY','coreybr','CURRENCY','SGD','SGD','个人参与者绑卡信息','币种','新加坡元'),(95,'usercore_user_bindcards','ODS_PTY_USER_BINDCARD','CURRENCY','coreybr','CURRENCY','ATS','ATS','个人参与者绑卡信息','币种','奥地利先令'),(96,'usercore_user_bindcards','ODS_PTY_USER_BINDCARD','CURRENCY','coreybr','CURRENCY','AUD','AUD','个人参与者绑卡信息','币种','澳大利亚元'),(97,'usercore_user_bindcards','ODS_PTY_USER_BINDCARD','CURRENCY','coreybr','CURRENCY','ITL','ITL','个人参与者绑卡信息','币种','意大利里拉'),(98,'usercore_user_bindcards','ODS_PTY_USER_BINDCARD','CURRENCY','coreybr','CURRENCY','BEF','BEF','个人参与者绑卡信息','币种','比利时法郎'),(99,'usercore_user_bindcards','ODS_PTY_USER_BINDCARD','CURRENCY','coreybr','CURRENCY','ESP','ESP','个人参与者绑卡信息','币种','西班牙比塞塔'),(100,'usercore_user_bindcards','ODS_PTY_USER_BINDCARD','CURRENCY','coreybr','CURRENCY','NLG','NLG','个人参与者绑卡信息','币种','荷兰盾'),(101,'usercore_user_bindcards','ODS_PTY_USER_BINDCARD','CURRENCY','coreybr','CURRENCY','PHP','PHP','个人参与者绑卡信息','币种','菲律宾比索'),(102,'usercore_user_bindcards','ODS_PTY_USER_BINDCARD','CURRENCY','coreybr','CURRENCY','MYR','MYR','个人参与者绑卡信息','币种','马来西亚林吉特'),(103,'asset_acct_info','ODS_AGT_ACCOUNT','ACCT_APPLICA','bizybr','ACCT_TYPE','23','10','账户表','账户类型','平台商户费用账户'),(104,'asset_acct_info','ODS_AGT_ACCOUNT','ACCT_APPLICA','bizybr','ACCT_TYPE','24','11','账户表','账户类型','平台商户自营账户'),(105,'asset_acct_info','ODS_AGT_ACCOUNT','ACCT_APPLICA','bizybr','ACCT_TYPE','15','5','账户表','账户类型','用户还款账户'),(106,'asset_acct_info','ODS_AGT_ACCOUNT','ACCT_APPLICA','bizybr','ACCT_TYPE','20','7','账户表','账户类型','平台商户往来过度户'),(107,'asset_acct_info','ODS_AGT_ACCOUNT','ACCT_APPLICA','bizybr','ACCT_TYPE','21','8','账户表','账户类型','平台商户红包账户'),(108,'asset_acct_info','ODS_AGT_ACCOUNT','ACCT_APPLICA','bizybr','ACCT_TYPE','22','9','账户表','账户类型','平台商户收入账户'),(109,'asset_acct_info','ODS_AGT_ACCOUNT','ACCT_APPLICA','bizybr','ACCT_TYPE','11','1','账户表','账户类型','用户理财账户'),(110,'asset_acct_info','ODS_AGT_ACCOUNT','ACCT_APPLICA','bizybr','ACCT_TYPE','12','2','账户表','账户类型','用户红包账户'),(111,'asset_acct_info','ODS_AGT_ACCOUNT','ACCT_APPLICA','bizybr','ACCT_TYPE','13','3','账户表','账户类型','用户积分账户'),(112,'asset_acct_info','ODS_AGT_ACCOUNT','ACCT_APPLICA','bizybr','ACCT_TYPE','14','4','账户表','账户类型','用户借款账户'),(113,'usercore_user_personal','ODS_PTY_USER_INFO','MARRY_STATUS','coreybr','MARRY_STATUS','1','2','个人参与者基本信息','婚姻状况','未婚'),(114,'','ODS_PRD_PRODUCT_INFO','','','PRODUCT_CATEGORY','','3','产品信息表','产品类别','哈行信用卡'),(115,'','ODS_PRD_PRODUCT_INFO','','','PRODUCT_CATEGORY','','4','产品信息表','产品类别','小贷'),(116,'','ODS_PRD_PRODUCT_INFO','','','PRODUCT_CATEGORY','','1','产品信息表','产品类别','P2P'),(117,'','ODS_PRD_PRODUCT_INFO','','','PRODUCT_CATEGORY','','2','产品信息表','产品类别','抵押贷款'),(118,'','ODS_PTY_USER_BIZ_RELATION','','','BIZ_TYPE','','2','参与者业务关联表','参与业务类型','参与哈行业务'),(119,'','ODS_PTY_USER_BIZ_RELATION','','','BIZ_TYPE','','3','参与者业务关联表','参与业务类型','参与抵押贷款业务'),(120,'usercore_role','ODS_PTY_ROLE','DEF','coreybr','DEFAULT','1','1','角色','是否默认','是默认角色'),(121,'','ODS_PTY_USER_BIZ_RELATION','','','BIZ_TYPE','','1','参与者业务关联表','参与业务类型','参与P2P业务'),(122,'','ODS_PRD_PRODUCT_INFO','','','PRODUCT_CATEGORY','','99','产品信息表','产品类别','其它'),(123,'loan_product','ODS_PRD_P2P_PRODUCT_INFO','STATUS','bizybr','STATUS','1','1','P2P类产品信息表','产品状态','已创建'),(124,'usercore_user_business','ODS_PTY_AGENT_OPERATE','INDUSTRY_TYPE','coreybr','INDUSTRY_TYPE','j','20','机构参与者经营信息','行业类型','综合含投资类主业不明显'),(125,'usercore_user_business','ODS_PTY_AGENT_OPERATE','INDUSTRY_TYPE','coreybr','INDUSTRY_TYPE','i','1','机构参与者经营信息','行业类型','文化体育娱乐业'),(126,'usercore_user_business','ODS_PTY_AGENT_OPERATE','INDUSTRY_TYPE','coreybr','INDUSTRY_TYPE','h','18','机构参与者经营信息','行业类型','卫生社会保障和社会服务业'),(127,'usercore_user_business','ODS_PTY_AGENT_OPERATE','INDUSTRY_TYPE','coreybr','INDUSTRY_TYPE','g','17','机构参与者经营信息','行业类型','教育'),(128,'usercore_role','ODS_PTY_ROLE','STATUS','coreybr','STATUS','0','0','角色','是否停用','正常'),(129,'usercore_role','ODS_PTY_ROLE','ROLE_TYPE','coreybr','ROLE_TYPE','1','2','角色','角色类型','机构'),(130,'usercore_role','ODS_PTY_ROLE','ROLE_TYPE','coreybr','ROLE_TYPE','0','1','角色','角色类型','个人'),(131,'usercore_user_business','ODS_PTY_AGENT_OPERATE','INDUSTRY_TYPE','coreybr','INDUSTRY_TYPE','k','99','机构参与者经营信息','行业类型','其它'),(132,'usercore_role','ODS_PTY_ROLE','DEF','coreybr','DEFAULT','0','0','角色','是否默认','不是默认角色'),(133,'usercore_role','ODS_PTY_ROLE','STATUS','coreybr','STATUS','1','1','角色','是否停用','停用'),(134,'usercore_user_job','ODS_PTY_USER_WORK','ACCUMULATION_FUND','coreybr','HAS_ACCUMULATION_FUND','0','0','个人参与者职业信息','公积金缴纳','没有缴纳公积金'),(135,'usercore_user_job','ODS_PTY_USER_WORK','ACCUMULATION_FUND','coreybr','HAS_ACCUMULATION_FUND','1','1','个人参与者职业信息','公积金缴纳','正常缴纳公积金'),(136,'usercore_user_personal','ODS_PTY_USER_ASSET','HAS_HOUSE','coreybr','HAS_HOUSE','0','0','个人参与者资产信息','是否有房','没有自有住房'),(137,'usercore_user_personal','ODS_PTY_USER_ASSET','HAS_HOUSE','coreybr','HAS_HOUSE','1','1','个人参与者资产信息','是否有房','拥有自有住房'),(138,'usercore_user_job','ODS_PTY_USER_WORK','WORK_YEAR','coreybr','WORK_YEAR','2','3','个人参与者职业信息','就业年限','3-5年'),(139,'usercore_user_job','ODS_PTY_USER_WORK','WORK_YEAR','coreybr','WORK_YEAR','3','4','个人参与者职业信息','就业年限','5年以上'),(140,'usercore_user_job','ODS_PTY_USER_WORK','SOCIAL_SECURITY','coreybr','HAS_SOCIAL_SECURITY','0','0','个人参与者职业信息','社保缴纳','没有缴纳社保'),(141,'usercore_user_job','ODS_PTY_USER_WORK','SOCIAL_SECURITY','coreybr','HAS_SOCIAL_SECURITY','1','1','个人参与者职业信息','社保缴纳','正常缴纳社保'),(142,'usercore_user_personal','ODS_PTY_USER_ASSET','HAS_CAR','coreybr','HAS_CAR','0','0','个人参与者资产信息','是否有车','没有自有车辆'),(143,'usercore_user_personal','ODS_PTY_USER_ASSET','HAS_CAR','coreybr','HAS_CAR','1','1','个人参与者资产信息','是否有车','拥有自有车辆'),(144,'t_client','ODS_PTY_USER_INFO','STATUS','ybrhh1','IS_DELETED','1','1','个人参与者基本信息','是否删除','是'),(145,'t_client','ODS_PTY_USER_INFO','STATUS','ybrhh1','IS_DELETED','0','0','个人参与者基本信息','是否删除','否'),(146,'t_client','ODS_PTY_USER_INFO','MARRIED','ybrhh1','MARRY_STATUS','O','99','个人参与者基本信息','婚姻状况','其它'),(147,'t_client','ODS_PTY_USER_INFO','MARRIED','ybrhh1','MARRY_STATUS','M','1','个人参与者基本信息','婚姻状况','已婚'),(148,'t_client','ODS_PTY_USER_INFO','MARRIED','ybrhh1','MARRY_STATUS','S','2','个人参与者基本信息','婚姻状况','未婚'),(149,'tc_credit_amount','ODS_RIC_CREDIT_AMOUNT','STATUS','','STATUS','1','1','授信额度表','状态','是'),(150,'tc_credit_amount','ODS_RIC_CREDIT_AMOUNT','STATUS','','STATUS','0','0','授信额度表','状态','否'),(151,'','ODS_EVT_REFUND','','','IS_OVERDUE','','1','还款事件','是否逾期','已逾期'),(152,'t_client','ODS_PTY_USER_EDU','EDUCATION','ybrhh1','EDUCATION','2','5','个人参与者教育信息','学历','中专'),(153,'t_client','ODS_PTY_USER_EDU','EDUCATION','ybrhh1','EDUCATION','1','8','个人参与者教育信息','学历','初中'),(154,'loan_overdue_compensate_serial','ODS_EVT_COMPENSATE','compensate_STATUS','bizybr','COMPENSATE_STATUS','1','2','代偿事件','代偿状态','代偿转账中'),(155,'loan_overdue_compensate_serial','ODS_EVT_COMPENSATE','compensate_STATUS','bizybr','COMPENSATE_STATUS','0','1','代偿事件','代偿状态','已逾期'),(156,'loan_borrow_apply','ODS_EVT_BORROW','STATUS','bizybr','STATUS','0','1','借款事件','借款申请状态','待提交'),(157,'loan_borrow_apply','ODS_EVT_BORROW','REFUND_WAY','bizybr','REFUND_WAY','11','11','借款事件','还款方式','到期还本首期付息'),(158,'loan_borrow_apply','ODS_EVT_BORROW','STATUS','bizybr','STATUS','2','3','借款事件','借款申请状态','待审核'),(159,'loan_borrow_apply','ODS_EVT_BORROW','STATUS','bizybr','STATUS','1','2','借款事件','借款申请状态','已取消'),(160,'loan_borrow_apply','ODS_EVT_BORROW','STATUS','bizybr','STATUS','4','5','借款事件','借款申请状态','审核中'),(161,'loan_borrow_apply','ODS_EVT_BORROW','STATUS','bizybr','STATUS','3','4','借款事件','借款申请状态','已退回'),(162,'loan_borrow_apply','ODS_EVT_BORROW','USER_TYPE','bizybr','USER_TYPE','1','2','借款事件','用户类型','机构'),(163,'loan_borrow_apply','ODS_EVT_BORROW','USER_TYPE','bizybr','USER_TYPE','0','1','借款事件','用户类型','个人'),(164,'asset_outcome_plan','ODS_EVT_REFUND','STATUS','coreybr','REFUND_STATUS','1','2','还款事件','还款状态','已还款'),(165,'asset_outcome_plan','ODS_EVT_REFUND','STATUS','coreybr','REFUND_STATUS','0','1','还款事件','还款状态','未还款'),(166,'usercore_user_bindcards','ODS_PTY_USER_BINDCARD','CURRENCY','coreybr','CURRENCY','DEM','DEM','个人参与者绑卡信息','币种','德国马克'),(167,'usercore_user_bindcards','ODS_PTY_USER_BINDCARD','CURRENCY','coreybr','CURRENCY','FRF','FRF','个人参与者绑卡信息','币种','法国法郎'),(168,'asset_outcome_plan','ODS_EVT_REFUND','STATUS','coreybr','REFUND_STATUS','5','6','还款事件','还款状态','违约'),(169,'asset_outcome_plan','ODS_EVT_REFUND','STATUS','coreybr','REFUND_STATUS','4','5','还款事件','还款状态','逾期已还款'),(170,'asset_outcome_plan','ODS_EVT_REFUND','STATUS','coreybr','REFUND_STATUS','3','4','还款事件','还款状态','逾期未还款'),(171,'asset_outcome_plan','ODS_EVT_REFUND','STATUS','coreybr','REFUND_STATUS','2','3','还款事件','还款状态','部分还款'),(172,'usercore_user_bindcards','ODS_PTY_USER_BINDCARD','CURRENCY','coreybr','CURRENCY','IDR','IDR','个人参与者绑卡信息','币种','印尼盾'),(173,'usercore_user_bindcards','ODS_PTY_USER_BINDCARD','CURRENCY','coreybr','CURRENCY','NZD','NZD','个人参与者绑卡信息','币种','新西兰元'),(174,'usercore_user_bindcards','ODS_PTY_USER_BINDCARD','CURRENCY','coreybr','CURRENCY','LUF','LUF','个人参与者绑卡信息','币种','卢森堡法郎'),(175,'usercore_user_bindcards','ODS_PTY_USER_BINDCARD','CURRENCY','coreybr','CURRENCY','PTE','PTE','个人参与者绑卡信息','币种','葡萄牙埃斯库多'),(176,'usercore_user_bindcards','ODS_PTY_USER_BINDCARD','CURRENCY','coreybr','CURRENCY','USD','USD','个人参与者绑卡信息','币种','美元'),(177,'usercore_user_bindcards','ODS_PTY_USER_BINDCARD','CURRENCY','coreybr','CURRENCY','EUR','EUR','个人参与者绑卡信息','币种','欧元'),(178,'usercore_user_bindcards','ODS_PTY_USER_BINDCARD','CURRENCY','coreybr','CURRENCY','SUR','SUR','个人参与者绑卡信息','币种','俄罗斯卢布'),(179,'usercore_user_bindcards','ODS_PTY_USER_BINDCARD','CURRENCY','coreybr','CURRENCY','KRW','KRW','个人参与者绑卡信息','币种','韩国元'),(180,'usercore_user_personal','ODS_PTY_USER_INFO','SEX','coreybr','SEX','2','3','个人参与者基本信息','性别','保密'),(181,'asset_acct_info','ODS_AGT_ACCOUNT','CURRENCY','bizybr','CURRENCY','HKD','HKD','账户表','币种','港币'),(182,'asset_acct_info','ODS_AGT_ACCOUNT','CURRENCY','bizybr','CURRENCY','CAD','CAD','账户表','币种','加拿大元'),(183,'asset_acct_info','ODS_AGT_ACCOUNT','CURRENCY','bizybr','CURRENCY','IEP','IEP','账户表','币种','爱尔兰镑'),(184,'asset_acct_info','ODS_AGT_ACCOUNT','CURRENCY','bizybr','CURRENCY','FIM','FIM','账户表','币种','芬兰马克'),(185,'asset_acct_info','ODS_AGT_ACCOUNT','CURRENCY','bizybr','CURRENCY','JPY','JPY','账户表','币种','日元'),(186,'asset_acct_info','ODS_AGT_ACCOUNT','CURRENCY','bizybr','CURRENCY','CNY','CNY','账户表','币种','人民币'),(187,'asset_acct_info','ODS_AGT_ACCOUNT','CURRENCY','bizybr','CURRENCY','CHF','CHF','账户表','币种','瑞士法郎'),(188,'asset_acct_info','ODS_AGT_ACCOUNT','CURRENCY','bizybr','CURRENCY','GBP','GBP','账户表','币种','英镑'),(189,'asset_acct_info','ODS_AGT_ACCOUNT','CURRENCY','bizybr','CURRENCY','PTE','PTE','账户表','币种','葡萄牙埃斯库多'),(190,'asset_acct_info','ODS_AGT_ACCOUNT','CURRENCY','bizybr','CURRENCY','LUF','LUF','账户表','币种','卢森堡法郎'),(191,'t_appl','ODS_EVT_APPLY','Decision_Reason','ybrhh1','DECISION_REASON','D215','D9','进件事件表','原因描述代码','资格不符'),(192,'t_appl','ODS_EVT_APPLY','Decision_Reason','ybrhh1','DECISION_REASON','D106','D10','进件事件表','原因描述代码','信用不符'),(193,'t_appl','ODS_EVT_APPLY','Decision_Reason','ybrhh1','DECISION_REASON','D710','D1','进件事件表','原因描述代码','黑名单'),(194,'t_appl','ODS_EVT_APPLY','Decision_Reason','ybrhh1','DECISION_REASON','D203','D2','进件事件表','原因描述代码','年龄不符'),(195,'t_appl','ODS_EVT_APPLY','Decision_Reason','ybrhh1','DECISION_REASON','D210','D3','进件事件表','原因描述代码','高风险户籍'),(196,'t_appl','ODS_EVT_APPLY','Decision_Reason','ybrhh1','DECISION_REASON','D308','D4','进件事件表','原因描述代码','联网核查失败'),(197,'t_appl','ODS_EVT_APPLY','Decision_Reason','ybrhh1','DECISION_REASON','D804','D5','进件事件表','原因描述代码','网申特殊拒绝'),(198,'t_appl','ODS_EVT_APPLY','Decision_Reason','ybrhh1','DECISION_REASON','D607','D6','进件事件表','原因描述代码','其他'),(199,'t_appl','ODS_EVT_APPLY','Decision_Reason','ybrhh1','DECISION_REASON','D307','D7','进件事件表','原因描述代码','资料不符'),(200,'t_appl','ODS_EVT_APPLY','Decision_Reason','ybrhh1','DECISION_REASON','D209','D8','进件事件表','原因描述代码','资格不符'),(201,'sellbiz_invest_vchr','ODS_AGT_INVEST_VCHR','INVEST_STATUS','bizybr','INVEST_STATUS','4','5','投资单据','投资状态','已取消'),(202,'sellbiz_invest_vchr','ODS_AGT_INVEST_VCHR','INVEST_STATUS','bizybr','INVEST_STATUS','3','4','投资单据','投资状态','支付超时'),(203,'sellbiz_invest_vchr','ODS_AGT_INVEST_VCHR','INVEST_STATUS','bizybr','INVEST_STATUS','2','3','投资单据','投资状态','待确认'),(204,'sellbiz_invest_vchr','ODS_AGT_INVEST_VCHR','INVEST_STATUS','bizybr','INVEST_STATUS','1','2','投资单据','投资状态','待支付'),(205,'sellbiz_invest_vchr','ODS_AGT_INVEST_VCHR','INVEST_STATUS','bizybr','INVEST_STATUS','0','1','投资单据','投资状态','申请中'),(206,'loan_product','ODS_PRD_P2P_LOAN_PRODUCT_INFO','allow_advance','bizybr','IS_ALLOW_ADVANCE','1','1','P2P借款产品信息表','是否允许提前还款','允许'),(207,'loan_product','ODS_PRD_P2P_LOAN_PRODUCT_INFO','allow_advance','bizybr','IS_ALLOW_ADVANCE','0','0','P2P借款产品信息表','是否允许提前还款','不允许'),(208,'loan_product','ODS_PRD_P2P_LOAN_PRODUCT_INFO','BEYOND_FLAG','bizybr','IS_BEYOND','1','1','P2P借款产品信息表','是否允许超出授信截止日','允许'),(209,'loan_product','ODS_PRD_P2P_LOAN_PRODUCT_INFO','BEYOND_FLAG','bizybr','IS_BEYOND','0','0','P2P借款产品信息表','是否允许超出授信截止日','不允许'),(210,'loan_product','ODS_PRD_P2P_LOAN_PRODUCT_INFO','ASSURE_FLAG','bizybr','HAS_ASSURE','1','1','P2P借款产品信息表','是否需要保证金','需要'),(211,'asset_acct_info','ODS_AGT_ACCOUNT','CURRENCY','bizybr','CURRENCY','KRW','KRW','账户表','币种','韩国元'),(212,'sellbiz_invest_vchr','ODS_AGT_INVEST_VCHR','INVEST_STATUS','bizybr','INVEST_STATUS','7','8','投资单据','投资状态','支付处理中'),(213,'sellbiz_purchase_vchr','ODS_AGT_PURCHASE_VCHR','PRODUCT_TYPE','bizybr','PRODUCT_TYPE','0','1','申购单据','投资产品类型','默认'),(214,'sellbiz_invest_vchr','ODS_AGT_INVEST_VCHR','INVEST_STATUS','bizybr','INVEST_STATUS','5','6','投资单据','投资状态','支付成功'),(215,'sellbiz_invest_vchr','ODS_AGT_INVEST_VCHR','INVEST_STATUS','bizybr','INVEST_STATUS','6','7','投资单据','投资状态','支付失败'),(216,'sellbiz_purchase_vchr','ODS_AGT_PURCHASE_VCHR','USER_ROLE','bizybr','USER_ROLE','0','1','申购单据','用户角色','个人'),(217,'sellbiz_purchase_vchr','ODS_AGT_PURCHASE_VCHR','USER_ROLE','bizybr','USER_ROLE','1','2','申购单据','用户角色','机构'),(218,'sellbiz_purchase_vchr','ODS_AGT_PURCHASE_VCHR','PRODUCT_TYPE','bizybr','PRODUCT_TYPE','8','2','申购单据','投资产品类型','活期理财'),(219,'sellbiz_purchase_vchr','ODS_AGT_PURCHASE_VCHR','PRODUCT_TYPE','bizybr','PRODUCT_TYPE','9','3','申购单据','投资产品类型','定期理财'),(220,'sellbiz_purchase_vchr','ODS_AGT_PURCHASE_VCHR','PURCHASE_STATUS','bizybr','PURCHASE_STATUS','1','1','申购单据','申购单状态','申请未成交'),(221,'sellbiz_purchase_vchr','ODS_AGT_PURCHASE_VCHR','PURCHASE_STATUS','bizybr','PURCHASE_STATUS','2','2','申购单据','申购单状态','部分成交'),(222,'usercore_user_education','ODS_PTY_USER_EDU','EDUCATION','coreybr','EDUCATION','3','7','个人参与者教育信息','学历','高中'),(223,'usercore_user_education','ODS_PTY_USER_EDU','EDUCATION','coreybr','EDUCATION','2','4','个人参与者教育信息','学历','大专'),(224,'usercore_user_job','ODS_PTY_USER_WORK','WORK_STATUS','coreybr','WORK_STATUS','0','1','个人参与者职业信息','就业状况','工薪族'),(225,'usercore_user_education','ODS_PTY_USER_EDU','EDUCATION','coreybr','EDUCATION','4','8','个人参与者教育信息','学历','初中'),(226,'usercore_user_job','ODS_PTY_USER_WORK','WORK_STATUS','coreybr','WORK_STATUS','2','6','个人参与者职业信息','就业状况','自由职业者(包含网商)'),(227,'usercore_user_job','ODS_PTY_USER_WORK','WORK_STATUS','coreybr','WORK_STATUS','1','2','个人参与者职业信息','就业状况','企业族'),(228,'usercore_user_job','ODS_PTY_USER_WORK','WORK_STATUS','coreybr','WORK_STATUS','4','99','个人参与者职业信息','就业状况','其它'),(229,'usercore_user_job','ODS_PTY_USER_WORK','WORK_STATUS','coreybr','WORK_STATUS','3','7','个人参与者职业信息','就业状况','学生'),(230,'usercore_user_job','ODS_PTY_USER_WORK','WORK_YEAR','coreybr','WORK_YEAR','1','2','个人参与者职业信息','就业年限','1-3年'),(231,'usercore_user_job','ODS_PTY_USER_WORK','WORK_YEAR','coreybr','WORK_YEAR','0','1','个人参与者职业信息','就业年限','1年以下'),(232,'usercore_user_contact','ODS_PTY_USER_CONTACT','RELATION','coreybr','CONTACT_RELATION','0','1','个人参与者联系人信息','关系','配偶'),(233,'asset_recharge_withdraw_detail','ODS_EVT_WITHDRAW','STATUS','coreybr','STATUS','1','2','提现事件表','处理状态','失败'),(234,'asset_recharge_withdraw_detail','ODS_EVT_WITHDRAW','STATUS','coreybr','STATUS','2','3','提现事件表','处理状态','处理中'),(235,'asset_recharge_withdraw_detail','ODS_EVT_WITHDRAW','WITHDRAW_TYPE','coreybr','WITHDRAW_TYPE','1','2','提现事件表','提现类型','加急提现'),(236,'asset_recharge_withdraw_detail','ODS_EVT_WITHDRAW','STATUS','coreybr','STATUS','0','1','提现事件表','处理状态','成功'),(237,'sellbiz_invest_vchr','ODS_EVT_INVEST','INVEST_STATUS','bizybr','INVEST_STATUS','2','3','投资事件','投资状态','待确认'),(238,'sellbiz_invest_vchr','ODS_EVT_INVEST','INVEST_STATUS','bizybr','INVEST_STATUS','3','4','投资事件','投资状态','支付超时'),(239,'sellbiz_invest_vchr','ODS_EVT_INVEST','INVEST_STATUS','bizybr','INVEST_STATUS','0','1','投资事件','投资状态','申请中'),(240,'sellbiz_invest_vchr','ODS_EVT_INVEST','INVEST_STATUS','bizybr','INVEST_STATUS','1','2','投资事件','投资状态','待支付'),(241,'sellbiz_invest_vchr','ODS_EVT_INVEST','INVEST_STATUS','bizybr','INVEST_STATUS','4','5','投资事件','投资状态','已取消'),(242,'sellbiz_invest_vchr','ODS_EVT_INVEST','INVEST_STATUS','bizybr','INVEST_STATUS','5','6','投资事件','投资状态','支付成功'),(243,'sellbiz_sell_vchr','ODS_AGT_SELL_VCHR','USER_ROLE','bizybr','USER_ROLE','0','1','卖出单据','用户角色','个人'),(244,'sellbiz_sell_vchr','ODS_AGT_SELL_VCHR','PRODUCT_TYPE','bizybr','PRODUCT_TYPE','9','3','卖出单据','投资产品类型','定期理财'),(245,'sellbiz_sell_vchr','ODS_AGT_SELL_VCHR','SELL_STATUS','bizybr','SELL_STATUS','1','1','卖出单据','卖出单状态','申请未成交'),(246,'sellbiz_sell_vchr','ODS_AGT_SELL_VCHR','USER_ROLE','bizybr','USER_ROLE','1','2','卖出单据','用户角色','机构'),(247,'sellbiz_sell_vchr','ODS_AGT_SELL_VCHR','SELL_STATUS','bizybr','SELL_STATUS','3','3','卖出单据','卖出单状态','全部成交'),(248,'sellbiz_sell_vchr','ODS_AGT_SELL_VCHR','SELL_STATUS','bizybr','SELL_STATUS','2','2','卖出单据','卖出单状态','部分成交'),(249,'sellbiz_sell_vchr','ODS_AGT_SELL_VCHR','SELL_STATUS','bizybr','SELL_STATUS','5','5','卖出单据','卖出单状态','全部流标'),(250,'sellbiz_sell_vchr','ODS_AGT_SELL_VCHR','SELL_STATUS','bizybr','SELL_STATUS','4','4','卖出单据','卖出单状态','部分成交，部分流标'),(251,'sellbiz_sell_vchr','ODS_AGT_SELL_VCHR','AUTO_FLAG','bizybr','IS_AUTO','1','1','卖出单据','是否自动','是'),(252,'sellbiz_sell_vchr','ODS_AGT_SELL_VCHR','AUTO_FLAG','bizybr','IS_AUTO','0','0','卖出单据','是否自动','否'),(253,'usercore_user_bindcards','ODS_PTY_USER_BINDCARD','CURRENCY','coreybr','CURRENCY','HKD','HKD','个人参与者绑卡信息','币种','港币'),(254,'usercore_user_bindcards','ODS_PTY_USER_BINDCARD','CURRENCY','coreybr','CURRENCY','CAD','CAD','个人参与者绑卡信息','币种','加拿大元'),(255,'usercore_user_bindcards','ODS_PTY_USER_BINDCARD','CURRENCY','coreybr','CURRENCY','CHF','CHF','个人参与者绑卡信息','币种','瑞士法郎'),(256,'usercore_user_bindcards','ODS_PTY_USER_BINDCARD','CURRENCY','coreybr','CURRENCY','GBP','GBP','个人参与者绑卡信息','币种','英镑'),(257,'usercore_user_bindcards','ODS_PTY_USER_BINDCARD','CURRENCY','coreybr','CURRENCY','JPY','JPY','个人参与者绑卡信息','币种','日元'),(258,'usercore_user_bindcards','ODS_PTY_USER_BINDCARD','CURRENCY','coreybr','CURRENCY','CNY','CNY','个人参与者绑卡信息','币种','人民币'),(259,'usercore_user_bindcards','ODS_PTY_USER_BINDCARD','OPEN_FAST_PAY','coreybr','IS_FAST_PAY','1','1','个人参与者绑卡信息','是否开通快捷支付','已开通'),(260,'usercore_user_bindcards','ODS_PTY_USER_BINDCARD','OPEN_FAST_PAY','coreybr','IS_FAST_PAY','0','0','个人参与者绑卡信息','是否开通快捷支付','未开通'),(261,'usercore_user_bindcards','ODS_PTY_USER_BINDCARD','CURRENCY','coreybr','CURRENCY','IEP','IEP','个人参与者绑卡信息','币种','爱尔兰镑'),(262,'usercore_user_bindcards','ODS_PTY_USER_BINDCARD','CURRENCY','coreybr','CURRENCY','FIM','FIM','个人参与者绑卡信息','币种','芬兰马克'),(263,'usercore_user_personal','ODS_PTY_USER_INFO','MARRY_STATUS','coreybr','MARRY_STATUS','2','3','个人参与者基本信息','婚姻状况','离异'),(264,'usercore_user_education','ODS_PTY_USER_EDU','EDUCATION','coreybr','EDUCATION','0','2','个人参与者教育信息','学历','硕士研究生'),(265,'usercore_user_contact','ODS_PTY_USER_CONTACT','RELATION','coreybr','CONTACT_RELATION','6','7','个人参与者联系人信息','关系','联系人'),(266,'usercore_user_business','ODS_PTY_AGENT_OPERATE','INDUSTRY_TYPE','coreybr','INDUSTRY_TYPE','6','7','机构参与者经营信息','行业类型','交通运输仓储业和邮政业'),(267,'usercore_user_business','ODS_PTY_AGENT_OPERATE','INDUSTRY_TYPE','coreybr','INDUSTRY_TYPE','7','8','机构参与者经营信息','行业类型','信息传输计算机服务和软件业'),(268,'usercore_user_business','ODS_PTY_AGENT_OPERATE','INDUSTRY_TYPE','coreybr','INDUSTRY_TYPE','8','9','机构参与者经营信息','行业类型','批发和零售业'),(269,'usercore_user_business','ODS_PTY_AGENT_OPERATE','INDUSTRY_TYPE','coreybr','INDUSTRY_TYPE','9','10','机构参与者经营信息','行业类型','住宿餐饮业'),(270,'usercore_user_business','ODS_PTY_AGENT_OPERATE','INDUSTRY_TYPE','coreybr','INDUSTRY_TYPE','a','11','机构参与者经营信息','行业类型','金融保险业'),(271,'usercore_user_business','ODS_PTY_AGENT_OPERATE','INDUSTRY_TYPE','coreybr','INDUSTRY_TYPE','b','12','机构参与者经营信息','行业类型','房地产业'),(272,'usercore_user_business','ODS_PTY_AGENT_OPERATE','INDUSTRY_TYPE','coreybr','INDUSTRY_TYPE','c','13','机构参与者经营信息','行业类型','租赁和商务服务业'),(273,'usercore_user_business','ODS_PTY_AGENT_OPERATE','INDUSTRY_TYPE','coreybr','INDUSTRY_TYPE','d','14','机构参与者经营信息','行业类型','科学研究技术服务和地质勘查业'),(274,'usercore_user_business','ODS_PTY_AGENT_OPERATE','INDUSTRY_TYPE','coreybr','INDUSTRY_TYPE','e','15','机构参与者经营信息','行业类型','水利环境和公共设施管理业'),(275,'usercore_user_business','ODS_PTY_AGENT_OPERATE','INDUSTRY_TYPE','coreybr','INDUSTRY_TYPE','f','16','机构参与者经营信息','行业类型','居民服务和其它服务业'),(276,'t_client_unit','ODS_PTY_USER_WORK','UNIT_TYPE','ybrhh1','COMPANY_TYPE','01','1','个人参与者职业信息','单位性质','机关、事业单位'),(277,'t_client_unit','ODS_PTY_USER_WORK','UNIT_TYPE','ybrhh1','COMPANY_TYPE','02','2','个人参与者职业信息','单位性质','国有企业'),(278,'t_client_unit','ODS_PTY_USER_WORK','UNIT_TYPE','ybrhh1','COMPANY_TYPE','03','3','个人参与者职业信息','单位性质','外商独资企业'),(279,'t_client_unit','ODS_PTY_USER_WORK','UNIT_TYPE','ybrhh1','COMPANY_TYPE','04','4','个人参与者职业信息','单位性质','合资、合作企业'),(280,'t_client','ODS_PTY_USER_EDU','EDUCATION','ybrhh1','EDUCATION','3','4','个人参与者教育信息','学历','大专'),(281,'t_client','ODS_PTY_USER_EDU','EDUCATION','ybrhh1','EDUCATION','4','3','个人参与者教育信息','学历','本科'),(282,'t_client','ODS_PTY_USER_EDU','EDUCATION','ybrhh1','EDUCATION','5','2','个人参与者教育信息','学历','硕士研究生'),(283,'t_client','ODS_PTY_USER_EDU','EDUCATION','ybrhh1','EDUCATION','6','1','个人参与者教育信息','学历','博士研究生'),(284,'t_client_unit','ODS_PTY_USER_WORK','UNIT_TYPE','ybrhh1','COMPANY_TYPE','05','5','个人参与者职业信息','单位性质','股份制'),(285,'t_client_unit','ODS_PTY_USER_WORK','UNIT_TYPE','ybrhh1','COMPANY_TYPE','06','6','个人参与者职业信息','单位性质','私营企业'),(286,'asset_recharge_withdraw_detail','ODS_EVT_WITHDRAW','WITHDRAW_TYPE','coreybr','WITHDRAW_TYPE','0','1','提现事件表','提现类型','普通提现'),(287,'asset_recharge_withdraw_detail','ODS_EVT_WITHDRAW','RW_NET_TYPE','coreybr','NET_TYPE','3','3','提现事件表','网络类型','线下'),(288,'asset_recharge_withdraw_detail','ODS_EVT_RECHARGE','STATUS','coreybr','STATUS','2','3','充值事件表','处理状态','处理中'),(289,'asset_recharge_withdraw_detail','ODS_EVT_RECHARGE','STATUS','coreybr','STATUS','1','2','充值事件表','处理状态','失败'),(290,'asset_recharge_withdraw_detail','ODS_EVT_RECHARGE','STATUS','coreybr','STATUS','0','1','充值事件表','处理状态','成功'),(291,'asset_recharge_withdraw_detail','ODS_EVT_RECHARGE','RW_NET_TYPE','coreybr','NET_TYPE','3','3','充值事件表','网络类型','线下'),(292,'asset_recharge_withdraw_detail','ODS_EVT_WITHDRAW','RW_NET_TYPE','coreybr','NET_TYPE','2','2','提现事件表','网络类型','快捷'),(293,'asset_recharge_withdraw_detail','ODS_EVT_WITHDRAW','RW_NET_TYPE','coreybr','NET_TYPE','1','1','提现事件表','网络类型','网关'),(294,'asset_recharge_withdraw_detail','ODS_EVT_WITHDRAW','FEE_MODE','coreybr','FEE_MODE','2','2','提现事件表','收费方式','费用外扣'),(295,'asset_recharge_withdraw_detail','ODS_EVT_WITHDRAW','FEE_MODE','coreybr','FEE_MODE','1','1','提现事件表','收费方式','费用内扣'),(296,'usercore_user_personal','ODS_PTY_USER_INFO','MARRY_STATUS','coreybr','MARRY_STATUS','3','4','个人参与者基本信息','婚姻状况','丧偶'),(297,'loan_borrow_apply','ODS_EVT_BORROW','REFUND_WAY','bizybr','REFUND_WAY','9','9','借款事件','还款方式','按每年固定日付息到期还本'),(298,'loan_borrow_apply','ODS_EVT_BORROW','REFUND_WAY','bizybr','REFUND_WAY','10','10','借款事件','还款方式','按每月固定日集合付息到期还本'),(299,'loan_borrow_apply','ODS_EVT_BORROW','REFUND_WAY','bizybr','REFUND_WAY','7','7','借款事件','还款方式','按每月固定日付息到期还本'),(300,'loan_borrow_apply','ODS_EVT_BORROW','REFUND_WAY','bizybr','REFUND_WAY','8','8','借款事件','还款方式','按每季度固定日付息到期还本'),(301,'loan_borrow_apply','ODS_EVT_BORROW','REFUND_WAY','bizybr','REFUND_WAY','5','5','借款事件','还款方式','按月等额本息'),(302,'loan_borrow_apply','ODS_EVT_BORROW','REFUND_WAY','bizybr','REFUND_WAY','6','6','借款事件','还款方式','按月等额本金'),(303,'loan_borrow_apply','ODS_EVT_BORROW','REFUND_WAY','bizybr','REFUND_WAY','3','3','借款事件','还款方式','按季付息到期还本'),(304,'loan_borrow_apply','ODS_EVT_BORROW','REFUND_WAY','bizybr','REFUND_WAY','4','4','借款事件','还款方式','按半年付息到期还本'),(305,'loan_borrow_apply','ODS_EVT_BORROW','REFUND_WAY','bizybr','REFUND_WAY','1','1','借款事件','还款方式','到期还本付息'),(306,'loan_borrow_apply','ODS_EVT_BORROW','REFUND_WAY','bizybr','REFUND_WAY','2','2','借款事件','还款方式','按月付息到期还本'),(307,'loan_overdue_compensate_serial','ODS_EVT_COMPENSATE','compensate_STATUS','bizybr','COMPENSATE_STATUS','2','3','代偿事件','代偿状态','已转账'),(308,'loan_overdue_compensate_serial','ODS_EVT_COMPENSATE','compensate_STATUS','bizybr','COMPENSATE_STATUS','3','4','代偿事件','代偿状态','转账失败'),(309,'loan_overdue_compensate_serial','ODS_EVT_COMPENSATE','compensate_STATUS','bizybr','COMPENSATE_STATUS','4','5','代偿事件','代偿状态','已代偿'),(310,'loan_overdue_compensate_serial','ODS_EVT_COMPENSATE','compensate_STATUS','bizybr','COMPENSATE_STATUS','5','6','代偿事件','代偿状态','已还清'),(311,'userbiz_referee_serial','ODS_EVT_REFEREE','STATUS','bizybr','STATUS','0','0','推荐事件表','状态','否'),(312,'userbiz_referee_serial','ODS_EVT_REFEREE','STATUS','bizybr','STATUS','1','1','推荐事件表','状态','是'),(313,'loan_expand_period','ODS_EVT_EXPAND','ITEM_UNIT','bizybr','ITEM_UNIT','6','1','展期事件','展期单位','日'),(314,'loan_expand_period','ODS_EVT_EXPAND','ITEM_UNIT','bizybr','ITEM_UNIT','2','2','展期事件','展期单位','月'),(315,'loan_expand_period','ODS_EVT_EXPAND','ITEM_UNIT','bizybr','ITEM_UNIT','1','3','展期事件','展期单位','年'),(316,'loan_expand_period','ODS_EVT_EXPAND','STATUS','bizybr','STATUS','0','3','展期事件','展期申请状态','待审核'),(317,'usercore_user_contact','ODS_PTY_USER_CONTACT','STATUS','coreybr','CONTACT_STATUS','0','0','个人参与者联系人信息','状态','否'),(318,'usercore_user_contact','ODS_PTY_USER_CONTACT','STATUS','coreybr','CONTACT_STATUS','1','1','个人参与者联系人信息','状态','是'),(319,'asset_acct_info','ODS_AGT_ACCOUNT','CURRENCY','bizybr','CURRENCY','AUD','AUD','账户表','币种','澳大利亚元'),(320,'asset_acct_info','ODS_AGT_ACCOUNT','CURRENCY','bizybr','CURRENCY','ATS','ATS','账户表','币种','奥地利先令'),(321,'usercore_user_contact','ODS_PTY_USER_CONTACT','RELATION','coreybr','CONTACT_RELATION','2','3','个人参与者联系人信息','关系','兄弟姐妹'),(322,'usercore_user_contact','ODS_PTY_USER_CONTACT','RELATION','coreybr','CONTACT_RELATION','3','5','个人参与者联系人信息','关系','朋友'),(323,'usercore_user_contact','ODS_PTY_USER_CONTACT','RELATION','coreybr','CONTACT_RELATION','4','6','个人参与者联系人信息','关系','同事'),(324,'usercore_user_contact','ODS_PTY_USER_CONTACT','RELATION','coreybr','CONTACT_RELATION','5','99','个人参与者联系人信息','关系','其它'),(325,'asset_acct_info','ODS_AGT_ACCOUNT','CURRENCY','bizybr','CURRENCY','SUR','SUR','账户表','币种','俄罗斯卢布'),(326,'usercore_user_contact','ODS_PTY_USER_CONTACT','RELATION','coreybr','CONTACT_RELATION','7','8','个人参与者联系人信息','关系','紧急联系人'),(327,'asset_acct_info','ODS_AGT_ACCOUNT','CURRENCY','bizybr','CURRENCY','IDR','IDR','账户表','币种','印尼盾'),(328,'asset_acct_info','ODS_AGT_ACCOUNT','CURRENCY','bizybr','CURRENCY','NZD','NZD','账户表','币种','新西兰元'),(329,'asset_acct_info','ODS_AGT_ACCOUNT','CURRENCY','bizybr','CURRENCY','DEM','DEM','账户表','币种','德国马克'),(330,'asset_acct_info','ODS_AGT_ACCOUNT','CURRENCY','bizybr','CURRENCY','FRF','FRF','账户表','币种','法国法郎'),(331,'asset_acct_info','ODS_AGT_ACCOUNT','CURRENCY','bizybr','CURRENCY','USD','USD','账户表','币种','美元'),(332,'asset_acct_info','ODS_AGT_ACCOUNT','CURRENCY','bizybr','CURRENCY','EUR','EUR','账户表','币种','欧元'),(333,'t_client_signrecord','ODS_EVT_SIGNRECORD','SIGN_STATUS','ybrhh1','SIGN_STATUS','3','4','面签记录表','流水状态','已面签（已激活已扣费）'),(334,'t_client_signrecord','ODS_EVT_SIGNRECORD','SIGN_STATUS','ybrhh1','SIGN_STATUS','2','3','面签记录表','流水状态','已预约'),(335,'t_appl','ODS_EVT_APPLY','STATUS','ybrhh1','IS_DELETED','1','1','进件事件表','是否删除','已删除'),(336,'t_appl','ODS_EVT_APPLY','STATUS','ybrhh1','IS_DELETED','0','0','进件事件表','是否删除','未删除'),(337,'t_client_signrecord','ODS_EVT_SIGNRECORD','SIGN_STATUS','ybrhh1','SIGN_STATUS','1','2','面签记录表','流水状态','已领单未预约'),(338,'t_client_signrecord','ODS_EVT_SIGNRECORD','SIGN_STATUS','ybrhh1','SIGN_STATUS','0','1','面签记录表','流水状态','未领单'),(339,'t_appl','ODS_EVT_APPLY','Decision_Reason','ybrhh1','DECISION_REASON','D708','D12','进件事件表','原因描述代码','已持卡或黑名单'),(340,'t_appl','ODS_EVT_APPLY','Decision_Reason','ybrhh1','DECISION_REASON','D102','D11','进件事件表','原因描述代码','信用不符'),(341,'t_appl','ODS_EVT_APPLY','Decision_Reason','ybrhh1','DECISION_REASON','D617','D14','进件事件表','原因描述代码','其他审核拒绝'),(342,'t_appl','ODS_EVT_APPLY','Decision_Reason','ybrhh1','DECISION_REASON','D707','D13','进件事件表','原因描述代码','已持卡或黑名单'),(343,'loan_product','ODS_PRD_P2P_LOAN_PRODUCT_INFO','PLEDGE_FLAG','bizybr','HAS_PLEDGE','1','1','P2P借款产品信息表','是否需要抵押','需要'),(344,'loan_product','ODS_PRD_P2P_LOAN_PRODUCT_INFO','ASSURE_FLAG','bizybr','HAS_ASSURE','0','0','P2P借款产品信息表','是否需要保证金','不需要'),(345,'loan_product','ODS_PRD_P2P_LOAN_PRODUCT_INFO','REFUND_WAY','bizybr','REFUND_WAY','9','9','P2P借款产品信息表','还款方式','按每年固定日付息到期还本'),(346,'loan_product','ODS_PRD_P2P_LOAN_PRODUCT_INFO','REFUND_WAY','bizybr','REFUND_WAY','10','10','P2P借款产品信息表','还款方式','按每月固定日集合付息到期还本'),(347,'loan_product','ODS_PRD_P2P_LOAN_PRODUCT_INFO','REFUND_WAY','bizybr','REFUND_WAY','11','11','P2P借款产品信息表','还款方式','到期还本首期付息'),(348,'loan_product','ODS_PRD_P2P_LOAN_PRODUCT_INFO','PLEDGE_FLAG','bizybr','HAS_PLEDGE','0','0','P2P借款产品信息表','是否需要抵押','不需要'),(349,'loan_product','ODS_PRD_P2P_LOAN_PRODUCT_INFO','REFUND_WAY','bizybr','REFUND_WAY','5','5','P2P借款产品信息表','还款方式','按月等额本息'),(350,'loan_product','ODS_PRD_P2P_LOAN_PRODUCT_INFO','REFUND_WAY','bizybr','REFUND_WAY','6','6','P2P借款产品信息表','还款方式','按月等额本金'),(351,'loan_product','ODS_PRD_P2P_LOAN_PRODUCT_INFO','REFUND_WAY','bizybr','REFUND_WAY','7','7','P2P借款产品信息表','还款方式','按每月固定日付息到期还本'),(352,'loan_product','ODS_PRD_P2P_LOAN_PRODUCT_INFO','REFUND_WAY','bizybr','REFUND_WAY','8','8','P2P借款产品信息表','还款方式','按每季度固定日付息到期还本'),(353,'usercore_user_education','ODS_PTY_USER_EDU','EDUCATION','coreybr','EDUCATION','1','3','个人参与者教育信息','学历','本科'),(354,'loan_borrow_apply','ODS_EVT_BORROW','BORROW_PERIOD_UNIT','bizybr','BORROW_PERIOD_UNIT','6','1','借款事件','借款期限单位','日'),(355,'sellbiz_sell_vchr','ODS_EVT_SELL','AUTO_FLAG','bizybr','IS_AUTO','1','1','卖出事件','是否自动','是'),(356,'sellbiz_sell_vchr','ODS_EVT_SELL','AUTO_FLAG','bizybr','IS_AUTO','0','0','卖出事件','是否自动','否'),(357,'sellbiz_sell_vchr','ODS_EVT_SELL','SELL_STATUS','bizybr','SELL_STATUS','5','5','卖出事件','卖出单状态','全部流标'),(358,'sellbiz_sell_vchr','ODS_EVT_SELL','SELL_STATUS','bizybr','SELL_STATUS','4','4','卖出事件','卖出单状态','部分成交，部分流标'),(359,'sellbiz_sell_vchr','ODS_EVT_SELL','SELL_STATUS','bizybr','SELL_STATUS','3','3','卖出事件','卖出单状态','全部成交'),(360,'sellbiz_sell_vchr','ODS_EVT_SELL','SELL_STATUS','bizybr','SELL_STATUS','2','2','卖出事件','卖出单状态','部分成交'),(361,'sellbiz_sell_vchr','ODS_EVT_SELL','SELL_STATUS','bizybr','SELL_STATUS','1','1','卖出事件','卖出单状态','申请未成交'),(362,'loan_borrow_apply','ODS_EVT_BORROW','BORROW_PERIOD_UNIT','bizybr','BORROW_PERIOD_UNIT','1','3','借款事件','借款期限单位','年'),(363,'loan_borrow_apply','ODS_EVT_BORROW','BORROW_PERIOD_UNIT','bizybr','BORROW_PERIOD_UNIT','2','2','借款事件','借款期限单位','月'),(364,'sellbiz_purchase_invest_relate','ODS_AGT_PCH_IVT_RELATE','STATUS','bizybr','STATUS','2','3','申购单投资单关联表','状态','待确认'),(365,'sellbiz_purchase_invest_relate','ODS_AGT_PCH_IVT_RELATE','STATUS','bizybr','STATUS','3','4','申购单投资单关联表','状态','支付超时'),(366,'sellbiz_purchase_invest_relate','ODS_AGT_PCH_IVT_RELATE','STATUS','bizybr','STATUS','0','1','申购单投资单关联表','状态','申请中'),(367,'sellbiz_purchase_invest_relate','ODS_AGT_PCH_IVT_RELATE','STATUS','bizybr','STATUS','1','2','申购单投资单关联表','状态','待支付'),(368,'sellbiz_transfer_vchr','ODS_AGT_TRANSFER_VCHR','TRANSFER_STATE','bizybr','TRANSFER_STATE','3','3','转让单据','转让单状态','部分撤销'),(369,'sellbiz_transfer_vchr','ODS_AGT_TRANSFER_VCHR','TRANSFER_STATE','bizybr','TRANSFER_STATE','4','4','转让单据','转让单状态','已撤销'),(370,'sellbiz_transfer_vchr','ODS_AGT_TRANSFER_VCHR','TRANSFER_STATE','bizybr','TRANSFER_STATE','1','1','转让单据','转让单状态','转让中'),(371,'sellbiz_transfer_vchr','ODS_AGT_TRANSFER_VCHR','TRANSFER_STATE','bizybr','TRANSFER_STATE','2','2','转让单据','转让单状态','售完'),(372,'sellbiz_purchase_invest_relate','ODS_AGT_PCH_IVT_RELATE','STATUS','bizybr','STATUS','4','5','申购单投资单关联表','状态','已取消'),(373,'sellbiz_purchase_invest_relate','ODS_AGT_PCH_IVT_RELATE','STATUS','bizybr','STATUS','5','6','申购单投资单关联表','状态','支付成功'),(374,'usercore_user_register','ODS_EVT_REGISTER','IF_FIRSTBUY','coreybr','IS_FIRSTBUY','0','0','注册事件表','是否首次购买','不是首次购买'),(375,'usercore_user_register','ODS_EVT_REGISTER','IF_ACCOUNT','coreybr','IS_ACCOUNT','1','1','注册事件表','是否开户','已开户'),(376,'usercore_user_personal','ODS_PTY_USER_INFO','MARRY_STATUS','coreybr','MARRY_STATUS','4','5','个人参与者基本信息','婚姻状况','保密'),(377,'usercore_user_register','ODS_EVT_REGISTER','USER_TYPE','coreybr','USER_TYPE','0','1','注册事件表','用户类型','个人'),(378,'','ODS_AGT_ACCOUNT','','','ACCOUNT_BIZ_TYPE','','3','账户表','业务类型','抵押贷款业务'),(379,'usercore_user_register','ODS_EVT_REGISTER','IF_BINDCARD','coreybr','IS_BINDCARD','0','0','注册事件表','是否绑卡','没有绑卡'),(380,'usercore_user_register','ODS_EVT_REGISTER','USER_TYPE','coreybr','USER_TYPE','1','2','注册事件表','用户类型','机构'),(381,'usercore_user_register','ODS_EVT_REGISTER','IF_REALNAME','coreybr','IS_REALNAME','0','0','注册事件表','是否实名','未实名'),(382,'usercore_user_register','ODS_EVT_REGISTER','IF_BINDCARD','coreybr','IS_BINDCARD','1','1','注册事件表','是否绑卡','已绑卡'),(383,'usercore_user_register','ODS_EVT_REGISTER','IF_ACCOUNT','coreybr','IS_ACCOUNT','0','0','注册事件表','是否开户','未开户'),(384,'usercore_user_register','ODS_EVT_REGISTER','IF_REALNAME','coreybr','IS_REALNAME','1','1','注册事件表','是否实名','已实名'),(385,'asset_acct_info','ODS_AGT_ACCOUNT','CURRENCY','bizybr','CURRENCY','ESP','ESP','账户表','币种','西班牙比塞塔'),(386,'asset_acct_info','ODS_AGT_ACCOUNT','CURRENCY','bizybr','CURRENCY','NLG','NLG','账户表','币种','荷兰盾'),(387,'asset_acct_info','ODS_AGT_ACCOUNT','CURRENCY','bizybr','CURRENCY','ITL','ITL','账户表','币种','意大利里拉'),(388,'asset_acct_info','ODS_AGT_ACCOUNT','CURRENCY','bizybr','CURRENCY','BEF','BEF','账户表','币种','比利时法郎'),(389,'asset_acct_info','ODS_AGT_ACCOUNT','CURRENCY','bizybr','CURRENCY','THB','THB','账户表','币种','泰铢'),(390,'asset_acct_info','ODS_AGT_ACCOUNT','CURRENCY','bizybr','CURRENCY','SGD','SGD','账户表','币种','新加坡元'),(391,'asset_acct_info','ODS_AGT_ACCOUNT','CURRENCY','bizybr','CURRENCY','PHP','PHP','账户表','币种','菲律宾比索'),(392,'asset_acct_info','ODS_AGT_ACCOUNT','CURRENCY','bizybr','CURRENCY','MYR','MYR','账户表','币种','马来西亚林吉特'),(393,'asset_acct_info','ODS_AGT_ACCOUNT','OWNER_TYPE','bizybr','OWNER_TYPE','0','1','账户表','属主类型','个人'),(394,'asset_acct_info','ODS_AGT_ACCOUNT','CURRENCY','bizybr','CURRENCY','OTH','OTH','账户表','币种','其它'),(395,'usercore_user_contact','ODS_PTY_USER_CONTACT','SEX','coreybr','CONTACT_SEX','2','3','个人参与者联系人信息','联系人性别','保密'),(396,'usercore_user_contact','ODS_PTY_USER_CONTACT','SEX','coreybr','CONTACT_SEX','1','2','个人参与者联系人信息','联系人性别','女'),(397,'usercore_user_accessory','ODS_PTY_USER_ACCESSORY','TYPE','coreybr','CERT_TYPE','18','99','个人参与者附件资料','附加证件类型','其它'),(398,'usercore_user_accessory','ODS_PTY_USER_ACCESSORY','TYPE','coreybr','CERT_TYPE','17','18','个人参与者附件资料','附加证件类型','技术职称证'),(399,'usercore_user_contact','ODS_PTY_USER_CONTACT','SEX','coreybr','CONTACT_SEX','0','1','个人参与者联系人信息','联系人性别','男'),(400,'usercore_user_accessory','ODS_PTY_USER_ACCESSORY','TYPE','coreybr','CERT_TYPE','19','19','个人参与者附件资料','附加证件类型','开户银行许可证'),(401,'usercore_user_accessory','ODS_PTY_USER_ACCESSORY','TYPE','coreybr','CERT_TYPE','14','15','个人参与者附件资料','附加证件类型','行驶证'),(402,'usercore_user_accessory','ODS_PTY_USER_ACCESSORY','TYPE','coreybr','CERT_TYPE','13','14','个人参与者附件资料','附加证件类型','房产证'),(403,'usercore_user_accessory','ODS_PTY_USER_ACCESSORY','TYPE','coreybr','CERT_TYPE','16','17','个人参与者附件资料','附加证件类型','学历学位证书'),(404,'usercore_user_accessory','ODS_PTY_USER_ACCESSORY','TYPE','coreybr','CERT_TYPE','15','16','个人参与者附件资料','附加证件类型','个人信用报告'),(405,'usercore_user_contact','ODS_PTY_USER_CONTACT','RELATION','coreybr','CONTACT_RELATION','1','2','个人参与者联系人信息','关系','父母'),(406,'usercore_user_business','ODS_PTY_AGENT_OPERATE','INDUSTRY_TYPE','coreybr','INDUSTRY_TYPE','1','2','机构参与者经营信息','行业类型','采矿业'),(407,'usercore_user_business','ODS_PTY_AGENT_OPERATE','INDUSTRY_TYPE','coreybr','INDUSTRY_TYPE','0','1','机构参与者经营信息','行业类型','农林牧渔业'),(408,'usercore_user_business','ODS_PTY_AGENT_OPERATE','INDUSTRY_TYPE','coreybr','INDUSTRY_TYPE','3','4','机构参与者经营信息','行业类型','电力热力燃气及水的生产和供应业'),(409,'usercore_user_business','ODS_PTY_AGENT_OPERATE','INDUSTRY_TYPE','coreybr','INDUSTRY_TYPE','2','3','机构参与者经营信息','行业类型','制造业'),(410,'usercore_user_base','ODS_PTY_AGENT_INFO','CERT_TYPE','coreybr','CERT_TYPE','1','2','机构参与者基本信息','法人证件类型','护照'),(411,'usercore_user_base','ODS_PTY_AGENT_INFO','CERT_TYPE','coreybr','CERT_TYPE','0','1','机构参与者基本信息','法人证件类型','身份证'),(412,'usercore_user_base','ODS_PTY_AGENT_INFO','CERT_TYPE','coreybr','CERT_TYPE','3','99','机构参与者基本信息','法人证件类型','其它'),(413,'usercore_user_base','ODS_PTY_AGENT_INFO','CERT_TYPE','coreybr','CERT_TYPE','2','3','机构参与者基本信息','法人证件类型','军官证'),(414,'usercore_user_business','ODS_PTY_AGENT_OPERATE','INDUSTRY_TYPE','coreybr','INDUSTRY_TYPE','5','6','机构参与者经营信息','行业类型','建筑业'),(415,'usercore_user_business','ODS_PTY_AGENT_OPERATE','INDUSTRY_TYPE','coreybr','INDUSTRY_TYPE','4','5','机构参与者经营信息','行业类型','环境和公共设施管理业'),(416,'t_client_detailinfo','ODS_PTY_USER_ASSET','HOUSE_BELONG','ybrhh1','OWNER_SHIP','3','3','个人参与者资产信息','所有权','本人或配偶的父母'),(417,'t_client_detailinfo','ODS_PTY_USER_ASSET','HOUSE_BELONG','ybrhh1','OWNER_SHIP','2','2','个人参与者资产信息','所有权','成年子女'),(418,'t_client_kinfolk','ODS_PTY_USER_CONTACT','RELATIVE','ybrhh1','CONTACT_RELATION','D','1','个人参与者联系人信息','关系','配偶'),(419,'t_client_unit','ODS_PTY_USER_WORK','UNIT_TYPE','ybrhh1','COMPANY_TYPE','07','99','个人参与者职业信息','单位性质','其它'),(420,'t_client_kinfolk','ODS_PTY_USER_CONTACT','RELATIVE','ybrhh1','CONTACT_RELATION','E','2','个人参与者联系人信息','关系','父母'),(421,'t_client_kinfolk','ODS_PTY_USER_CONTACT','RELATIVE','ybrhh1','CONTACT_RELATION','F','4','个人参与者联系人信息','关系','子女'),(422,'t_client_kinfolk','ODS_PTY_USER_CONTACT','FLAG','ybrhh1','DATA_FROM','1','1','个人参与者联系人信息','数据来源','申请时录入'),(423,'t_client_kinfolk','ODS_PTY_USER_CONTACT','RELATIVE','ybrhh1','CONTACT_RELATION','Z','99','个人参与者联系人信息','关系','其他'),(424,'t_client_detailinfo','ODS_PTY_USER_ASSET','HOUSE_BELONG','ybrhh1','OWNER_SHIP','1','1','个人参与者资产信息','所有权','本人或者配偶'),(425,'t_client_kinfolk','ODS_PTY_USER_CONTACT','FLAG','ybrhh1','DATA_FROM','2','2','个人参与者联系人信息','数据来源','签约时录入'),(426,'asset_recharge_withdraw_detail','ODS_EVT_RECHARGE','RW_NET_TYPE','coreybr','NET_TYPE','1','1','充值事件表','网络类型','网关'),(427,'asset_recharge_withdraw_detail','ODS_EVT_RECHARGE','RW_NET_TYPE','coreybr','NET_TYPE','2','2','充值事件表','网络类型','快捷'),(428,'usercore_login_record','ODS_EVT_LOGIN','STATUS','coreybr','LOGIN_STATUS','1','2','登陆事件表','登录状态','失败'),(429,'usercore_login_record','ODS_EVT_LOGIN','TERMINAL','coreybr','TERMINAL_TYPE','0','1','登陆事件表','终端类型','web端'),(430,'usercore_login_record','ODS_EVT_LOGIN','TERMINAL','coreybr','TERMINAL_TYPE','1','2','登陆事件表','终端类型','app端'),(431,'usercore_login_record','ODS_EVT_LOGIN','TERMINAL','coreybr','TERMINAL_TYPE','2','3','登陆事件表','终端类型','微信'),(432,'usercore_login_record','ODS_EVT_LOGIN','LOGIN_MODE','coreybr','LOGIN_MODE','0','1','登陆事件表','登录方式','平台账号登录'),(433,'usercore_login_record','ODS_EVT_LOGIN','LOGIN_MODE','coreybr','LOGIN_MODE','1','2','登陆事件表','登录方式','联合登录'),(434,'asset_recharge_withdraw_detail','ODS_EVT_RECHARGE','FEE_MODE','coreybr','FEE_MODE','1','1','充值事件表','收费方式','费用内扣'),(435,'asset_recharge_withdraw_detail','ODS_EVT_RECHARGE','FEE_MODE','coreybr','FEE_MODE','2','2','充值事件表','收费方式','费用外扣'),(436,'sellbiz_sell_transfer_relate','ODS_AGT_SEL_TRN_RELATE','STATUS','bizybr','STATUS','7','8','卖出单转让单关联表','状态','支付处理中'),(437,'sellbiz_sell_transfer_relate','ODS_AGT_SEL_TRN_RELATE','STATUS','bizybr','STATUS','6','7','卖出单转让单关联表','状态','支付失败'),(438,'sellbiz_sell_transfer_relate','ODS_AGT_SEL_TRN_RELATE','STATUS','bizybr','STATUS','5','6','卖出单转让单关联表','状态','支付成功'),(439,'sellbiz_sell_transfer_relate','ODS_AGT_SEL_TRN_RELATE','STATUS','bizybr','STATUS','4','5','卖出单转让单关联表','状态','已取消'),(440,'sellbiz_sell_transfer_relate','ODS_AGT_SEL_TRN_RELATE','STATUS','bizybr','STATUS','3','4','卖出单转让单关联表','状态','支付超时'),(441,'sellbiz_sell_transfer_relate','ODS_AGT_SEL_TRN_RELATE','STATUS','bizybr','STATUS','2','3','卖出单转让单关联表','状态','待确认'),(442,'sellbiz_sell_transfer_relate','ODS_AGT_SEL_TRN_RELATE','STATUS','bizybr','STATUS','1','2','卖出单转让单关联表','状态','待支付'),(443,'sellbiz_sell_transfer_relate','ODS_AGT_SEL_TRN_RELATE','STATUS','bizybr','STATUS','0','1','卖出单转让单关联表','状态','申请中'),(444,'sellbiz_purchase_invest_relate','ODS_AGT_PCH_IVT_RELATE','STATUS','bizybr','STATUS','7','8','申购单投资单关联表','状态','支付处理中'),(445,'sellbiz_purchase_invest_relate','ODS_AGT_PCH_IVT_RELATE','STATUS','bizybr','STATUS','6','7','申购单投资单关联表','状态','支付失败'),(446,'loan_expand_period','ODS_EVT_EXPAND','STATUS','bizybr','STATUS','2','7','展期事件','展期申请状态','审核拒绝'),(447,'loan_expand_period','ODS_EVT_EXPAND','STATUS','bizybr','STATUS','1','6','展期事件','展期申请状态','已审核'),(448,'loan_product','ODS_PRD_P2P_PRODUCT_INFO','STATUS','bizybr','STATUS','3','3','P2P类产品信息表','产品状态','删除'),(449,'loan_product','ODS_PRD_P2P_PRODUCT_INFO','STATUS','bizybr','STATUS','2','2','P2P类产品信息表','产品状态','上架'),(450,'loan_product','ODS_PRD_P2P_PRODUCT_INFO','PRODUCT_TYPE','bizybr','P2P_PRODUCT_TYPE','2','99','P2P类产品信息表','P2P产品类型','其它'),(451,'loan_product','ODS_PRD_P2P_PRODUCT_INFO','PRODUCT_TYPE','bizybr','P2P_PRODUCT_TYPE','1','99','P2P类产品信息表','P2P产品类型','其它'),(452,'loan_product','ODS_PRD_P2P_PRODUCT_INFO','PRODUCT_TYPE','bizybr','P2P_PRODUCT_TYPE','9','2','P2P类产品信息表','P2P产品类型','固定期限'),(453,'loan_product','ODS_PRD_P2P_PRODUCT_INFO','PRODUCT_TYPE','bizybr','P2P_PRODUCT_TYPE','8','1','P2P类产品信息表','P2P产品类型','随借随还'),(454,'loan_product','ODS_PRD_P2P_LOAN_PRODUCT_INFO','REFUND_WAY','bizybr','REFUND_WAY','2','2','P2P借款产品信息表','还款方式','按月付息到期还本'),(455,'loan_product','ODS_PRD_P2P_LOAN_PRODUCT_INFO','REFUND_WAY','bizybr','REFUND_WAY','1','1','P2P借款产品信息表','还款方式','到期还本付息'),(456,'loan_product','ODS_PRD_P2P_LOAN_PRODUCT_INFO','REFUND_WAY','bizybr','REFUND_WAY','4','4','P2P借款产品信息表','还款方式','按半年付息到期还本'),(457,'loan_product','ODS_PRD_P2P_LOAN_PRODUCT_INFO','REFUND_WAY','bizybr','REFUND_WAY','3','3','P2P借款产品信息表','还款方式','按季付息到期还本'),(458,'','ODS_EVT_REFUND','','','IS_OVERDUE','','0','还款事件','是否逾期','未逾期'),(459,'asset_outcome_plan','ODS_EVT_REFUND','STATUS','coreybr','REFUND_STATUS','6','7','还款事件','还款状态','已兑付'),(460,'usercore_user_accessory','ODS_PTY_USER_ACCESSORY','TYPE','coreybr','CERT_TYPE','11','12','个人参与者附件资料','附加证件类型','信用卡对账单'),(461,'usercore_user_accessory','ODS_PTY_USER_ACCESSORY','TYPE','coreybr','CERT_TYPE','12','13','个人参与者附件资料','附加证件类型','支付宝截图'),(462,'usercore_user_accessory','ODS_PTY_USER_ACCESSORY','TYPE','coreybr','CERT_TYPE','9','10','个人参与者附件资料','附加证件类型','劳动合同'),(463,'usercore_user_accessory','ODS_PTY_USER_ACCESSORY','TYPE','coreybr','CERT_TYPE','10','11','个人参与者附件资料','附加证件类型','工资卡流水'),(464,'usercore_user_accessory','ODS_PTY_USER_ACCESSORY','TYPE','coreybr','CERT_TYPE','7','8','个人参与者附件资料','附加证件类型','社保公积金缴纳证明'),(465,'usercore_user_accessory','ODS_PTY_USER_ACCESSORY','TYPE','coreybr','CERT_TYPE','8','9','个人参与者附件资料','附加证件类型','结婚证'),(466,'usercore_user_accessory','ODS_PTY_USER_ACCESSORY','TYPE','coreybr','CERT_TYPE','5','6','个人参与者附件资料','附加证件类型','身份证手持'),(467,'usercore_user_accessory','ODS_PTY_USER_ACCESSORY','TYPE','coreybr','CERT_TYPE','6','7','个人参与者附件资料','附加证件类型','工作证明'),(468,'usercore_user_accessory','ODS_PTY_USER_ACCESSORY','TYPE','coreybr','CERT_TYPE','3','4','个人参与者附件资料','附加证件类型','身份证正面'),(469,'usercore_user_accessory','ODS_PTY_USER_ACCESSORY','TYPE','coreybr','CERT_TYPE','4','5','个人参与者附件资料','附加证件类型','身份证反面'),(470,'usercore_user_personal','ODS_PTY_USER_INFO','SEX','coreybr','SEX','0','1','个人参与者基本信息','性别','男'),(471,'t_client_signrecord','ODS_EVT_SIGNRECORD','MSSIND','ybrhh1','MSSIND','0','0','面签记录表','是否接收短信','不接收短信'),(472,'t_client_signrecord','ODS_EVT_SIGNRECORD','MSSIND','ybrhh1','MSSIND','1','1','面签记录表','是否接收短信','接收短信'),(473,'t_client_signrecord','ODS_EVT_SIGNRECORD','SIGN_STATUS','ybrhh1','SIGN_STATUS','4','5','面签记录表','流水状态','拒绝'),(474,'t_client_signrecord','ODS_EVT_SIGNRECORD','SIGN_STATUS','ybrhh1','SIGN_STATUS','5','6','面签记录表','流水状态','已激活未扣费');

/*Table structure for table `ETL_TARGET_TB_SYNC_TIME` */

DROP TABLE IF EXISTS `ETL_TARGET_TB_SYNC_TIME`;

CREATE TABLE `ETL_TARGET_TB_SYNC_TIME` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `target_db` varchar(50) NOT NULL DEFAULT 'odsybr',
  `target_tb_name` varchar(50) NOT NULL,
  `target_tb_comment` varchar(50) DEFAULT NULL,
  `last_sync_time` bigint(13) NOT NULL DEFAULT '0',
  `last_sync_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `db_tb` (`target_tb_name`,`target_db`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8;

/*Data for the table `ETL_TARGET_TB_SYNC_TIME` */

insert  into `ETL_TARGET_TB_SYNC_TIME`(`id`,`target_db`,`target_tb_name`,`target_tb_comment`,`last_sync_time`,`last_sync_datetime`) values (1,'odsybr','ODS_PTY_USER_INFO','个人参与者基本信息',0,'0000-00-00 00:00:00'),(2,'odsybr','ODS_PTY_USER_EDU','个人参与者教育信息',0,'0000-00-00 00:00:00'),(3,'odsybr','ODS_PTY_USER_WORK','个人参与者职业信息',0,'0000-00-00 00:00:00'),(4,'odsybr','ODS_PTY_USER_ASSET','个人参与者资产信息',0,'0000-00-00 00:00:00'),(5,'odsybr','ODS_PTY_USER_ACCESSORY','个人参与者附件资料',0,'0000-00-00 00:00:00'),(6,'odsybr','ODS_PTY_USER_CONTACT','个人参与者联系人信息',0,'0000-00-00 00:00:00'),(7,'odsybr','ODS_PTY_USER_BINDCARD','个人参与者绑卡信息',0,'0000-00-00 00:00:00'),(8,'odsybr','ODS_PTY_AGENT_ACCOUNT','机构参与者开户信息',0,'0000-00-00 00:00:00'),(9,'odsybr','ODS_PTY_AGENT_INFO','机构参与者基本信息',0,'0000-00-00 00:00:00'),(10,'odsybr','ODS_PTY_AGENT_OPERATE','机构参与者经营信息',0,'0000-00-00 00:00:00'),(11,'odsybr','ODS_PTY_ROLE','角色',0,'0000-00-00 00:00:00'),(12,'odsybr','ODS_PTY_USER_ROLE','用户角色关系',0,'0000-00-00 00:00:00'),(13,'odsybr','ODS_PTY_USER_BIZ_RELATION','参与者业务关联表',0,'0000-00-00 00:00:00'),(14,'odsybr','ODS_PTY_ACCOUNT_MANAGER','客户经理表',0,'0000-00-00 00:00:00'),(15,'odsybr','ODS_RIC_PRE_CREDIT','预授信表',0,'0000-00-00 00:00:00'),(16,'odsybr','ODS_RIC_CREDIT_HISTORY','授信历史表',0,'0000-00-00 00:00:00'),(17,'odsybr','ODS_RIC_CREDIT_AMOUNT','授信额度表',0,'0000-00-00 00:00:00'),(18,'odsybr','ODS_RIC_CREDIT_ENHANCE','客户增信信息表',0,'0000-00-00 00:00:00'),(19,'odsybr','ODS_PRD_PRODUCT_INFO','产品信息表',0,'0000-00-00 00:00:00'),(20,'odsybr','ODS_PRD_P2P_PRODUCT_INFO','P2P类产品信息表',0,'0000-00-00 00:00:00'),(21,'odsybr','ODS_PRD_P2P_LOAN_PRODUCT_INFO','P2P借款产品信息表',0,'0000-00-00 00:00:00'),(22,'odsybr','ODS_AGT_INVEST_VCHR','投资单据',0,'0000-00-00 00:00:00'),(23,'odsybr','ODS_AGT_PURCHASE_VCHR','申购单据',0,'0000-00-00 00:00:00'),(24,'odsybr','ODS_AGT_SELL_VCHR','卖出单据',0,'0000-00-00 00:00:00'),(25,'odsybr','ODS_AGT_TRANSFER_VCHR','转让单据',0,'0000-00-00 00:00:00'),(26,'odsybr','ODS_AGT_PCH_IVT_RELATE','申购单投资单关联表',0,'0000-00-00 00:00:00'),(27,'odsybr','ODS_AGT_SEL_TRN_RELATE','卖出单转让单关联表',0,'0000-00-00 00:00:00'),(28,'odsybr','ODS_AGT_ACCOUNT','账户表',0,'0000-00-00 00:00:00'),(29,'odsybr','ODS_AGT_ACCT_BRW','借款账户表',0,'0000-00-00 00:00:00'),(30,'odsybr','ODS_AGT_ACCT_IVT','投资账户表',0,'0000-00-00 00:00:00'),(31,'odsybr','ODS_AGT_ACCT_SCORE','积分账户',0,'0000-00-00 00:00:00'),(32,'odsybr','ODS_AGT_ACCT_REBATE','红包账户',0,'0000-00-00 00:00:00'),(33,'odsybr','ODS_EVT_REGISTER','注册事件表',0,'0000-00-00 00:00:00'),(34,'odsybr','ODS_EVT_LOGIN','登陆事件表',0,'0000-00-00 00:00:00'),(35,'odsybr','ODS_EVT_RECHARGE','充值事件表',0,'0000-00-00 00:00:00'),(36,'odsybr','ODS_EVT_WITHDRAW','提现事件表',0,'0000-00-00 00:00:00'),(37,'odsybr','ODS_EVT_INVEST','投资事件',0,'0000-00-00 00:00:00'),(38,'odsybr','ODS_EVT_PURCHASE','申购事件',0,'0000-00-00 00:00:00'),(39,'odsybr','ODS_EVT_TRANSFER','转让事件',0,'0000-00-00 00:00:00'),(40,'odsybr','ODS_EVT_SELL','卖出事件',0,'0000-00-00 00:00:00'),(41,'odsybr','ODS_EVT_BORROW','借款事件',0,'0000-00-00 00:00:00'),(42,'odsybr','ODS_EVT_REFUND','还款事件',0,'0000-00-00 00:00:00'),(43,'odsybr','ODS_EVT_OVERDUE','逾期事件',0,'0000-00-00 00:00:00'),(44,'odsybr','ODS_EVT_EXPAND','展期事件',0,'0000-00-00 00:00:00'),(45,'odsybr','ODS_EVT_COMPENSATE','代偿事件',0,'0000-00-00 00:00:00'),(46,'odsybr','ODS_EVT_CLEAR','核销事件',0,'0000-00-00 00:00:00'),(47,'odsybr','ODS_EVT_REFEREE','推荐事件表',0,'0000-00-00 00:00:00'),(48,'odsybr','ODS_EVT_APPLY','进件事件表',0,'0000-00-00 00:00:00'),(49,'odsybr','ODS_EVT_SIGNRECORD','面签记录表',0,'0000-00-00 00:00:00'),(50,'odsybr','ODS_FIN_P2P_FINANCE_INFO','P2P财务信息表',0,'0000-00-00 00:00:00'),(51,'odsybr','ODS_FIN_P2P_ASSET_INFO','P2P资产信息表',0,'0000-00-00 00:00:00');

/*Table structure for table `ETL_THEME_TABLE` */

DROP TABLE IF EXISTS `ETL_THEME_TABLE`;

CREATE TABLE `ETL_THEME_TABLE` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `theme` varchar(100) NOT NULL COMMENT '主题',
  `target_tb_name` varchar(100) NOT NULL COMMENT '目标表',
  `target_tb_comment` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `theme_table` (`theme`,`target_tb_name`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8;

/*Data for the table `ETL_THEME_TABLE` */

insert  into `ETL_THEME_TABLE`(`id`,`theme`,`target_tb_name`,`target_tb_comment`) values (1,'participant_theme','ODS_PTY_USER_INFO','个人参与者基本信息'),(2,'participant_theme','ODS_PTY_USER_EDU','个人参与者教育信息'),(3,'participant_theme','ODS_PTY_USER_WORK','个人参与者职业信息'),(4,'participant_theme','ODS_PTY_USER_ASSET','个人参与者资产信息'),(5,'participant_theme','ODS_PTY_USER_ACCESSORY','个人参与者附件资料'),(6,'participant_theme','ODS_PTY_USER_CONTACT','个人参与者联系人信息'),(7,'participant_theme','ODS_PTY_USER_BINDCARD','个人参与者绑卡信息'),(8,'participant_theme','ODS_PTY_AGENT_ACCOUNT','机构参与者开户信息'),(9,'participant_theme','ODS_PTY_AGENT_INFO','机构参与者基本信息'),(10,'participant_theme','ODS_PTY_AGENT_OPERATE','机构参与者经营信息'),(11,'participant_theme','ODS_PTY_ROLE','角色'),(12,'participant_theme','ODS_PTY_USER_ROLE','用户角色关系'),(13,'participant_theme','ODS_PTY_USER_BIZ_RELATION','参与者业务关联表'),(14,'participant_theme','ODS_PTY_ACCOUNT_MANAGER','客户经理表'),(15,'wind_control_theme','ODS_RIC_PRE_CREDIT','预授信表'),(16,'wind_control_theme','ODS_RIC_CREDIT_HISTORY','授信历史表'),(17,'wind_control_theme','ODS_RIC_CREDIT_AMOUNT','授信额度表'),(18,'wind_control_theme','ODS_RIC_CREDIT_ENHANCE','客户增信信息表'),(19,'product_theme','ODS_PRD_PRODUCT_INFO','产品信息表'),(20,'product_theme','ODS_PRD_P2P_PRODUCT_INFO','P2P类产品信息表'),(21,'product_theme','ODS_PRD_P2P_LOAN_PRODUCT_INFO','P2P借款产品信息表'),(22,'protocol_theme','ODS_AGT_INVEST_VCHR','投资单据'),(23,'protocol_theme','ODS_AGT_PURCHASE_VCHR','申购单据'),(24,'protocol_theme','ODS_AGT_SELL_VCHR','卖出单据'),(25,'protocol_theme','ODS_AGT_TRANSFER_VCHR','转让单据'),(26,'protocol_theme','ODS_AGT_PCH_IVT_RELATE','申购单投资单关联表'),(27,'protocol_theme','ODS_AGT_SEL_TRN_RELATE','卖出单转让单关联表'),(28,'protocol_theme','ODS_AGT_ACCOUNT','账户表'),(29,'protocol_theme','ODS_AGT_ACCT_BRW','借款账户表'),(30,'protocol_theme','ODS_AGT_ACCT_IVT','投资账户表'),(31,'protocol_theme','ODS_AGT_ACCT_SCORE','积分账户'),(32,'protocol_theme','ODS_AGT_ACCT_REBATE','红包账户'),(33,'event_theme','ODS_EVT_REGISTER','注册事件表'),(34,'event_theme','ODS_EVT_LOGIN','登陆事件表'),(35,'event_theme','ODS_EVT_RECHARGE','充值事件表'),(36,'event_theme','ODS_EVT_WITHDRAW','提现事件表'),(37,'event_theme','ODS_EVT_INVEST','投资事件'),(38,'event_theme','ODS_EVT_PURCHASE','申购事件'),(39,'event_theme','ODS_EVT_TRANSFER','转让事件'),(40,'event_theme','ODS_EVT_SELL','卖出事件'),(41,'event_theme','ODS_EVT_BORROW','借款事件'),(42,'event_theme','ODS_EVT_REFUND','还款事件'),(43,'event_theme','ODS_EVT_OVERDUE','逾期事件'),(44,'event_theme','ODS_EVT_EXPAND','展期事件'),(45,'event_theme','ODS_EVT_COMPENSATE','代偿事件'),(46,'event_theme','ODS_EVT_CLEAR','核销事件'),(47,'event_theme','ODS_EVT_REFEREE','推荐事件表'),(48,'event_theme','ODS_EVT_APPLY','进件事件表'),(49,'event_theme','ODS_EVT_SIGNRECORD','面签记录表'),(50,'financial_theme','ODS_FIN_P2P_FINANCE_INFO','P2P财务信息表'),(51,'financial_theme','ODS_FIN_P2P_ASSET_INFO','P2P资产信息表');

/*Table structure for table `ODS_AGT_ACCOUNT` */

DROP TABLE IF EXISTS `ODS_AGT_ACCOUNT`;

CREATE TABLE `ODS_AGT_ACCOUNT` (
  `ACCOUNT_ID` varchar(64) NOT NULL COMMENT '账户编号',
  `ACCT_TYPE` int(3) DEFAULT NULL COMMENT '账户类型EnumAccountType',
  `CURRENCY` char(3) DEFAULT NULL COMMENT '币种EnumCurrencyType',
  `USER_ID` varchar(64) DEFAULT NULL COMMENT '用户编号',
  `OWNER_TYPE` int(3) DEFAULT NULL COMMENT '属主类型EnumOwnershipType',
  `OPEN_ORG_TYPE` int(3) DEFAULT NULL COMMENT '帐户开户机构类型EnumOrgType',
  `OPEN_ORG_CODE` varchar(64) DEFAULT NULL COMMENT '账户开户机构号',
  `ACCT_NAME` varchar(64) DEFAULT NULL COMMENT '账户户名',
  `STATUS` int(3) DEFAULT NULL COMMENT '账户状态EnumAccountStatus',
  `ACCOUNT_BIZ_TYPE` int(3) DEFAULT NULL COMMENT '业务类型EnumAccountBizType',
  `CREATE_DATE` datetime DEFAULT NULL COMMENT '创建时间',
  `UPDATE_DATE` datetime DEFAULT NULL COMMENT '更新时间',
  `EXTF1` varchar(5) DEFAULT NULL COMMENT '备用字段1',
  `EXTF2` varchar(20) DEFAULT NULL COMMENT '备用字段2',
  `EXTF3` varchar(50) DEFAULT NULL COMMENT '备用字段3',
  `EXTF4` varchar(200) DEFAULT NULL COMMENT '备用字段4',
  `EXTF5` varchar(1000) DEFAULT NULL COMMENT '备用字段5',
  PRIMARY KEY (`ACCOUNT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='账户表';

/*Data for the table `ODS_AGT_ACCOUNT` */

/*Table structure for table `ODS_AGT_ACCT_BRW` */

DROP TABLE IF EXISTS `ODS_AGT_ACCT_BRW`;

CREATE TABLE `ODS_AGT_ACCT_BRW` (
  `ACCOUNT_ID` varchar(64) NOT NULL COMMENT '账户编号',
  `BORROW_AMOUNT` decimal(18,4) DEFAULT NULL COMMENT '借款金额',
  `BORROW_TIME` datetime DEFAULT NULL COMMENT '借款时间',
  `BORROW_PERIOD` int(5) DEFAULT NULL COMMENT '借款期限',
  `EXTF1` varchar(5) DEFAULT NULL COMMENT '备用字段1',
  `EXTF2` varchar(20) DEFAULT NULL COMMENT '备用字段2',
  `EXTF3` varchar(50) DEFAULT NULL COMMENT '备用字段3',
  `EXTF4` varchar(200) DEFAULT NULL COMMENT '备用字段4',
  `EXTF5` varchar(1000) DEFAULT NULL COMMENT '备用字段5',
  PRIMARY KEY (`ACCOUNT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='借款账户表';

/*Data for the table `ODS_AGT_ACCT_BRW` */

/*Table structure for table `ODS_AGT_ACCT_IVT` */

DROP TABLE IF EXISTS `ODS_AGT_ACCT_IVT`;

CREATE TABLE `ODS_AGT_ACCT_IVT` (
  `ACCOUNT_ID` varchar(64) NOT NULL COMMENT '账户编号',
  `INVEST_AMOUNT` decimal(18,4) DEFAULT NULL COMMENT '投资金额',
  `BALANCE_AVLB` decimal(18,4) DEFAULT NULL COMMENT '可用余额',
  `INVEST_PERIOD` int(5) DEFAULT NULL COMMENT '投资期限',
  `INVEST_PERIOD_UNIT` int(3) DEFAULT NULL COMMENT '投资期限单位',
  `EXTF1` varchar(5) DEFAULT NULL COMMENT '备用字段1',
  `EXTF2` varchar(20) DEFAULT NULL COMMENT '备用字段2',
  `EXTF3` varchar(50) DEFAULT NULL COMMENT '备用字段3',
  `EXTF4` varchar(200) DEFAULT NULL COMMENT '备用字段4',
  `EXTF5` varchar(1000) DEFAULT NULL COMMENT '备用字段5',
  PRIMARY KEY (`ACCOUNT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='投资账户表';

/*Data for the table `ODS_AGT_ACCT_IVT` */

/*Table structure for table `ODS_AGT_ACCT_REBATE` */

DROP TABLE IF EXISTS `ODS_AGT_ACCT_REBATE`;

CREATE TABLE `ODS_AGT_ACCT_REBATE` (
  `ACCOUNT_ID` varchar(64) NOT NULL COMMENT '账户编号',
  `REBATE_AVLB` decimal(18,4) DEFAULT NULL COMMENT '红包余额',
  `REBATE_PERIOD` int(5) DEFAULT NULL COMMENT '红包有效期',
  `REBATE_PERIOD_UNIT` int(3) DEFAULT NULL COMMENT '红包有效期单位',
  `REBATE_TYPE` int(3) DEFAULT NULL COMMENT '红包类型',
  `EXTF1` varchar(5) DEFAULT NULL COMMENT '备用字段1',
  `EXTF2` varchar(20) DEFAULT NULL COMMENT '备用字段2',
  `EXTF3` varchar(50) DEFAULT NULL COMMENT '备用字段3',
  `EXTF4` varchar(200) DEFAULT NULL COMMENT '备用字段4',
  `EXTF5` varchar(1000) DEFAULT NULL COMMENT '备用字段5',
  PRIMARY KEY (`ACCOUNT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='红包账户';

/*Data for the table `ODS_AGT_ACCT_REBATE` */

/*Table structure for table `ODS_AGT_ACCT_SCORE` */

DROP TABLE IF EXISTS `ODS_AGT_ACCT_SCORE`;

CREATE TABLE `ODS_AGT_ACCT_SCORE` (
  `ACCOUNT_ID` varchar(64) NOT NULL COMMENT '账户编号',
  `SCORE_LV` int(5) DEFAULT NULL COMMENT '积分等级',
  `SCORE_AVLB` decimal(18,4) DEFAULT NULL COMMENT '可用积分',
  `SCORE_RULE` varchar(64) DEFAULT NULL COMMENT '积分规则',
  `EXTF1` varchar(5) DEFAULT NULL COMMENT '备用字段1',
  `EXTF2` varchar(20) DEFAULT NULL COMMENT '备用字段2',
  `EXTF3` varchar(50) DEFAULT NULL COMMENT '备用字段3',
  `EXTF4` varchar(200) DEFAULT NULL COMMENT '备用字段4',
  `EXTF5` varchar(1000) DEFAULT NULL COMMENT '备用字段5',
  PRIMARY KEY (`ACCOUNT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='积分账户';

/*Data for the table `ODS_AGT_ACCT_SCORE` */

/*Table structure for table `ODS_AGT_INVEST_VCHR` */

DROP TABLE IF EXISTS `ODS_AGT_INVEST_VCHR`;

CREATE TABLE `ODS_AGT_INVEST_VCHR` (
  `INVOICE_ID` varchar(64) NOT NULL COMMENT '投资单据编号',
  `VCHR_TYPE` varchar(20) DEFAULT NULL COMMENT '投资单据类型',
  `GOODS_ID` varchar(64) DEFAULT NULL COMMENT '商品编号',
  `USER_ID` varchar(64) DEFAULT NULL COMMENT '用户编号',
  `INVEST_AMOUNT` decimal(18,4) DEFAULT NULL COMMENT '投资金额',
  `DISCOUNT_AMOUNT` decimal(18,4) DEFAULT NULL COMMENT '优惠金额',
  `INVEST_NUM` decimal(18,4) DEFAULT NULL COMMENT '投资份额',
  `INVEST_STATUS` int(3) DEFAULT NULL COMMENT '投资状态EnumInvestStatus',
  `CREATE_DATE` datetime DEFAULT NULL COMMENT '创建时间',
  `UPDATE_DATE` datetime DEFAULT NULL COMMENT '修改时间',
  `EXTF1` varchar(5) DEFAULT NULL COMMENT '备用字段1',
  `EXTF2` varchar(20) DEFAULT NULL COMMENT '备用字段2',
  `EXTF3` varchar(50) DEFAULT NULL COMMENT '备用字段3',
  `EXTF4` varchar(200) DEFAULT NULL COMMENT '备用字段4',
  `EXTF5` varchar(1000) DEFAULT NULL COMMENT '备用字段5',
  PRIMARY KEY (`INVOICE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='投资单据';

/*Data for the table `ODS_AGT_INVEST_VCHR` */

/*Table structure for table `ODS_AGT_PCH_IVT_RELATE` */

DROP TABLE IF EXISTS `ODS_AGT_PCH_IVT_RELATE`;

CREATE TABLE `ODS_AGT_PCH_IVT_RELATE` (
  `RELATE_ID` varchar(64) NOT NULL COMMENT '关联编号',
  `PURCHASE_VCHR_ID` varchar(64) DEFAULT NULL COMMENT '申购单编号',
  `SELL_VCHR_ID` varchar(64) DEFAULT NULL COMMENT '卖出单编号',
  `INVEST_VCHR_ID` varchar(64) DEFAULT NULL COMMENT '投资单编号',
  `CONFIRM_SHARE` decimal(18,4) DEFAULT NULL COMMENT '确认份额',
  `HOLD_SHARE` decimal(18,4) DEFAULT NULL COMMENT '持有份额',
  `CANTRANSFER_SHARE` decimal(18,4) DEFAULT NULL COMMENT '可转份额',
  `ONSALE_SHARE` decimal(18,4) DEFAULT NULL COMMENT '在转份额',
  `FROZEN_SHARE` decimal(18,4) DEFAULT NULL COMMENT '冻结份额',
  `GOODS_ID` varchar(64) DEFAULT NULL COMMENT '商品编号',
  `STATUS` int(3) DEFAULT NULL COMMENT '状态EnumInvestStatus',
  `CREATE_DATE` datetime DEFAULT NULL COMMENT '创建时间',
  `UPDATE_DATE` datetime DEFAULT NULL COMMENT '修改时间',
  `EXTF1` varchar(5) DEFAULT NULL COMMENT '备用字段1',
  `EXTF2` varchar(20) DEFAULT NULL COMMENT '备用字段2',
  `EXTF3` varchar(50) DEFAULT NULL COMMENT '备用字段3',
  `EXTF4` varchar(200) DEFAULT NULL COMMENT '备用字段4',
  `EXTF5` varchar(1000) DEFAULT NULL COMMENT '备用字段5',
  PRIMARY KEY (`RELATE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='申购单投资单关联表';

/*Data for the table `ODS_AGT_PCH_IVT_RELATE` */

/*Table structure for table `ODS_AGT_PURCHASE_VCHR` */

DROP TABLE IF EXISTS `ODS_AGT_PURCHASE_VCHR`;

CREATE TABLE `ODS_AGT_PURCHASE_VCHR` (
  `INVOICE_ID` varchar(64) NOT NULL COMMENT '申购单编号',
  `PURCHASE_TYPE` varchar(20) DEFAULT NULL COMMENT '申购单类型',
  `PRODUCT_TYPE` int(3) DEFAULT NULL COMMENT '投资产品类型EnumInvestProductType',
  `GOODS_ID` varchar(64) DEFAULT NULL COMMENT '商品编号',
  `USER_ID` varchar(64) DEFAULT NULL COMMENT '用户编号',
  `USER_ROLE` int(3) DEFAULT NULL COMMENT '用户角色EnumRoleType',
  `PURCHASE_SHARE` decimal(18,4) DEFAULT NULL COMMENT '申购份额',
  `DONE_SHARE` decimal(18,4) DEFAULT NULL COMMENT '已申购份额',
  `LEFT_SHARE` decimal(18,4) DEFAULT NULL COMMENT '可申购份额',
  `FROZEN_SHARE` decimal(18,4) DEFAULT NULL COMMENT '冻结份额',
  `CANCEL_SHARE` decimal(18,4) DEFAULT NULL COMMENT '撤销份额',
  `TRANSFER_SHARE` decimal(18,4) DEFAULT NULL COMMENT '转出份额',
  `CANTRANSFER_SHARE` decimal(18,4) DEFAULT NULL COMMENT '可转份额',
  `PURCHASE_STATUS` int(3) DEFAULT NULL COMMENT '申购单状态EnumPurchaseVchrStatus',
  `APPLY_TIME` datetime DEFAULT NULL COMMENT '申购时间',
  `END_TIME` datetime DEFAULT NULL COMMENT '到期时间',
  `CREATE_DATE` datetime DEFAULT NULL COMMENT '创建时间',
  `UPDATE_DATE` datetime DEFAULT NULL COMMENT '修改时间',
  `CHANNEL` varchar(64) DEFAULT NULL COMMENT '渠道EnumChannel(无)',
  `IS_AUTO` int(3) DEFAULT NULL COMMENT '是否自动EnumBoolean',
  `INTEREST` decimal(18,4) DEFAULT NULL COMMENT '利息',
  `EXTF1` varchar(5) DEFAULT NULL COMMENT '备用字段1',
  `EXTF2` varchar(20) DEFAULT NULL COMMENT '备用字段2',
  `EXTF3` varchar(50) DEFAULT NULL COMMENT '备用字段3',
  `EXTF4` varchar(200) DEFAULT NULL COMMENT '备用字段4',
  `EXTF5` varchar(1000) DEFAULT NULL COMMENT '备用字段5',
  PRIMARY KEY (`INVOICE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='申购单据';

/*Data for the table `ODS_AGT_PURCHASE_VCHR` */

/*Table structure for table `ODS_AGT_SELL_VCHR` */

DROP TABLE IF EXISTS `ODS_AGT_SELL_VCHR`;

CREATE TABLE `ODS_AGT_SELL_VCHR` (
  `INVOICE_ID` varchar(64) NOT NULL COMMENT '卖出单编号',
  `PURCHASE_VCHR_ID` varchar(64) DEFAULT NULL COMMENT '原申购单编号',
  `GOODS_ID` varchar(64) DEFAULT NULL COMMENT '商品编号',
  `USER_ID` varchar(64) DEFAULT NULL COMMENT '用户编号',
  `SELL_TYPE` int(3) DEFAULT NULL COMMENT '卖出单类型EnumSellVchrType',
  `PRODUCT_TYPE` int(3) DEFAULT NULL COMMENT '投资产品类型EnumInvestProductType',
  `USER_ROLE` int(3) DEFAULT NULL COMMENT '用户角色EnumRoleType',
  `SELL_SHARE` decimal(18,4) DEFAULT NULL COMMENT '卖出份额',
  `DONE_SHARE` decimal(18,4) DEFAULT NULL COMMENT '已卖出份额',
  `LEFT_SHARE` decimal(18,4) DEFAULT NULL COMMENT '可卖出份额',
  `FROZEN_SHARE` decimal(18,4) DEFAULT NULL COMMENT '冻结份额',
  `CANCEL_SHARE` decimal(18,4) DEFAULT NULL COMMENT '撤销份额',
  `SELL_STATUS` int(3) DEFAULT NULL COMMENT '卖出单状态EnumPurchaseVchrStatus',
  `APPLY_TIME` datetime DEFAULT NULL COMMENT '申购时间',
  `CREATE_DATE` datetime DEFAULT NULL COMMENT '创建时间',
  `UPDATE_DATE` datetime DEFAULT NULL COMMENT '修改时间',
  `CHANNEL` varchar(64) DEFAULT NULL COMMENT '渠道EnumChannel(无)',
  `IS_AUTO` int(3) DEFAULT NULL COMMENT '是否自动EnumBoolean',
  `INTEREST` decimal(18,4) DEFAULT NULL COMMENT '利息',
  `EXTF1` varchar(5) DEFAULT NULL COMMENT '备用字段1',
  `EXTF2` varchar(20) DEFAULT NULL COMMENT '备用字段2',
  `EXTF3` varchar(50) DEFAULT NULL COMMENT '备用字段3',
  `EXTF4` varchar(200) DEFAULT NULL COMMENT '备用字段4',
  `EXTF5` varchar(1000) DEFAULT NULL COMMENT '备用字段5',
  PRIMARY KEY (`INVOICE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='卖出单据';

/*Data for the table `ODS_AGT_SELL_VCHR` */

/*Table structure for table `ODS_AGT_SEL_TRN_RELATE` */

DROP TABLE IF EXISTS `ODS_AGT_SEL_TRN_RELATE`;

CREATE TABLE `ODS_AGT_SEL_TRN_RELATE` (
  `RELATE_ID` varchar(64) NOT NULL COMMENT '关联编号',
  `INVEST_VCHR_NO` varchar(64) DEFAULT NULL COMMENT '投资单编号',
  `PURCHASE_VCHR_NO` varchar(64) DEFAULT NULL COMMENT '申购单编号',
  `SELL_VCHR_NO` varchar(64) DEFAULT NULL COMMENT '卖出单编号',
  `TRANSFER_VCHR_NO` varchar(64) DEFAULT NULL COMMENT '转让单编号',
  `SHARE` decimal(18,4) DEFAULT NULL COMMENT '份额',
  `PRICE` decimal(18,4) DEFAULT NULL COMMENT '单价',
  `GOODS_ID` varchar(64) DEFAULT NULL COMMENT '商品编号',
  `STATUS` int(3) DEFAULT NULL COMMENT '状态EnumInvestStatus',
  `CREATE_DATE` datetime DEFAULT NULL COMMENT '创建时间',
  `UPDATE_DATE` datetime DEFAULT NULL COMMENT '修改时间',
  `EXTF1` varchar(5) DEFAULT NULL COMMENT '备用字段1',
  `EXTF2` varchar(20) DEFAULT NULL COMMENT '备用字段2',
  `EXTF3` varchar(50) DEFAULT NULL COMMENT '备用字段3',
  `EXTF4` varchar(200) DEFAULT NULL COMMENT '备用字段4',
  `EXTF5` varchar(1000) DEFAULT NULL COMMENT '备用字段5',
  PRIMARY KEY (`RELATE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='卖出单转让单关联表';

/*Data for the table `ODS_AGT_SEL_TRN_RELATE` */

/*Table structure for table `ODS_AGT_TRANSFER_VCHR` */

DROP TABLE IF EXISTS `ODS_AGT_TRANSFER_VCHR`;

CREATE TABLE `ODS_AGT_TRANSFER_VCHR` (
  `INVOICE_ID` varchar(64) NOT NULL COMMENT '转让单据编号',
  `GOODS_ID` varchar(64) DEFAULT NULL COMMENT '商品编号',
  `USER_ID` varchar(64) DEFAULT NULL COMMENT '转让人编号',
  `TRANSFER_NUM` decimal(18,4) DEFAULT NULL COMMENT '转让份额',
  `RESIDUE_NUM` decimal(18,4) DEFAULT NULL COMMENT '剩余份额',
  `TRANSFER_AMOUNT` decimal(18,4) DEFAULT NULL COMMENT '转让金额',
  `TRANSFER_PRICE` decimal(18,4) DEFAULT NULL COMMENT '转让单价',
  `TRANSFER_DATE` datetime DEFAULT NULL COMMENT '转让日期',
  `TRANSFER_STATE` int(3) DEFAULT NULL COMMENT '转让单状态EnumTransferVchrStatus',
  `TRANSFER_DEPOSIT_RATE` decimal(18,4) DEFAULT NULL COMMENT '转让折扣率',
  `EXTF1` varchar(5) DEFAULT NULL COMMENT '备用字段1',
  `EXTF2` varchar(20) DEFAULT NULL COMMENT '备用字段2',
  `EXTF3` varchar(50) DEFAULT NULL COMMENT '备用字段3',
  `EXTF4` varchar(200) DEFAULT NULL COMMENT '备用字段4',
  `EXTF5` varchar(1000) DEFAULT NULL COMMENT '备用字段5',
  PRIMARY KEY (`INVOICE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='转让单据';

/*Data for the table `ODS_AGT_TRANSFER_VCHR` */

/*Table structure for table `ODS_EVT_APPLY` */

DROP TABLE IF EXISTS `ODS_EVT_APPLY`;

CREATE TABLE `ODS_EVT_APPLY` (
  `APPLY_ID` varchar(64) NOT NULL COMMENT '进件编号',
  `USER_ID` varchar(64) DEFAULT NULL COMMENT '用户编号',
  `CREDIT_CARD_NO` varchar(64) DEFAULT NULL COMMENT '信用卡号',
  `CREDIT_LIMIT` decimal(18,2) DEFAULT NULL COMMENT '额度',
  `IS_ACT_AMT` int(3) DEFAULT NULL COMMENT '是否实际额度EnumBoolean',
  `PROCESS` int(3) DEFAULT NULL COMMENT '授信进度EnumCreditProcess',
  `IS_DELETED` int(3) DEFAULT NULL COMMENT '是否删除EnumBoolean',
  `LIMIT_START_DATE` datetime DEFAULT NULL COMMENT '额度开始日期',
  `LIMIT_END_DATE` datetime DEFAULT NULL COMMENT '额度结束日期',
  `HIGHEST_CREDIT` decimal(18,2) DEFAULT NULL COMMENT '最高额度',
  `CREDIT_RATE` varchar(20) DEFAULT NULL COMMENT '信用等级',
  `CREDIT_SCORE` varchar(20) DEFAULT NULL COMMENT '信用评分',
  `CREDIT_DATE` datetime DEFAULT NULL COMMENT '授信日期',
  `FINAL_DECISION` varchar(20) DEFAULT NULL COMMENT '审批结果',
  `DECISION_REASON` varchar(5) DEFAULT NULL COMMENT '原因描述代码EnumReasonCode',
  `CREATE_DATE` datetime DEFAULT NULL COMMENT '创建日期',
  `UPDATE_DATE` datetime DEFAULT NULL COMMENT '最后修改时间',
  `EXTF1` varchar(5) DEFAULT NULL COMMENT '备用字段1',
  `EXTF2` varchar(20) DEFAULT NULL COMMENT '备用字段2',
  `EXTF3` varchar(50) DEFAULT NULL COMMENT '备用字段3',
  `EXTF4` varchar(200) DEFAULT NULL COMMENT '备用字段4',
  `EXTF5` varchar(1000) DEFAULT NULL COMMENT '备用字段5',
  PRIMARY KEY (`APPLY_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='进件事件表';

/*Data for the table `ODS_EVT_APPLY` */

/*Table structure for table `ODS_EVT_BORROW` */

DROP TABLE IF EXISTS `ODS_EVT_BORROW`;

CREATE TABLE `ODS_EVT_BORROW` (
  `BORROW_APPLY_ID` varchar(64) NOT NULL COMMENT '借款申请编号',
  `PRODUCT_ID` varchar(64) DEFAULT NULL COMMENT '信贷产品编号',
  `USER_ID` varchar(64) DEFAULT NULL COMMENT '用户编号',
  `GOODS_ID` varchar(64) DEFAULT NULL COMMENT '商品编号',
  `CHANNEL` int(3) DEFAULT NULL COMMENT '申请渠道EnumChannel',
  `BORROW_AMOUNT` decimal(18,4) DEFAULT NULL COMMENT '借款金额',
  `LOAN_AMOUNT` decimal(18,4) DEFAULT NULL COMMENT '放款金额',
  `BORROW_GOAL` varchar(300) DEFAULT NULL COMMENT '借款目的',
  `BORROW_PERIOD` int(11) DEFAULT NULL COMMENT '借款期限EnumPeriodUnit',
  `BORROW_PERIOD_UNIT` int(3) DEFAULT NULL COMMENT '借款期限单位',
  `BORROW_RATE` decimal(18,4) DEFAULT NULL COMMENT '借款基础利率',
  `INCREMENT_RATE` decimal(18,4) DEFAULT NULL COMMENT '加点利率',
  `SERVICE_RATE` decimal(18,4) DEFAULT NULL COMMENT '服务费率',
  `SERVICE_AMOUNT` decimal(18,4) DEFAULT NULL COMMENT '服务费金额',
  `ASSURE_RATE` decimal(18,4) DEFAULT NULL COMMENT '担保费率',
  `RISK_RATE` decimal(18,4) DEFAULT NULL COMMENT '风险准备金费率',
  `REFUND_WAY` int(3) DEFAULT NULL COMMENT '还款方式EnumRefundWay',
  `RAISE_PERIOD_LIMIT` varchar(20) DEFAULT NULL COMMENT '募集期限',
  `STATUS` int(3) DEFAULT NULL COMMENT '借款申请状态EnumApplyStatus',
  `USER_TYPE` int(3) DEFAULT NULL COMMENT '用户类型EnumRoleType',
  `COMMENT` varchar(300) DEFAULT NULL COMMENT '审核意见',
  `EXTF1` varchar(5) DEFAULT NULL COMMENT '备用字段1',
  `EXTF2` varchar(20) DEFAULT NULL COMMENT '备用字段2',
  `EXTF3` varchar(50) DEFAULT NULL COMMENT '备用字段3',
  `EXTF4` varchar(200) DEFAULT NULL COMMENT '备用字段4',
  `EXTF5` varchar(1000) DEFAULT NULL COMMENT '备用字段5',
  PRIMARY KEY (`BORROW_APPLY_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='借款事件';

/*Data for the table `ODS_EVT_BORROW` */

/*Table structure for table `ODS_EVT_CLEAR` */

DROP TABLE IF EXISTS `ODS_EVT_CLEAR`;

CREATE TABLE `ODS_EVT_CLEAR` (
  `CLEAR_ID` varchar(64) NOT NULL COMMENT '核销编号',
  `GOODS_ID` varchar(64) DEFAULT NULL COMMENT '商品编号',
  `USER_ID` varchar(64) DEFAULT NULL COMMENT '用户编号',
  `CLEAR_PRINCIPAL_AMT` decimal(18,4) DEFAULT NULL COMMENT '核销本金金额',
  `PLENTY_AMT` decimal(18,4) DEFAULT NULL COMMENT '核销罚息',
  `CLEAR_FEE_AMT` decimal(18,4) DEFAULT NULL COMMENT '核销服务费',
  `CLEAR_TYPE` varchar(20) DEFAULT NULL COMMENT '核销类型',
  `CLEAR_ORDER_ID` varchar(64) DEFAULT NULL COMMENT '核销订单号',
  `ITEM` varchar(20) DEFAULT NULL COMMENT '核销还款计划期次',
  `STATUS` varchar(20) DEFAULT NULL COMMENT '核销状态',
  `EXTF1` varchar(5) DEFAULT NULL COMMENT '备用字段1',
  `EXTF2` varchar(20) DEFAULT NULL COMMENT '备用字段2',
  `EXTF3` varchar(50) DEFAULT NULL COMMENT '备用字段3',
  `EXTF4` varchar(200) DEFAULT NULL COMMENT '备用字段4',
  `EXTF5` varchar(1000) DEFAULT NULL COMMENT '备用字段5',
  PRIMARY KEY (`CLEAR_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='核销事件';

/*Data for the table `ODS_EVT_CLEAR` */

/*Table structure for table `ODS_EVT_COMPENSATE` */

DROP TABLE IF EXISTS `ODS_EVT_COMPENSATE`;

CREATE TABLE `ODS_EVT_COMPENSATE` (
  `COMPENSATE_ID` varchar(64) NOT NULL COMMENT '代偿编号',
  `GOODS_ID` varchar(64) DEFAULT NULL COMMENT '商品编号',
  `USER_ID` varchar(64) DEFAULT NULL COMMENT '用户编号',
  `CURRENT_ITEM` varchar(20) DEFAULT NULL COMMENT '当前期次',
  `SUM_ITEM` varchar(20) DEFAULT NULL COMMENT '总期次',
  `RATE` decimal(18,4) DEFAULT NULL COMMENT '利率',
  `DELAYED_PRINCIPLE` decimal(18,4) DEFAULT NULL COMMENT '代偿本金',
  `DELAYED_INTEREST` decimal(18,4) DEFAULT NULL COMMENT '代偿利息',
  `DELAYED_SUM_AMT` decimal(18,4) DEFAULT NULL COMMENT '代偿总金额',
  `PENALTY_AMT` decimal(18,4) DEFAULT NULL COMMENT '罚息',
  `FEE` decimal(18,4) DEFAULT NULL COMMENT '手续费',
  `COMPENSATE_ACCOUNT_ID` varchar(64) DEFAULT NULL COMMENT '代偿账户',
  `COMPENSATE_ACCOUNT_TYPE` varchar(64) DEFAULT NULL COMMENT '代偿账户类型',
  `DELAYED_RECHARGE_AMT` decimal(18,4) DEFAULT NULL COMMENT '已充值金额',
  `DELAYED_CLEAR_AMT` decimal(18,4) DEFAULT NULL COMMENT '已结清金额',
  `PRE_PLENTY_AMT` decimal(18,4) DEFAULT NULL COMMENT '应付罚息',
  `COMPENSATE_STATUS` int(3) DEFAULT NULL COMMENT '代偿状态EnumCompensateStatus',
  `COMPENSATE_CONFIRM_STATUS` varchar(20) DEFAULT NULL COMMENT '代偿确认状态',
  `COMPENSATE_TYPE` varchar(20) DEFAULT NULL COMMENT '代偿类型',
  `EXTF1` varchar(5) DEFAULT NULL COMMENT '备用字段1',
  `EXTF2` varchar(20) DEFAULT NULL COMMENT '备用字段2',
  `EXTF3` varchar(50) DEFAULT NULL COMMENT '备用字段3',
  `EXTF4` varchar(200) DEFAULT NULL COMMENT '备用字段4',
  `EXTF5` varchar(1000) DEFAULT NULL COMMENT '备用字段5',
  PRIMARY KEY (`COMPENSATE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='代偿事件';

/*Data for the table `ODS_EVT_COMPENSATE` */

/*Table structure for table `ODS_EVT_EXPAND` */

DROP TABLE IF EXISTS `ODS_EVT_EXPAND`;

CREATE TABLE `ODS_EVT_EXPAND` (
  `EXPAND_APPLY_ID` varchar(64) NOT NULL COMMENT '展期申请编号',
  `USER_ID` varchar(64) DEFAULT NULL COMMENT '用户编号',
  `GOODS_ID` varchar(64) DEFAULT NULL COMMENT '商品编号',
  `ITEM` varchar(20) DEFAULT NULL COMMENT '展期期次',
  `ITEM_NUM` varchar(20) DEFAULT NULL COMMENT '已展期数量',
  `ITEM_UNIT` int(3) DEFAULT NULL COMMENT '展期单位EnumPeriodUnit',
  `STATUS` int(3) DEFAULT NULL COMMENT '展期申请状态EnumApplyStatus',
  `EXTF1` varchar(5) DEFAULT NULL COMMENT '备用字段1',
  `EXTF2` varchar(20) DEFAULT NULL COMMENT '备用字段2',
  `EXTF3` varchar(50) DEFAULT NULL COMMENT '备用字段3',
  `EXTF4` varchar(200) DEFAULT NULL COMMENT '备用字段4',
  `EXTF5` varchar(1000) DEFAULT NULL COMMENT '备用字段5',
  PRIMARY KEY (`EXPAND_APPLY_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='展期事件';

/*Data for the table `ODS_EVT_EXPAND` */

/*Table structure for table `ODS_EVT_INVEST` */

DROP TABLE IF EXISTS `ODS_EVT_INVEST`;

CREATE TABLE `ODS_EVT_INVEST` (
  `EVENT_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT '投资事件编号',
  `USER_ID` varchar(64) DEFAULT NULL COMMENT '投资人编号',
  `GOODS_ID` varchar(64) DEFAULT NULL COMMENT '商品编号',
  `INVEST_EVENT_TYPE` varchar(20) DEFAULT NULL COMMENT '投资事件类型',
  `INVEST_AMOUNT` decimal(18,4) DEFAULT NULL COMMENT '投资金额',
  `INVEST_FEE` decimal(18,4) DEFAULT NULL COMMENT '投资手续费',
  `DISCOUNT_AMOUNT` decimal(18,4) DEFAULT NULL COMMENT '优惠金额',
  `INVEST_NUM` decimal(18,4) DEFAULT NULL COMMENT '投资份额',
  `CREATE_DATE` datetime DEFAULT NULL COMMENT '投资事件创建时间',
  `UPDATE_DATE` datetime DEFAULT NULL COMMENT '投资事件修改时间',
  `INVEST_STATUS` int(3) DEFAULT NULL COMMENT '投资状态EnumInvestStatus',
  `EXTF1` varchar(5) DEFAULT NULL COMMENT '备用字段1',
  `EXTF2` varchar(20) DEFAULT NULL COMMENT '备用字段2',
  `EXTF3` varchar(50) DEFAULT NULL COMMENT '备用字段3',
  `EXTF4` varchar(200) DEFAULT NULL COMMENT '备用字段4',
  `EXTF5` varchar(1000) DEFAULT NULL COMMENT '备用字段5',
  PRIMARY KEY (`EVENT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='投资事件';

/*Data for the table `ODS_EVT_INVEST` */

/*Table structure for table `ODS_EVT_LOGIN` */

DROP TABLE IF EXISTS `ODS_EVT_LOGIN`;

CREATE TABLE `ODS_EVT_LOGIN` (
  `EVENT_ID` varchar(64) NOT NULL COMMENT '登录事件编号',
  `USER_ID` varchar(64) DEFAULT NULL COMMENT '用户编号',
  `ACCOUNT` varchar(64) DEFAULT NULL COMMENT '登录账号',
  `LOGIN_TIME` datetime DEFAULT NULL COMMENT '登录时间',
  `LOGIN_IP` varchar(64) DEFAULT NULL COMMENT '登录IP',
  `LOGIN_STATUS` int(3) DEFAULT NULL COMMENT '登录状态EnumLoginStatus',
  `REASON` varchar(64) DEFAULT NULL COMMENT '原因',
  `TERMINAL_TYPE` int(3) DEFAULT NULL COMMENT '终端类型EnumTerminalType',
  `LOGIN_MODE` int(3) DEFAULT NULL COMMENT '登录方式EnumLoginMode',
  `EXTF1` varchar(5) DEFAULT NULL COMMENT '备用字段1',
  `EXTF2` varchar(20) DEFAULT NULL COMMENT '备用字段2',
  `EXTF3` varchar(50) DEFAULT NULL COMMENT '备用字段3',
  `EXTF4` varchar(200) DEFAULT NULL COMMENT '备用字段4',
  `EXTF5` varchar(1000) DEFAULT NULL COMMENT '备用字段5',
  PRIMARY KEY (`EVENT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='登陆事件表';

/*Data for the table `ODS_EVT_LOGIN` */

/*Table structure for table `ODS_EVT_OVERDUE` */

DROP TABLE IF EXISTS `ODS_EVT_OVERDUE`;

CREATE TABLE `ODS_EVT_OVERDUE` (
  `REFUND_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT '还款编号',
  `GOODS_ID` varchar(64) DEFAULT NULL COMMENT '商品编号',
  `USER_ID` varchar(64) DEFAULT NULL COMMENT '用户编号',
  `OVERDUE_ITEM_NUM` varchar(20) DEFAULT NULL COMMENT '逾期期次',
  `OVERDUE_CAP` decimal(18,4) DEFAULT NULL COMMENT '逾期本金',
  `OVERDUE_INTEREST` decimal(18,4) DEFAULT NULL COMMENT '逾期利息',
  `DELAY_AMT` decimal(18,4) DEFAULT NULL COMMENT '逾期罚息',
  `EXTF1` varchar(5) DEFAULT NULL COMMENT '备用字段1',
  `EXTF2` varchar(20) DEFAULT NULL COMMENT '备用字段2',
  `EXTF3` varchar(50) DEFAULT NULL COMMENT '备用字段3',
  `EXTF4` varchar(200) DEFAULT NULL COMMENT '备用字段4',
  `EXTF5` varchar(1000) DEFAULT NULL COMMENT '备用字段5',
  PRIMARY KEY (`REFUND_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='逾期事件';

/*Data for the table `ODS_EVT_OVERDUE` */

/*Table structure for table `ODS_EVT_PURCHASE` */

DROP TABLE IF EXISTS `ODS_EVT_PURCHASE`;

CREATE TABLE `ODS_EVT_PURCHASE` (
  `EVENT_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT '申购事件编号',
  `USER_ID` varchar(64) DEFAULT NULL COMMENT '用户编号',
  `GOODS_ID` varchar(64) DEFAULT NULL COMMENT '商品编号',
  `USER_ROLE` int(3) DEFAULT NULL COMMENT '用户角色EnumRoleType',
  `PURCHASE_EVENT_TYPE` varchar(20) DEFAULT NULL COMMENT '申购事件类型EnumPurchaseType(无)',
  `PRODUCT_TYPE` int(3) DEFAULT NULL COMMENT '投资产品类型EnumInvestProductType',
  `PURCHASE_SHARE` decimal(18,4) DEFAULT NULL COMMENT '申购份额',
  `DONE_SHARE` decimal(18,4) DEFAULT NULL COMMENT '已申购份额',
  `LEFT_SHARE` decimal(18,4) DEFAULT NULL COMMENT '可申购份额',
  `FROZEN_SHARE` decimal(18,4) DEFAULT NULL COMMENT '冻结份额',
  `CANCEL_SHARE` decimal(18,4) DEFAULT NULL COMMENT '撤销份额',
  `TRANSFER_SHARE` decimal(18,4) DEFAULT NULL COMMENT '转出份额',
  `CANTRANSFER_SHARE` decimal(18,4) DEFAULT NULL COMMENT '可转份额',
  `PURCHASE_STATUS` int(3) DEFAULT NULL COMMENT '申购单状态EnumPurchaseVchrStatus',
  `APPLY_TIME` datetime DEFAULT NULL COMMENT '申购时间',
  `END_TIME` datetime DEFAULT NULL COMMENT '到期时间',
  `CREATE_DATE` datetime DEFAULT NULL COMMENT '创建时间',
  `UPDATE_DATE` datetime DEFAULT NULL COMMENT '修改时间',
  `CHANNEL` varchar(64) DEFAULT NULL COMMENT '渠道EnumChannel(无)',
  `IS_AUTO` int(3) DEFAULT NULL COMMENT '是否自动EnumBoolean',
  `INTEREST` decimal(18,4) DEFAULT NULL COMMENT '利息',
  `EXTF1` varchar(5) DEFAULT NULL COMMENT '备用字段1',
  `EXTF2` varchar(20) DEFAULT NULL COMMENT '备用字段2',
  `EXTF3` varchar(50) DEFAULT NULL COMMENT '备用字段3',
  `EXTF4` varchar(200) DEFAULT NULL COMMENT '备用字段4',
  `EXTF5` varchar(1000) DEFAULT NULL COMMENT '备用字段5',
  PRIMARY KEY (`EVENT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='申购事件';

/*Data for the table `ODS_EVT_PURCHASE` */

/*Table structure for table `ODS_EVT_RECHARGE` */

DROP TABLE IF EXISTS `ODS_EVT_RECHARGE`;

CREATE TABLE `ODS_EVT_RECHARGE` (
  `EVENT_ID` varchar(64) NOT NULL COMMENT '充值事件编号',
  `USER_ID` varchar(64) DEFAULT NULL COMMENT '充值人编号',
  `RECHARGE_AMT` decimal(18,4) DEFAULT NULL COMMENT '充值金额',
  `FEE_AMT` decimal(18,4) DEFAULT NULL COMMENT '收费金额',
  `FEE_MODE` int(3) DEFAULT NULL COMMENT '收费方式EnumFeeMode',
  `NET_TYPE` int(3) DEFAULT NULL COMMENT '网络类型EnumNetType',
  `STATUS` int(3) DEFAULT NULL COMMENT '处理状态EnumProcessingStatus',
  `EXTF1` varchar(5) DEFAULT NULL COMMENT '备用字段1',
  `EXTF2` varchar(20) DEFAULT NULL COMMENT '备用字段2',
  `EXTF3` varchar(50) DEFAULT NULL COMMENT '备用字段3',
  `EXTF4` varchar(200) DEFAULT NULL COMMENT '备用字段4',
  `EXTF5` varchar(1000) DEFAULT NULL COMMENT '备用字段5',
  PRIMARY KEY (`EVENT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='充值事件表';

/*Data for the table `ODS_EVT_RECHARGE` */

/*Table structure for table `ODS_EVT_REFEREE` */

DROP TABLE IF EXISTS `ODS_EVT_REFEREE`;

CREATE TABLE `ODS_EVT_REFEREE` (
  `EVENT_ID` varchar(64) NOT NULL COMMENT '推荐事件编号',
  `REFEREE_NO` varchar(64) DEFAULT NULL COMMENT '推荐人编号',
  `REFEREE_MOBILE` varchar(20) DEFAULT NULL COMMENT '推荐人手机号',
  `REFERAL_NO` varchar(64) DEFAULT NULL COMMENT '被推荐人编号',
  `REFERAL_MOBILE` varchar(20) DEFAULT NULL COMMENT '被推荐人手机号',
  `RED_PACKET` decimal(18,4) DEFAULT NULL COMMENT '推荐红包',
  `POINTS` varchar(20) DEFAULT NULL COMMENT '推荐积分',
  `STATUS` int(3) DEFAULT NULL COMMENT '状态EnumBoolean',
  `EXTF1` varchar(5) DEFAULT NULL COMMENT '备用字段1',
  `EXTF2` varchar(20) DEFAULT NULL COMMENT '备用字段2',
  `EXTF3` varchar(50) DEFAULT NULL COMMENT '备用字段3',
  `EXTF4` varchar(200) DEFAULT NULL COMMENT '备用字段4',
  `EXTF5` varchar(1000) DEFAULT NULL COMMENT '备用字段5',
  PRIMARY KEY (`EVENT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='推荐事件表';

/*Data for the table `ODS_EVT_REFEREE` */

/*Table structure for table `ODS_EVT_REFUND` */

DROP TABLE IF EXISTS `ODS_EVT_REFUND`;

CREATE TABLE `ODS_EVT_REFUND` (
  `REFUND_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT '还款编号',
  `GOODS_ID` varchar(64) DEFAULT NULL COMMENT '商品编号',
  `USER_ID` varchar(64) DEFAULT NULL COMMENT '用户编号',
  `PLAN_CURRENT_ITEM` varchar(20) DEFAULT NULL COMMENT '还款当前期数',
  `PLAN_ITEM_TOTAL` varchar(20) DEFAULT NULL COMMENT '还款计划总期数',
  `PLAN_REFUND_DATE` varchar(20) DEFAULT NULL COMMENT '应还日期',
  `REAL_REFUND_DATE` varchar(20) DEFAULT NULL COMMENT '实际还款日期',
  `PRE_REFUND_CAPITAL` decimal(18,4) DEFAULT NULL COMMENT '预期还款本金',
  `PRE_REFUND_INTEREST` decimal(18,4) DEFAULT NULL COMMENT '预期利息金额',
  `PRE_REFUND_FEE` decimal(18,4) DEFAULT NULL COMMENT '预期服务费金额',
  `REFUND_CAPITAL` decimal(18,4) DEFAULT NULL COMMENT '实际还款本金',
  `REFUND_INTEREST` decimal(18,4) DEFAULT NULL COMMENT '实际还款利息',
  `REFUND_FEE` decimal(18,4) DEFAULT NULL COMMENT '实际还款手续费',
  `REFUND_AMOUNT` decimal(18,4) DEFAULT NULL COMMENT '当期还款总额',
  `REFUND_STATUS` int(3) DEFAULT NULL COMMENT '还款状态EnumRefundStatus',
  `IS_OVERDUE` int(3) DEFAULT NULL COMMENT '是否逾期EnumBoolean',
  `EXTF1` varchar(5) DEFAULT NULL COMMENT '备用字段1',
  `EXTF2` varchar(20) DEFAULT NULL COMMENT '备用字段2',
  `EXTF3` varchar(50) DEFAULT NULL COMMENT '备用字段3',
  `EXTF4` varchar(200) DEFAULT NULL COMMENT '备用字段4',
  `EXTF5` varchar(1000) DEFAULT NULL COMMENT '备用字段5',
  PRIMARY KEY (`REFUND_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='还款事件';

/*Data for the table `ODS_EVT_REFUND` */

/*Table structure for table `ODS_EVT_REGISTER` */

DROP TABLE IF EXISTS `ODS_EVT_REGISTER`;

CREATE TABLE `ODS_EVT_REGISTER` (
  `EVENT_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT '注册事件编号',
  `USER_ID` varchar(64) DEFAULT NULL COMMENT '用户编号',
  `USER_TYPE` int(3) DEFAULT NULL COMMENT '用户类型EnumRoleType',
  `IS_BINDCARD` int(3) DEFAULT NULL COMMENT '是否绑卡EnumBoolean',
  `IS_REALNAME` int(3) DEFAULT NULL COMMENT '是否实名EnumBoolean',
  `IS_ACCOUNT` int(3) DEFAULT NULL COMMENT '是否开户EnumBoolean',
  `IS_FIRSTBUY` int(3) DEFAULT NULL COMMENT '是否首次购买EnumBoolean',
  `IS_PAYPWD` int(3) DEFAULT NULL COMMENT '是否设置交易密码EnumBoolean',
  `SEC_LEVEL` int(3) DEFAULT NULL COMMENT '安全等级EnumSecurityLevel',
  `USER_LEVEL` int(3) DEFAULT NULL COMMENT '会员级别EnumUserLevel',
  `USER_STATUS` int(3) DEFAULT NULL COMMENT '用户状态EnumUserStatus',
  `REGISTER_TIME` datetime DEFAULT NULL COMMENT '创建时间',
  `REGISTER_REFEREE` varchar(64) DEFAULT NULL COMMENT '注册推荐人',
  `REGISTER_TERMINAL` varchar(20) DEFAULT NULL COMMENT '注册渠道',
  `INTEGRAL_LEVEL` varchar(20) DEFAULT NULL COMMENT '积分等级',
  `EXTF1` varchar(5) DEFAULT NULL COMMENT '备用字段1',
  `EXTF2` varchar(20) DEFAULT NULL COMMENT '备用字段2',
  `EXTF3` varchar(50) DEFAULT NULL COMMENT '备用字段3',
  `EXTF4` varchar(200) DEFAULT NULL COMMENT '备用字段4',
  `EXTF5` varchar(1000) DEFAULT NULL COMMENT '备用字段5',
  PRIMARY KEY (`EVENT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='注册事件表';

/*Data for the table `ODS_EVT_REGISTER` */

/*Table structure for table `ODS_EVT_SELL` */

DROP TABLE IF EXISTS `ODS_EVT_SELL`;

CREATE TABLE `ODS_EVT_SELL` (
  `EVENT_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT '卖出事件编号',
  `USER_ID` varchar(64) DEFAULT NULL COMMENT '用户编号',
  `GOODS_ID` varchar(64) DEFAULT NULL COMMENT '商品编号',
  `PURCHASE_VCHR_ID` varchar(64) DEFAULT NULL COMMENT '原申购单编号',
  `SELL_EVENT_TYPE` int(3) DEFAULT NULL COMMENT '卖出事件类型EnumSellVchrType',
  `PRODUCT_TYPE` int(3) DEFAULT NULL COMMENT '投资产品类型EnumInvestProductType',
  `USER_ROLE` int(3) DEFAULT NULL COMMENT '用户角色EnumRoleType',
  `SELL_SHARE` decimal(18,4) DEFAULT NULL COMMENT '卖出份额',
  `DONE_SHARE` decimal(18,4) DEFAULT NULL COMMENT '已卖出份额',
  `LEFT_SHARE` decimal(18,4) DEFAULT NULL COMMENT '可卖出份额',
  `FROZEN_SHARE` decimal(18,4) DEFAULT NULL COMMENT '冻结份额',
  `CANCEL_SHARE` decimal(18,4) DEFAULT NULL COMMENT '撤销份额',
  `SELL_STATUS` int(3) DEFAULT NULL COMMENT '卖出单状态EnumPurchaseVchrStatus',
  `APPLY_TIME` datetime DEFAULT NULL COMMENT '申购时间',
  `CREATE_DATE` datetime DEFAULT NULL COMMENT '创建时间',
  `UPDATE_DATE` datetime DEFAULT NULL COMMENT '修改时间',
  `CHANNEL` varchar(64) DEFAULT NULL COMMENT '渠道EnumChannel(无)',
  `IS_AUTO` int(3) DEFAULT NULL COMMENT '是否自动EnumBoolean',
  `INTEREST` decimal(18,4) DEFAULT NULL COMMENT '利息',
  `EXTF1` varchar(5) DEFAULT NULL COMMENT '备用字段1',
  `EXTF2` varchar(20) DEFAULT NULL COMMENT '备用字段2',
  `EXTF3` varchar(50) DEFAULT NULL COMMENT '备用字段3',
  `EXTF4` varchar(200) DEFAULT NULL COMMENT '备用字段4',
  `EXTF5` varchar(1000) DEFAULT NULL COMMENT '备用字段5',
  PRIMARY KEY (`EVENT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='卖出事件';

/*Data for the table `ODS_EVT_SELL` */

/*Table structure for table `ODS_EVT_SIGNRECORD` */

DROP TABLE IF EXISTS `ODS_EVT_SIGNRECORD`;

CREATE TABLE `ODS_EVT_SIGNRECORD` (
  `SIGN_ID` varchar(64) DEFAULT NULL COMMENT '注册序号',
  `CLIENT_ID` varchar(64) DEFAULT NULL COMMENT '客户id',
  `MANAGER_ID` varchar(64) DEFAULT NULL COMMENT '领单客户经理ID',
  `DATETIME` datetime DEFAULT NULL COMMENT '预约面签时间',
  `PROVINCE` varchar(50) DEFAULT NULL COMMENT '预约面签省',
  `CITY` varchar(20) DEFAULT NULL COMMENT '预约面签市',
  `COUNTY` varchar(20) DEFAULT NULL COMMENT '预约面签县',
  `ADDRESS` varchar(200) DEFAULT NULL COMMENT '预约面签地址',
  `EXPLAINS` varchar(250) DEFAULT NULL COMMENT '面签说明',
  `SIGN_LAT` decimal(11,8) DEFAULT NULL COMMENT '面签地点纬度',
  `SIGN_LON` decimal(11,8) DEFAULT NULL COMMENT '面签地点经度',
  `ACTIVATE_LAT` decimal(11,8) DEFAULT NULL COMMENT '激活地点纬度',
  `ACTIVATE_LON` decimal(11,8) DEFAULT NULL COMMENT '激活地点经度',
  `SIGN_STATUS` int(3) DEFAULT NULL COMMENT '流水状态EnumSerialStatus',
  `REQUEST_DATE` varchar(20) DEFAULT NULL COMMENT '申请时间',
  `SIGNRE_DATE` varchar(20) DEFAULT NULL COMMENT '签约时间',
  `UPDATE_DATE` datetime DEFAULT NULL COMMENT '最后修改时间',
  `CONTRACT_ID` varchar(64) DEFAULT NULL COMMENT '合同编号',
  `ORDER_ID` varchar(40) DEFAULT NULL COMMENT '商家支付订单请求流水',
  `ORDER_DATE` varchar(40) DEFAULT NULL COMMENT '商家支付订单请求时间',
  `MPORDER_ID` varchar(40) DEFAULT NULL COMMENT '企业平台订单号',
  `APPLY_ID` varchar(40) DEFAULT NULL COMMENT '进件编号',
  `PURPOSE` varchar(20) DEFAULT NULL COMMENT '资金用途',
  `MSSIND` int(3) DEFAULT NULL COMMENT '是否接收短信',
  `ACTIVE_SERIAL_ID` varchar(50) DEFAULT NULL COMMENT '激活申请成功的流水号',
  `HA_MANAGER_ID` varchar(50) DEFAULT NULL,
  `HA_MANAGER_NAME` varchar(50) DEFAULT NULL,
  `APPLICATION_NUMBER` varchar(40) DEFAULT NULL COMMENT '哈行申请流水号',
  `OCR_LEGALITY` varchar(20) DEFAULT NULL COMMENT 'OCR识别匹配度',
  `ACTIVE_DATE` varchar(20) DEFAULT NULL COMMENT '激活时间',
  `EXTF1` varchar(5) DEFAULT NULL COMMENT '备用字段1',
  `EXTF2` varchar(20) DEFAULT NULL COMMENT '备用字段2',
  `EXTF3` varchar(50) DEFAULT NULL COMMENT '备用字段3',
  `EXTF4` varchar(200) DEFAULT NULL COMMENT '备用字段4',
  `EXTF5` varchar(1000) DEFAULT NULL COMMENT '备用字段5'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='面签记录表';

/*Data for the table `ODS_EVT_SIGNRECORD` */

/*Table structure for table `ODS_EVT_TRANSFER` */

DROP TABLE IF EXISTS `ODS_EVT_TRANSFER`;

CREATE TABLE `ODS_EVT_TRANSFER` (
  `EVENT_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT '转让编号',
  `USER_ID` varchar(64) DEFAULT NULL COMMENT '转让人编号',
  `GOODS_ID` varchar(64) DEFAULT NULL COMMENT '商品编号',
  `TRANSFER_NUM` decimal(18,4) DEFAULT NULL COMMENT '转让份额',
  `RESIDUE_NUM` decimal(18,4) DEFAULT NULL COMMENT '剩余份额',
  `TRANSFER_AMOUNT` decimal(18,4) DEFAULT NULL COMMENT '转让金额',
  `TRANSFER_PRICE` decimal(18,4) DEFAULT NULL COMMENT '转让单价',
  `TRANSFER_DATE` datetime DEFAULT NULL COMMENT '转让日期',
  `TRANSFER_STATE` int(3) DEFAULT NULL COMMENT '转让状态EnumTransferVchrStatus',
  `TRANSFER_DEPOSIT_RATE` decimal(18,4) DEFAULT NULL COMMENT '转让折扣率',
  `EXTF1` varchar(5) DEFAULT NULL COMMENT '备用字段1',
  `EXTF2` varchar(20) DEFAULT NULL COMMENT '备用字段2',
  `EXTF3` varchar(50) DEFAULT NULL COMMENT '备用字段3',
  `EXTF4` varchar(200) DEFAULT NULL COMMENT '备用字段4',
  `EXTF5` varchar(1000) DEFAULT NULL COMMENT '备用字段5',
  PRIMARY KEY (`EVENT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='转让事件';

/*Data for the table `ODS_EVT_TRANSFER` */

/*Table structure for table `ODS_EVT_WITHDRAW` */

DROP TABLE IF EXISTS `ODS_EVT_WITHDRAW`;

CREATE TABLE `ODS_EVT_WITHDRAW` (
  `EVENT_ID` varchar(64) NOT NULL COMMENT '提现事件编号',
  `USER_ID` varchar(64) DEFAULT NULL COMMENT '提现人编号',
  `WITHDRAW_AMT` decimal(18,4) DEFAULT NULL COMMENT '提现金额',
  `FEE_AMT` decimal(18,4) DEFAULT NULL COMMENT '收费金额',
  `FEE_MODE` int(3) DEFAULT NULL COMMENT '收费方式EnumFeeMode',
  `NET_TYPE` int(3) DEFAULT NULL COMMENT '网络类型EnumNetType',
  `WITHDRAW_TYPE` int(3) DEFAULT NULL COMMENT '提现类型EnumWithdrawType',
  `STATUS` int(3) DEFAULT NULL COMMENT '处理状态EnumProcessingStatus',
  `EXTF1` varchar(5) DEFAULT NULL COMMENT '备用字段1',
  `EXTF2` varchar(20) DEFAULT NULL COMMENT '备用字段2',
  `EXTF3` varchar(50) DEFAULT NULL COMMENT '备用字段3',
  `EXTF4` varchar(200) DEFAULT NULL COMMENT '备用字段4',
  `EXTF5` varchar(1000) DEFAULT NULL COMMENT '备用字段5',
  PRIMARY KEY (`EVENT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='提现事件表';

/*Data for the table `ODS_EVT_WITHDRAW` */

/*Table structure for table `ODS_FIN_P2P_ASSET_INFO` */

DROP TABLE IF EXISTS `ODS_FIN_P2P_ASSET_INFO`;

CREATE TABLE `ODS_FIN_P2P_ASSET_INFO` (
  `GOODS_ID` varchar(64) NOT NULL COMMENT '商品编号',
  `MANAGER_AMT` decimal(18,4) DEFAULT NULL COMMENT '收取管理费总额',
  `FEE_AMT` decimal(18,4) DEFAULT NULL COMMENT '收取手续费总额',
  `SAIL_AMT` decimal(18,4) DEFAULT NULL COMMENT '收取发行费总额',
  `DISTRIBUTED_REBATE` decimal(18,4) DEFAULT NULL COMMENT '已派发红包总额',
  `SETTLED_REBATE` decimal(18,4) DEFAULT NULL COMMENT '已兑换红包总额',
  `USED_REBATE` decimal(18,4) DEFAULT NULL COMMENT '已消费红包总额',
  `INVALID_REBATE` decimal(18,4) DEFAULT NULL COMMENT '已失效红包总额',
  `DISTRIBUTED_INTEGRAL` decimal(18,4) DEFAULT NULL COMMENT '已派发积分总额',
  `SETTLED_INTEGRAL` decimal(18,4) DEFAULT NULL COMMENT '已消费积分总额',
  `INVALID_INTEGRAL` decimal(18,4) DEFAULT NULL COMMENT '已失效积分总额',
  `OFF_AMT` decimal(18,4) DEFAULT NULL COMMENT '已兑付优惠总额',
  `COMMISSION_SUM` decimal(18,4) DEFAULT NULL COMMENT '已发放佣金总额',
  `COMMISSION_WITHDRAW` decimal(18,4) DEFAULT NULL COMMENT '已提现佣金总额',
  `PREMIUM_SUM` decimal(18,4) DEFAULT NULL COMMENT '应付贴息总额',
  `PREMIUM_PAYED` decimal(18,4) DEFAULT NULL COMMENT '已付贴息总额',
  `STAT_DATE` datetime DEFAULT NULL COMMENT '统计日期',
  PRIMARY KEY (`GOODS_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='P2P资产信息表';

/*Data for the table `ODS_FIN_P2P_ASSET_INFO` */

/*Table structure for table `ODS_FIN_P2P_FINANCE_INFO` */

DROP TABLE IF EXISTS `ODS_FIN_P2P_FINANCE_INFO`;

CREATE TABLE `ODS_FIN_P2P_FINANCE_INFO` (
  `FIN_INFO_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT '财务信息编号',
  `ACTUAL_LOAN_AMOUNT` decimal(18,4) DEFAULT '0.0000' COMMENT '实际放款金额',
  `PRE_REPAY_AMT` decimal(18,4) DEFAULT '0.0000' COMMENT '预期还款金额',
  `ACTUAL_REFUND_AMOUNT` decimal(18,4) DEFAULT '0.0000' COMMENT '实际还款金额',
  `PRE_AMOUNT` decimal(18,4) DEFAULT '0.0000' COMMENT '待还金额',
  `ACTUAL_COMPENSATED_AMT` decimal(18,4) DEFAULT '0.0000' COMMENT '实际代偿金额',
  `CLEAR_AMT` decimal(18,4) DEFAULT '0.0000' COMMENT '核销金额',
  `STAT_DATE` date DEFAULT NULL COMMENT '统计日期',
  PRIMARY KEY (`FIN_INFO_ID`),
  UNIQUE KEY `STAT_DATE` (`STAT_DATE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='P2P财务信息表';

/*Data for the table `ODS_FIN_P2P_FINANCE_INFO` */

/*Table structure for table `ODS_PRD_P2P_LOAN_PRODUCT_INFO` */

DROP TABLE IF EXISTS `ODS_PRD_P2P_LOAN_PRODUCT_INFO`;

CREATE TABLE `ODS_PRD_P2P_LOAN_PRODUCT_INFO` (
  `PRODUCT_ID` varchar(64) NOT NULL COMMENT '产品编号',
  `REFUND_WAY` int(3) DEFAULT NULL COMMENT '还款方式EnumRefundWay',
  `ACCOUNT_MANAGE_TYPE` varchar(20) DEFAULT NULL COMMENT '账户管理费收费方式',
  `MIN_BRW_PERIOD` varchar(20) DEFAULT NULL COMMENT '最小借款期限',
  `MAX_BRW_PERIOD` varchar(20) DEFAULT NULL COMMENT '最大借款期限',
  `MIN_RAISE_PERIOD` varchar(20) DEFAULT NULL COMMENT '最小募集期限',
  `MAX_RAISE_PERIOD` varchar(20) DEFAULT NULL COMMENT '最大募集期限',
  `MIN_BRW_AMOUNT` decimal(18,4) DEFAULT NULL COMMENT '最小借款金额',
  `MAX_BRW_AMOUNT` decimal(18,4) DEFAULT NULL COMMENT '最大借款金额',
  `INCREMENT_AMOUNT` decimal(18,4) DEFAULT NULL COMMENT '递增金额',
  `MIN_BORROW_RATE` decimal(18,4) DEFAULT NULL COMMENT '最小借款利率',
  `MAX_BORROW_RATE` decimal(18,4) DEFAULT NULL COMMENT '最大借款利率',
  `BORROW_RATE` decimal(18,4) DEFAULT NULL COMMENT '借款利率',
  `SERVICE_RATE` decimal(18,4) DEFAULT NULL COMMENT '服务费率',
  `HAS_PLEDGE` int(3) DEFAULT NULL COMMENT '是否需要抵押EnumBoolean',
  `HAS_ASSURE` int(3) DEFAULT NULL COMMENT '是否需要保证金EnumBoolean',
  `IS_BEYOND` int(3) DEFAULT NULL COMMENT '是否允许超出授信截止日EnumBoolean',
  `IS_ALLOW_ADVANCE` int(3) DEFAULT NULL COMMENT '是否允许提前还款EnumBoolean',
  `EXTF1` varchar(5) DEFAULT NULL COMMENT '备用字段1',
  `EXTF2` varchar(20) DEFAULT NULL COMMENT '备用字段2',
  `EXTF3` varchar(50) DEFAULT NULL COMMENT '备用字段3',
  `EXTF4` varchar(200) DEFAULT NULL COMMENT '备用字段4',
  `EXTF5` varchar(1000) DEFAULT NULL COMMENT '备用字段5',
  PRIMARY KEY (`PRODUCT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='P2P借款产品信息表';

/*Data for the table `ODS_PRD_P2P_LOAN_PRODUCT_INFO` */

/*Table structure for table `ODS_PRD_P2P_PRODUCT_INFO` */

DROP TABLE IF EXISTS `ODS_PRD_P2P_PRODUCT_INFO`;

CREATE TABLE `ODS_PRD_P2P_PRODUCT_INFO` (
  `PRODUCT_ID` varchar(64) NOT NULL COMMENT '产品编号',
  `P2P_PRODUCT_TYPE` int(3) DEFAULT NULL COMMENT 'P2P产品类型EnumP2PProductCategory',
  `CREATE_TIME` datetime DEFAULT NULL COMMENT 'P2P产品创建时间',
  `UPDATE_TIME` datetime DEFAULT NULL COMMENT 'P2P产品修改时间',
  `PRODUCT_CHANNEL` varchar(64) DEFAULT NULL COMMENT '产品渠道',
  `CHECK_PERIOD` varchar(20) DEFAULT NULL COMMENT '审核周期',
  `STATUS` int(3) DEFAULT NULL COMMENT '产品状态EnumProductStatus',
  `EXTF1` varchar(5) DEFAULT NULL COMMENT '备用字段1',
  `EXTF2` varchar(20) DEFAULT NULL COMMENT '备用字段2',
  `EXTF3` varchar(50) DEFAULT NULL COMMENT '备用字段3',
  `EXTF4` varchar(200) DEFAULT NULL COMMENT '备用字段4',
  `EXTF5` varchar(1000) DEFAULT NULL COMMENT '备用字段5',
  PRIMARY KEY (`PRODUCT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='P2P类产品信息表';

/*Data for the table `ODS_PRD_P2P_PRODUCT_INFO` */

/*Table structure for table `ODS_PRD_PRODUCT_INFO` */

DROP TABLE IF EXISTS `ODS_PRD_PRODUCT_INFO`;

CREATE TABLE `ODS_PRD_PRODUCT_INFO` (
  `PRODUCT_ID` varchar(64) NOT NULL COMMENT '产品编号',
  `PRODUCT_CATEGORY` int(3) DEFAULT '0' COMMENT '产品类别EnumProductCategory',
  `PROTOCOL_ID` varchar(64) DEFAULT NULL COMMENT '协议编号',
  `PRODUCT_NAME` varchar(255) DEFAULT NULL COMMENT '产品名称',
  `PRODUCT_DESC` varchar(250) DEFAULT NULL COMMENT '产品描述',
  `EXTF1` varchar(5) DEFAULT NULL COMMENT '备用字段1',
  `EXTF2` varchar(20) DEFAULT NULL COMMENT '备用字段2',
  `EXTF3` varchar(50) DEFAULT NULL COMMENT '备用字段3',
  `EXTF4` varchar(200) DEFAULT NULL COMMENT '备用字段4',
  `EXTF5` varchar(1000) DEFAULT NULL COMMENT '备用字段5',
  PRIMARY KEY (`PRODUCT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='产品信息表';

/*Data for the table `ODS_PRD_PRODUCT_INFO` */

/*Table structure for table `ODS_PTY_ACCOUNT_MANAGER` */

DROP TABLE IF EXISTS `ODS_PTY_ACCOUNT_MANAGER`;

CREATE TABLE `ODS_PTY_ACCOUNT_MANAGER` (
  `MANAGER_ID` varchar(64) NOT NULL COMMENT '客户经理编号',
  `MANAGER_NAME` varchar(50) DEFAULT NULL COMMENT '客户经理姓名',
  `PASSWORD` varchar(64) DEFAULT NULL COMMENT '客户经理密码',
  `MOBILE` varchar(20) DEFAULT NULL COMMENT '手机号码',
  `CHARGE_PROVINCE` varchar(50) DEFAULT NULL COMMENT '负责区域：省',
  `CHARGE_CITY` varchar(50) DEFAULT NULL COMMENT '负责区域：市',
  `CHARGE_COUNTY` varchar(50) DEFAULT NULL COMMENT '负责区域：区',
  `ROLE_NAME` varchar(50) DEFAULT NULL COMMENT '角色名称',
  `ROLE_DESC` varchar(200) DEFAULT NULL COMMENT '角色描述',
  `EXTF1` varchar(5) DEFAULT NULL COMMENT '备用字段1',
  `EXTF2` varchar(20) DEFAULT NULL COMMENT '备用字段2',
  `EXTF3` varchar(50) DEFAULT NULL COMMENT '备用字段3',
  `EXTF4` varchar(200) DEFAULT NULL COMMENT '备用字段4',
  `EXTF5` varchar(1000) DEFAULT NULL COMMENT '备用字段5',
  PRIMARY KEY (`MANAGER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='客户经理表';

/*Data for the table `ODS_PTY_ACCOUNT_MANAGER` */

/*Table structure for table `ODS_PTY_AGENT_ACCOUNT` */

DROP TABLE IF EXISTS `ODS_PTY_AGENT_ACCOUNT`;

CREATE TABLE `ODS_PTY_AGENT_ACCOUNT` (
  `USER_ID` varchar(64) NOT NULL COMMENT '用户编号',
  `BANK_ID` varchar(64) DEFAULT NULL COMMENT '开户行编号',
  `SUBBANK_ID` varchar(64) DEFAULT NULL COMMENT '联行编号',
  `BANK_ACCOUNT_NO` varchar(64) DEFAULT NULL COMMENT '银行账号',
  `ACCESSORY_URL` varchar(250) DEFAULT NULL COMMENT '开户附件',
  `CREATE_TIME` datetime DEFAULT NULL COMMENT '机构用户开户信息创建时间',
  `UPDATE_TIME` datetime DEFAULT NULL COMMENT '机构用户开户信息修改时间',
  `EXTF1` varchar(5) DEFAULT NULL COMMENT '备用字段1',
  `EXTF2` varchar(20) DEFAULT NULL COMMENT '备用字段2',
  `EXTF3` varchar(50) DEFAULT NULL COMMENT '备用字段3',
  `EXTF4` varchar(200) DEFAULT NULL COMMENT '备用字段4',
  `EXTF5` varchar(1000) DEFAULT NULL COMMENT '备用字段5',
  PRIMARY KEY (`USER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='机构参与者开户信息';

/*Data for the table `ODS_PTY_AGENT_ACCOUNT` */

/*Table structure for table `ODS_PTY_AGENT_INFO` */

DROP TABLE IF EXISTS `ODS_PTY_AGENT_INFO`;

CREATE TABLE `ODS_PTY_AGENT_INFO` (
  `USER_ID` varchar(64) NOT NULL COMMENT '用户编号',
  `ORG_NAME` varchar(64) DEFAULT NULL COMMENT '机构名称',
  `ORG_ADDRESS` varchar(250) DEFAULT NULL COMMENT '机构地址',
  `REGISTER_DATE` varchar(20) DEFAULT NULL COMMENT '注册时间',
  `REGISTER_MONEY` decimal(18,4) DEFAULT NULL COMMENT '注册资本',
  `LEGAL_NAME` varchar(50) DEFAULT NULL COMMENT '法人姓名',
  `CERT_TYPE` int(3) DEFAULT NULL COMMENT '法人证件类型EnumCertType',
  `CERT_NO` varchar(64) DEFAULT NULL COMMENT '证件号码',
  `ORG_URL` varchar(250) DEFAULT NULL COMMENT '机构网址',
  `FAX` varchar(50) DEFAULT NULL COMMENT '传真',
  `EMAIL` varchar(100) DEFAULT NULL COMMENT '邮箱',
  `CREATE_TIME` datetime DEFAULT NULL COMMENT '机构用户基本信息创建时间',
  `UPDATE_TIME` datetime DEFAULT NULL COMMENT '机构用户基本信息修改时间',
  `EXTF1` varchar(5) DEFAULT NULL COMMENT '备用字段1',
  `EXTF2` varchar(20) DEFAULT NULL COMMENT '备用字段2',
  `EXTF3` varchar(50) DEFAULT NULL COMMENT '备用字段3',
  `EXTF4` varchar(200) DEFAULT NULL COMMENT '备用字段4',
  `EXTF5` varchar(1000) DEFAULT NULL COMMENT '备用字段5',
  PRIMARY KEY (`USER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='机构参与者基本信息';

/*Data for the table `ODS_PTY_AGENT_INFO` */

/*Table structure for table `ODS_PTY_AGENT_OPERATE` */

DROP TABLE IF EXISTS `ODS_PTY_AGENT_OPERATE`;

CREATE TABLE `ODS_PTY_AGENT_OPERATE` (
  `USER_ID` varchar(64) NOT NULL COMMENT '用户编号',
  `INDUSTRY_TYPE` int(3) DEFAULT NULL COMMENT '行业类型EnumIndustryType',
  `INDUSTRY_LABELS` varchar(50) DEFAULT NULL COMMENT '行业标签',
  `CREATE_TIME` datetime DEFAULT NULL COMMENT '机构用户经营信息创建时间',
  `UPDATE_TIME` datetime DEFAULT NULL COMMENT '机构用户经营信息修改时间',
  `EXTF1` varchar(5) DEFAULT NULL COMMENT '备用字段1',
  `EXTF2` varchar(20) DEFAULT NULL COMMENT '备用字段2',
  `EXTF3` varchar(50) DEFAULT NULL COMMENT '备用字段3',
  `EXTF4` varchar(200) DEFAULT NULL COMMENT '备用字段4',
  `EXTF5` varchar(1000) DEFAULT NULL COMMENT '备用字段5',
  PRIMARY KEY (`USER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='机构参与者经营信息';

/*Data for the table `ODS_PTY_AGENT_OPERATE` */

/*Table structure for table `ODS_PTY_ROLE` */

DROP TABLE IF EXISTS `ODS_PTY_ROLE`;

CREATE TABLE `ODS_PTY_ROLE` (
  `ROLE_ID` varchar(64) NOT NULL COMMENT '角色编号',
  `ROLE_NAME` varchar(50) DEFAULT NULL COMMENT '角色名称',
  `ROLE_TYPE` int(3) DEFAULT NULL COMMENT '角色类型EnumRoleType',
  `ROLE_DESC` varchar(250) DEFAULT NULL COMMENT '角色描述',
  `STATUS` int(3) DEFAULT NULL COMMENT '是否停用EnumBoolean',
  `DEF` int(3) DEFAULT NULL COMMENT '是否默认EnumBoolean',
  `CREATE_TIME` datetime DEFAULT NULL COMMENT '角色信息创建时间',
  `UPDATE_TIME` datetime DEFAULT NULL COMMENT '角色信息修改时间',
  `EXTF1` varchar(5) DEFAULT NULL COMMENT '备用字段1',
  `EXTF2` varchar(20) DEFAULT NULL COMMENT '备用字段2',
  `EXTF3` varchar(50) DEFAULT NULL COMMENT '备用字段3',
  `EXTF4` varchar(200) DEFAULT NULL COMMENT '备用字段4',
  `EXTF5` varchar(1000) DEFAULT NULL COMMENT '备用字段5',
  PRIMARY KEY (`ROLE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='角色';

/*Data for the table `ODS_PTY_ROLE` */

/*Table structure for table `ODS_PTY_USER_ACCESSORY` */

DROP TABLE IF EXISTS `ODS_PTY_USER_ACCESSORY`;

CREATE TABLE `ODS_PTY_USER_ACCESSORY` (
  `USER_ACCESSORY_ID` varchar(64) NOT NULL COMMENT '用户附件编号',
  `USER_ID` varchar(64) DEFAULT NULL COMMENT '用户编号',
  `CERT_NAME` varchar(100) DEFAULT NULL COMMENT '证件名称',
  `CERT_TYPE` int(3) DEFAULT NULL COMMENT '附加证件类型EnumAccessoryType',
  `CERT_NO` varchar(64) DEFAULT NULL COMMENT '证件号码',
  `CERT_PHOTO` varchar(250) DEFAULT NULL COMMENT '证件照',
  `LICENCE_ISSUE` varchar(250) DEFAULT NULL COMMENT '发证机构',
  `LICENCE_ADDRESS` varchar(250) DEFAULT NULL COMMENT '证件地址',
  `EFFECTIVE_TIME` datetime DEFAULT NULL COMMENT '生效时间',
  `UNEFFECTIVE_TIME` datetime DEFAULT NULL COMMENT '失效时间',
  `CREATE_TIME` datetime DEFAULT NULL COMMENT '附件信息创建时间',
  `UPDATE_TIME` datetime DEFAULT NULL COMMENT '附件信息修改时间',
  `EXTF1` varchar(5) DEFAULT NULL COMMENT '备用字段1',
  `EXTF2` varchar(20) DEFAULT NULL COMMENT '备用字段2',
  `EXTF3` varchar(50) DEFAULT NULL COMMENT '备用字段3',
  `EXTF4` varchar(200) DEFAULT NULL COMMENT '备用字段4',
  `EXTF5` varchar(1000) DEFAULT NULL COMMENT '备用字段5',
  PRIMARY KEY (`USER_ACCESSORY_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='个人参与者附件资料';

/*Data for the table `ODS_PTY_USER_ACCESSORY` */

/*Table structure for table `ODS_PTY_USER_ASSET` */

DROP TABLE IF EXISTS `ODS_PTY_USER_ASSET`;

CREATE TABLE `ODS_PTY_USER_ASSET` (
  `USER_CAP_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT '用户资产编号',
  `USER_ID` varchar(64) DEFAULT NULL COMMENT '用户编号',
  `HAS_HOUSE` int(3) DEFAULT NULL COMMENT '是否有房EnumBoolean',
  `HAS_CAR` int(3) DEFAULT NULL COMMENT '是否有车EnumBoolean',
  `OWNER_SHIP` int(3) DEFAULT NULL COMMENT '所有权EnumHouseOwnership',
  `HOUSE_PROPERTY` int(3) DEFAULT NULL COMMENT '房屋性质EnumHouseProperty',
  `PROVINCE` varchar(64) DEFAULT NULL COMMENT '省',
  `CITY` varchar(64) DEFAULT NULL COMMENT '市',
  `AREA` varchar(64) DEFAULT NULL COMMENT '区',
  `ROAD` varchar(64) DEFAULT NULL COMMENT '街道',
  `PREMISES` varchar(64) DEFAULT NULL COMMENT '小区/楼盘',
  `BUILD_NO` varchar(50) DEFAULT NULL COMMENT '楼号',
  `UNIT` varchar(20) DEFAULT NULL COMMENT '单元',
  `ROOM_NO` varchar(20) DEFAULT NULL COMMENT '房间号',
  `EXTF1` varchar(5) DEFAULT NULL COMMENT '备用字段1',
  `EXTF2` varchar(20) DEFAULT NULL COMMENT '备用字段2',
  `EXTF3` varchar(50) DEFAULT NULL COMMENT '备用字段3',
  `EXTF4` varchar(200) DEFAULT NULL COMMENT '备用字段4',
  `EXTF5` varchar(1000) DEFAULT NULL COMMENT '备用字段5',
  PRIMARY KEY (`USER_CAP_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='个人参与者资产信息';

/*Data for the table `ODS_PTY_USER_ASSET` */

/*Table structure for table `ODS_PTY_USER_BINDCARD` */

DROP TABLE IF EXISTS `ODS_PTY_USER_BINDCARD`;

CREATE TABLE `ODS_PTY_USER_BINDCARD` (
  `BIND_CARD_ID` varchar(64) NOT NULL COMMENT '用户绑卡编号',
  `USER_ID` varchar(64) DEFAULT NULL COMMENT '用户编号',
  `CARD_NO` varchar(64) DEFAULT NULL COMMENT '卡号',
  `BRANCH_NAME` varchar(250) DEFAULT NULL COMMENT '支行名称',
  `PRE_MOBILE` varchar(20) DEFAULT NULL COMMENT '预留手机号',
  `IS_FAST_PAY` int(3) DEFAULT NULL COMMENT '是否开通快捷支付EnumBoolean',
  `BANK_ID` varchar(64) DEFAULT NULL COMMENT '银行编号',
  `SUBBANK_ID` varchar(64) DEFAULT NULL COMMENT '联行编号',
  `CURRENCY` char(3) DEFAULT NULL COMMENT '币种EnumCurrencyType',
  `CARD_TYPE` varchar(20) DEFAULT NULL COMMENT '银行卡类型',
  `IS_DEFAULT` int(3) DEFAULT NULL COMMENT '是否默认EnumBoolean',
  `BIND_STATUS` int(3) DEFAULT NULL COMMENT '绑卡状态EnumBindStatus',
  `BCHCDE` varchar(20) DEFAULT NULL COMMENT 'BCHCDE',
  `CREATE_TIME` datetime DEFAULT NULL COMMENT '绑卡信息创建时间',
  `UPDATE_TIME` datetime DEFAULT NULL COMMENT '绑卡信息修改时间',
  `EXTF1` varchar(5) DEFAULT NULL COMMENT '备用字段1',
  `EXTF2` varchar(20) DEFAULT NULL COMMENT '备用字段2',
  `EXTF3` varchar(50) DEFAULT NULL COMMENT '备用字段3',
  `EXTF4` varchar(200) DEFAULT NULL COMMENT '备用字段4',
  `EXTF5` varchar(1000) DEFAULT NULL COMMENT '备用字段5',
  PRIMARY KEY (`BIND_CARD_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='个人参与者绑卡信息';

/*Data for the table `ODS_PTY_USER_BINDCARD` */

/*Table structure for table `ODS_PTY_USER_BIZ_RELATION` */

DROP TABLE IF EXISTS `ODS_PTY_USER_BIZ_RELATION`;

CREATE TABLE `ODS_PTY_USER_BIZ_RELATION` (
  `BIZ_USER_RLT_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT '关联编号',
  `USER_ID` varchar(64) DEFAULT NULL COMMENT '用户编号',
  `BIZ_TYPE` char(3) DEFAULT '0' COMMENT '参与业务类型EnumBizType',
  `EXTF1` varchar(5) DEFAULT NULL COMMENT '备用字段1',
  `EXTF2` varchar(20) DEFAULT NULL COMMENT '备用字段2',
  `EXTF3` varchar(50) DEFAULT NULL COMMENT '备用字段3',
  `EXTF4` varchar(200) DEFAULT NULL COMMENT '备用字段4',
  `EXTF5` varchar(1000) DEFAULT NULL COMMENT '备用字段5',
  PRIMARY KEY (`BIZ_USER_RLT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='参与者业务关联表';

/*Data for the table `ODS_PTY_USER_BIZ_RELATION` */

/*Table structure for table `ODS_PTY_USER_CONTACT` */

DROP TABLE IF EXISTS `ODS_PTY_USER_CONTACT`;

CREATE TABLE `ODS_PTY_USER_CONTACT` (
  `USER_CONTACT_ID` varchar(64) NOT NULL COMMENT '用户联系人编号',
  `USER_ID` varchar(64) DEFAULT NULL COMMENT '用户编号',
  `CONTACT_NAME` varchar(250) DEFAULT NULL COMMENT '联系人姓名',
  `CONTACT_SEX` int(3) DEFAULT NULL COMMENT '联系人性别EnumSex',
  `CONTACT_ADDRESS` varchar(250) DEFAULT NULL COMMENT '联系人地址',
  `CONTACT_COMPANY` varchar(250) DEFAULT NULL COMMENT '联系人单位',
  `CONTACT_HOME_PHONE_NO` varchar(20) DEFAULT NULL COMMENT '家庭电话',
  `CONTACT_OFFICE_PHONE_NO` varchar(20) DEFAULT NULL COMMENT '办公电话',
  `CONTACT_MOBILE_NO` varchar(20) DEFAULT NULL COMMENT '移动电话',
  `CONTACT_EMAIL` varchar(64) DEFAULT NULL COMMENT '邮箱',
  `CONTACT_POSTALCODE` varchar(20) DEFAULT NULL COMMENT '邮政编码',
  `CONTACT_POSTADDRESS` varchar(250) DEFAULT NULL COMMENT '邮件地址',
  `CONTACT_FAX` varchar(20) DEFAULT NULL COMMENT '传真',
  `CONTACT_STATUS` int(3) DEFAULT NULL COMMENT '状态EnumBoolean',
  `CONTACT_RELATION` int(3) DEFAULT NULL COMMENT '关系EnumContactRelation',
  `DATA_FROM` int(3) DEFAULT NULL COMMENT '数据来源EnumDataFrom',
  `CREATE_TIME` datetime DEFAULT NULL COMMENT '联系人信息创建时间',
  `UPDATE_TIME` datetime DEFAULT NULL COMMENT '联系人信息修改时间',
  `EXTF1` varchar(5) DEFAULT NULL COMMENT '备用字段1',
  `EXTF2` varchar(20) DEFAULT NULL COMMENT '备用字段2',
  `EXTF3` varchar(50) DEFAULT NULL COMMENT '备用字段3',
  `EXTF4` varchar(200) DEFAULT NULL COMMENT '备用字段4',
  `EXTF5` varchar(1000) DEFAULT NULL COMMENT '备用字段5',
  PRIMARY KEY (`USER_CONTACT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='个人参与者联系人信息';

/*Data for the table `ODS_PTY_USER_CONTACT` */

/*Table structure for table `ODS_PTY_USER_EDU` */

DROP TABLE IF EXISTS `ODS_PTY_USER_EDU`;

CREATE TABLE `ODS_PTY_USER_EDU` (
  `USER_EDU_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT '用户教育信息编号',
  `USER_ID` varchar(64) DEFAULT NULL COMMENT '用户编号',
  `EDUCATION` int(3) DEFAULT NULL COMMENT '学历EnumEducation',
  `SCHOOL` varchar(64) DEFAULT NULL COMMENT '学校',
  `MAJOR` varchar(50) DEFAULT NULL COMMENT '专业',
  `GRADUATION` varchar(20) DEFAULT NULL COMMENT '毕业年份',
  `CREATE_TIME` datetime DEFAULT NULL COMMENT '教育信息创建时间',
  `UPDATE_TIME` datetime DEFAULT NULL COMMENT '教育信息修改时间',
  `EXTF1` varchar(5) DEFAULT NULL COMMENT '备用字段1',
  `EXTF2` varchar(20) DEFAULT NULL COMMENT '备用字段2',
  `EXTF3` varchar(50) DEFAULT NULL COMMENT '备用字段3',
  `EXTF4` varchar(200) DEFAULT NULL COMMENT '备用字段4',
  `EXTF5` varchar(1000) DEFAULT NULL COMMENT '备用字段5',
  PRIMARY KEY (`USER_EDU_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='个人参与者教育信息';

/*Data for the table `ODS_PTY_USER_EDU` */

/*Table structure for table `ODS_PTY_USER_INFO` */

DROP TABLE IF EXISTS `ODS_PTY_USER_INFO`;

CREATE TABLE `ODS_PTY_USER_INFO` (
  `USER_ID` varchar(64) NOT NULL COMMENT '用户编号',
  `NAME` varchar(64) DEFAULT NULL COMMENT '姓名',
  `BIRTHDAY` varchar(64) DEFAULT NULL COMMENT '出生日期',
  `MARRY_STATUS` int(3) DEFAULT NULL COMMENT '婚姻状况EnumMarryStatus',
  `SEX` int(3) DEFAULT NULL COMMENT '性别EnumSex',
  `COUNTRY` varchar(64) DEFAULT NULL COMMENT '国籍',
  `NATION` varchar(64) DEFAULT NULL COMMENT '民族',
  `RELIGION` varchar(64) DEFAULT NULL COMMENT '宗教',
  `POLITICAL_STATUS` varchar(20) DEFAULT NULL COMMENT '政治面貌',
  `CERT_NO` varchar(20) DEFAULT NULL COMMENT '身份证号码',
  `MOBILE_NO` varchar(20) DEFAULT NULL COMMENT '手机号',
  `EMAIL` varchar(64) DEFAULT NULL COMMENT '邮箱',
  `ADDRESS` varchar(250) DEFAULT NULL COMMENT '住宅地址',
  `HOME_PHONE_NO` varchar(20) DEFAULT NULL COMMENT '住宅电话',
  `EMP_IDT` int(3) DEFAULT NULL COMMENT '员工标志EnumBoolean',
  `IS_DELETED` int(3) DEFAULT NULL COMMENT '是否删除EnumBoolean',
  `CREATE_TIME` datetime DEFAULT NULL COMMENT '个人信息创建时间',
  `UPDATE_TIME` datetime DEFAULT NULL COMMENT '个人信息修改时间',
  `EXTF1` varchar(5) DEFAULT NULL COMMENT '备用字段1',
  `EXTF2` varchar(20) DEFAULT NULL COMMENT '备用字段2',
  `EXTF3` varchar(50) DEFAULT NULL COMMENT '备用字段3',
  `EXTF4` varchar(200) DEFAULT NULL COMMENT '备用字段4',
  `EXTF5` varchar(1000) DEFAULT NULL COMMENT '备用字段5',
  PRIMARY KEY (`USER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='个人参与者基本信息';

/*Data for the table `ODS_PTY_USER_INFO` */

/*Table structure for table `ODS_PTY_USER_ROLE` */

DROP TABLE IF EXISTS `ODS_PTY_USER_ROLE`;

CREATE TABLE `ODS_PTY_USER_ROLE` (
  `USER_ROLE_ID` varchar(64) NOT NULL COMMENT '用户角色编号',
  `USER_ID` varchar(64) DEFAULT NULL COMMENT '用户编号',
  `ROLE_ID` varchar(64) DEFAULT NULL COMMENT '角色编号',
  `CREATE_TIME` datetime DEFAULT NULL COMMENT '用户角色关系创建时间',
  `UPDATE_TIME` datetime DEFAULT NULL COMMENT '用户角色关系修改时间',
  `EXTF1` varchar(5) DEFAULT NULL COMMENT '备用字段1',
  `EXTF2` varchar(20) DEFAULT NULL COMMENT '备用字段2',
  `EXTF3` varchar(50) DEFAULT NULL COMMENT '备用字段3',
  `EXTF4` varchar(200) DEFAULT NULL COMMENT '备用字段4',
  `EXTF5` varchar(1000) DEFAULT NULL COMMENT '备用字段5',
  PRIMARY KEY (`USER_ROLE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用户角色关系';

/*Data for the table `ODS_PTY_USER_ROLE` */

/*Table structure for table `ODS_PTY_USER_WORK` */

DROP TABLE IF EXISTS `ODS_PTY_USER_WORK`;

CREATE TABLE `ODS_PTY_USER_WORK` (
  `USER_WORK_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT '用户工作信息编号',
  `USER_ID` varchar(64) DEFAULT NULL COMMENT '用户编号',
  `WORK_STATUS` int(3) DEFAULT NULL COMMENT '就业状况EnumWorkStatus',
  `WORK_YEAR` int(3) DEFAULT NULL COMMENT '就业年限EnumWorkYear',
  `HAS_SOCIAL_SECURITY` int(3) DEFAULT NULL COMMENT '社保缴纳EnumBoolean',
  `HAS_ACCUMULATION_FUND` int(3) DEFAULT NULL COMMENT '公积金缴纳EnumBoolean',
  `COMPANY_NAME` varchar(200) DEFAULT NULL COMMENT '单位名称',
  `COMPANY_ADDRESS` varchar(250) DEFAULT NULL COMMENT '单位地址',
  `COMPANY_PHONE_NO` varchar(20) DEFAULT NULL COMMENT '单位电话',
  `COMPANY_TYPE` int(3) DEFAULT NULL COMMENT '单位性质EnumCompanyType',
  `POSITION` varchar(50) DEFAULT NULL COMMENT '职务职位',
  `ANNUAL_INCOME` decimal(18,2) DEFAULT NULL COMMENT '税后年收入',
  `PROVINCE` varchar(64) DEFAULT NULL COMMENT '省份',
  `CITY` varchar(64) DEFAULT NULL COMMENT '市区',
  `AREA` varchar(64) DEFAULT NULL COMMENT '地区',
  `CREATE_TIME` datetime DEFAULT NULL COMMENT '职业信息创建时间',
  `UPDATE_TIME` datetime DEFAULT NULL COMMENT '职业信息修改时间',
  `EXTF1` varchar(5) DEFAULT NULL COMMENT '备用字段1',
  `EXTF2` varchar(20) DEFAULT NULL COMMENT '备用字段2',
  `EXTF3` varchar(50) DEFAULT NULL COMMENT '备用字段3',
  `EXTF4` varchar(200) DEFAULT NULL COMMENT '备用字段4',
  `EXTF5` varchar(1000) DEFAULT NULL COMMENT '备用字段5',
  PRIMARY KEY (`USER_WORK_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='个人参与者职业信息';

/*Data for the table `ODS_PTY_USER_WORK` */

/*Table structure for table `ODS_RIC_CREDIT_AMOUNT` */

DROP TABLE IF EXISTS `ODS_RIC_CREDIT_AMOUNT`;

CREATE TABLE `ODS_RIC_CREDIT_AMOUNT` (
  `CREDIT_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT '授信编号',
  `USER_ID` varchar(64) DEFAULT NULL COMMENT '用户编号',
  `CERT_NO` varchar(18) DEFAULT NULL COMMENT '身份证号码',
  `CREDIT_AMOUNT` decimal(18,4) DEFAULT NULL COMMENT '授信额度',
  `CREDIT_DATE` datetime DEFAULT NULL COMMENT '授信日期',
  `EFFECTIVE_DATE` datetime DEFAULT NULL COMMENT '生效日期',
  `FAILURE_DATE` datetime DEFAULT NULL COMMENT '失效日期',
  `CREDIT_SCORE` varchar(10) DEFAULT NULL COMMENT '信用评分',
  `STATUS` int(3) DEFAULT NULL COMMENT '状态',
  `CREDIT_POLICY_VERSION1` varchar(200) DEFAULT NULL COMMENT '授信规则版本号1',
  `CREDIT_POLICY_VERSION2` varchar(200) DEFAULT NULL COMMENT '授信规则版本号2',
  `CREDIT_POLICY_VERSION3` varchar(64) DEFAULT NULL COMMENT '额度有效期规则版本号',
  `EXTF1` varchar(5) DEFAULT NULL COMMENT '备用字段1',
  `EXTF2` varchar(20) DEFAULT NULL COMMENT '备用字段2',
  `EXTF3` varchar(50) DEFAULT NULL COMMENT '备用字段3',
  `EXTF4` varchar(200) DEFAULT NULL COMMENT '备用字段4',
  `EXTF5` varchar(1000) DEFAULT NULL COMMENT '备用字段5',
  PRIMARY KEY (`CREDIT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='授信额度表';

/*Data for the table `ODS_RIC_CREDIT_AMOUNT` */

/*Table structure for table `ODS_RIC_CREDIT_ENHANCE` */

DROP TABLE IF EXISTS `ODS_RIC_CREDIT_ENHANCE`;

CREATE TABLE `ODS_RIC_CREDIT_ENHANCE` (
  `USER_ID` varchar(64) NOT NULL COMMENT '用户编号',
  `JD_ACCOUNT` varchar(64) DEFAULT NULL COMMENT '京东账号',
  `JD_PWD` varchar(64) DEFAULT NULL COMMENT '京东账号密码',
  `SECURITY_ACCOUNT` varchar(64) DEFAULT NULL COMMENT '社保账号',
  `SECURITY_PWD` varchar(64) DEFAULT NULL COMMENT '社保账号密码',
  `FUND_ACCOUNT` varchar(64) DEFAULT NULL COMMENT '公积金账号',
  `FUND_PWD` varchar(64) DEFAULT NULL COMMENT '公积金账号密码',
  `OPERATOR_STATUS` varchar(200) DEFAULT NULL COMMENT '运营商返回的状态id',
  `OPERATOR_USER_ID` varchar(200) DEFAULT NULL COMMENT '运营商返回的客户id',
  `OPERATOR_SERVICE_PWD` varchar(64) DEFAULT NULL COMMENT '运营商服务密码',
  `EXTF1` varchar(5) DEFAULT NULL COMMENT '备用字段1',
  `EXTF2` varchar(20) DEFAULT NULL COMMENT '备用字段2',
  `EXTF3` varchar(50) DEFAULT NULL COMMENT '备用字段3',
  `EXTF4` varchar(200) DEFAULT NULL COMMENT '备用字段4',
  `EXTF5` varchar(1000) DEFAULT NULL COMMENT '备用字段5',
  PRIMARY KEY (`USER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='客户增信信息表';

/*Data for the table `ODS_RIC_CREDIT_ENHANCE` */

/*Table structure for table `ODS_RIC_CREDIT_HISTORY` */

DROP TABLE IF EXISTS `ODS_RIC_CREDIT_HISTORY`;

CREATE TABLE `ODS_RIC_CREDIT_HISTORY` (
  `CREDIT_HISTORY_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT '授信历史编号',
  `USER_ID` varchar(64) DEFAULT NULL COMMENT '用户编号',
  `CERT_NO` varchar(18) DEFAULT NULL COMMENT '身份证号码',
  `ADJUST_DATE` datetime DEFAULT NULL COMMENT '调整日期',
  `EFFECTIVE_DATE` datetime DEFAULT NULL COMMENT '生效日期',
  `FAILURE_DATE` datetime DEFAULT NULL COMMENT '失效日期',
  `BEFORE_AMOUNT` decimal(18,4) DEFAULT NULL COMMENT '调整前额度',
  `AFTER_AMOUNT` decimal(18,4) DEFAULT NULL COMMENT '调整后额度',
  `ADJUST_AMOUNT` decimal(18,4) DEFAULT NULL COMMENT '本次调整额度',
  `ADJUST_FLAG` varchar(10) DEFAULT NULL COMMENT '本次调整符号',
  `ADJUST_REASON_CODE` varchar(64) DEFAULT NULL COMMENT '调整原因代码',
  `ADJUST_DESC` varchar(200) DEFAULT NULL COMMENT '调整原因描述',
  `CREDIT_POLICY_VERSION1` varchar(200) DEFAULT NULL COMMENT '授信规则版本号1',
  `CREDIT_POLICY_VERSION2` varchar(200) DEFAULT NULL COMMENT '授信规则版本号2',
  `CREDIT_POLICY_VERSION3` varchar(64) DEFAULT NULL COMMENT '额度有效期规则版本号',
  `CREDIT_RESULT_CODE` varchar(64) DEFAULT NULL COMMENT '授信结果代码',
  `EXTF1` varchar(5) DEFAULT NULL COMMENT '备用字段1',
  `EXTF2` varchar(20) DEFAULT NULL COMMENT '备用字段2',
  `EXTF3` varchar(50) DEFAULT NULL COMMENT '备用字段3',
  `EXTF4` varchar(200) DEFAULT NULL COMMENT '备用字段4',
  `EXTF5` varchar(1000) DEFAULT NULL COMMENT '备用字段5',
  PRIMARY KEY (`CREDIT_HISTORY_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='授信历史表';

/*Data for the table `ODS_RIC_CREDIT_HISTORY` */

/*Table structure for table `ODS_RIC_PRE_CREDIT` */

DROP TABLE IF EXISTS `ODS_RIC_PRE_CREDIT`;

CREATE TABLE `ODS_RIC_PRE_CREDIT` (
  `PRE_CREDIT_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT '预授信编号',
  `USER_ID` varchar(64) DEFAULT NULL COMMENT '用户编号',
  `CERT_NO` varchar(18) DEFAULT NULL COMMENT '身份证号码',
  `CREATE_TIME` datetime DEFAULT NULL COMMENT '创建时间',
  `START_TIME` datetime DEFAULT NULL COMMENT '有效开始时间',
  `END_TIME` datetime DEFAULT NULL COMMENT '有效截止时间',
  `UPDATE_TIME` datetime DEFAULT NULL COMMENT '更新时间',
  `PRE_AMOUNT` decimal(18,4) DEFAULT NULL COMMENT '预授信额度',
  `CHANNEL_ID` varchar(64) DEFAULT NULL COMMENT '渠道ID',
  `EXTF1` varchar(5) DEFAULT NULL COMMENT '备用字段1',
  `EXTF2` varchar(20) DEFAULT NULL COMMENT '备用字段2',
  `EXTF3` varchar(50) DEFAULT NULL COMMENT '备用字段3',
  `EXTF4` varchar(200) DEFAULT NULL COMMENT '备用字段4',
  `EXTF5` varchar(1000) DEFAULT NULL COMMENT '备用字段5',
  PRIMARY KEY (`PRE_CREDIT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='预授信表';

/*Data for the table `ODS_RIC_PRE_CREDIT` */

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

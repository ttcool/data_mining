# -*- coding:utf-8 -*-

import os
import json

BASE_DIR = os.path.dirname(os.path.dirname(__file__))


# kafka consumer config
KAFKA = {
    'topics': 'maxwell',
    'configs': {
        'bootstrap_servers': ['192.168.1.198:9092'],
        'group_id': 'kafka_consumer_01',
        'client_id': 'kafka_consumer_01',
        'enable_auto_commit': False,
        'auto_offset_reset': 'earliest',
        # 'value_deserializer': lambda m: json.loads(m.decode('utf-8'))
    }
}

# mysql config
MYSQL_CONFIG = {
    'origin': {
        'db': 'mysql',
        'user': 'dev',
        'passwd': '123456',
        'host': '192.168.1.198',
        'port': 3306,
        'charset': 'utf8'
    }
}

# mongodb config
MONGODB_CONFIG = {
    'default': {
        'host': '192.168.1.100:27017,192.168.1.101:27017,192.168.1.101:27018',
        'port': 27017,
        'user': 'bdp',
        'password': '123456',
        'db': 'bdp_data',
        'replicaSet': 'rs0'
    }
}

# bdp metadata database name only if BDP_STORAGE_TYPE = "mysql"
BDP_METADATA_DATABASE = "bdp_metadata"
ODS_target_DATABASE = "odsybr"

# only if BDP_STORAGE_TYPE = "mongodb", all data in BDP_DATABASE
BDP_DATABASE = "bdp_data"

# origin log directory
ORIGIN_LOG_DIR = '/var/log/supervisor/syphbdp/'

# bdp storage type, mysql or mongodb
BDP_STORAGE_TYPE = "mongodb"

# bdp origin collection prefix
BDP_ORIGIN_PREFIX = "stg"

# logger config
LOGGING_DIR = os.path.join(BASE_DIR, 'logs')
if not os.path.exists(LOGGING_DIR):
    os.makedirs(LOGGING_DIR)
LOGGING = {
    'formatter': '%(levelname)s %(asctime)s %(process)d %(thread)d %(pathname)s [line:%(lineno)d] %(message)s',
    'handlers': {
        'console': {
            'class': 'logging.StreamHandler',
            'level': 'INFO',
        },
        'origin': {
            'class': 'logging.FileHandler',
            'filename': os.path.join(LOGGING_DIR, 'bdp_origin.log'),
            'maxBytes': 1024 * 1024 * 20,
            'backupCount': 200,
            'level': 'INFO',
        },
        'syphbdp': {
            'class': 'logging.FileHandler',
            'filename': os.path.join(LOGGING_DIR, 'syphbdp.log'),
            'maxBytes': 1024 * 1024 * 20,
            'backupCount': 200,
            'level': 'INFO',
        },
    },
    'loggers': {
        'apps.origin': {
            'handlers': ['console', 'origin'],
            'level': 'INFO',
        },
        'syphbdp': {
            'handlers': ['console', 'syphbdp'],
            'level': 'INFO',
        }

    }
}


# -*- coding: utf-8 -*-

import json

from kafka import KafkaConsumer
from kafka.errors import NoBrokersAvailable
from MySQLdb.connections import IntegrityError

from conf.settings import KAFKA, BDP_STORAGE_TYPE
from vendor.public.log import get_logger
from apps.origin.parse.maxwell import MaxwellParse
from vendor.public.method import get_str_hash_ord
from operater import DataOperator

logger = get_logger("apps.origin")


def main():
    consumer = None
    data_operator = None
    try:
        logger.info("Start Kafka consumer, config=%s", KAFKA)
        consumer = KafkaConsumer(KAFKA["topics"], **KAFKA["configs"])
        for message in consumer:
            try:
                logger.info("Consume message offset=%s, value=%s", message.offset, message.value)
                if message.value:
                    hash_ord = get_str_hash_ord(message.value)
                    data = json.loads(message.value, encoding='utf-8')
                    mp = MaxwellParse(data, hash_ord)
                    operate_type, data = mp.parse()
                    data_operator = DataOperator(BDP_STORAGE_TYPE)
                    data_operator.start_execute(operate_type, data)
                    consumer.commit()
                logger.info("Kafka consumer commit offset=%s", message.offset)
            except (ValueError, IntegrityError), e:
                logger.error("Message can't decode or handle, Exception=%s", e.args)
                consumer.commit()
            except Exception, e:
                logger.error("Consumer message Exception=%s", e.args, exc_info=True)
                if data_operator:
                    data_operator.rollback()
                # break

    except NoBrokersAvailable:
        logger.error("Kafka consumer connection error, please check conf.settings.KAFKA")
    except Exception, e:
        logger.error("Consumer main Exception=%s", e.args, exc_info=True)
    finally:
        if consumer:
            consumer.close()
        if data_operator:
            data_operator.clear()


if __name__ == '__main__':
    main()
# -*- coding: utf-8 -*-

from apps.origin.storage.mysql.handler import Handler as MySQLHandler
from vendor.connection.mysql import origin_conn as conn, origin_cursor as cur
from apps.origin.storage.mongo.handler import Handler as MongodbHandler
from vendor.connection.mongo import db
from vendor.public.method import get_collection_name, transform_data
from vendor.constants.COMMON import OPERATE_TYPE
from conf.settings import BDP_DATABASE


class WrappedMySQLHandler(object):
    """wrapped for mysql handler"""

    @staticmethod
    def start_execute(operate_type, data):
        handler = MySQLHandler()
        execute_method = getattr(handler, "execute_" + operate_type, None)
        if callable(execute_method):
            execute_method(cur, data)
            conn.commit()

    @staticmethod
    def clear():
        cur.close()
        conn.close()

    @staticmethod
    def rollback():
        conn.rollback()


class WrappedMongodbHandler(object):
    """wrapped for mongodb handler"""

    @staticmethod
    def start_execute(operate_type, data):
        coll_name = get_collection_name(data["database"], data["table"])
        coll = getattr(db, coll_name)
        handler = MongodbHandler()
        execute_method = getattr(handler, "execute_" + operate_type, None)
        if callable(execute_method):
            if operate_type in (OPERATE_TYPE['INSERT'], OPERATE_TYPE['UPDATE'], OPERATE_TYPE['DELETE']):
                bdp_columns = getattr(db, "bdp_columns")
                data["data"] = transform_data(data["data"], BDP_DATABASE + "__" + coll_name, bdp_columns)
                execute_method(coll, data)
            else:
                execute_method(coll, data, db)

    @staticmethod
    def clear():
        pass

    @staticmethod
    def rollback():
        pass


class DataOperator(object):
    """Kafka message consumer operator, wrapped for mysql or mongodb handler

    Arguments:
    storage: bdp storage type config from conf.settings.
    """
    def __init__(self, storage="mongodb"):
        self.storage = storage
        self.wrapped_handler = self.get_handler()

    def get_handler(self):
        """Get mysql or mongodb handler through self.storage"""
        if self.storage == "mysql":
            wrapped_handler = WrappedMySQLHandler
        else:
            wrapped_handler = WrappedMongodbHandler

        return wrapped_handler

    def start_execute(self, operate_type, data):
        """get execute_method , and start handler's execute_method
        :param operate_type: ddl or dml operate, get from packet["type"] or classify from packet["type"],
        :param data: after parse data
        """
        return self.wrapped_handler.start_execute(operate_type, data)

    def clear(self):
        """main process exit, clear db connections"""
        return self.wrapped_handler.clear()

    def rollback(self):
        """rollback for transaction operate"""
        return self.wrapped_handler.rollback()

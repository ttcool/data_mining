# -*- coding: utf-8 -*-

import re
import copy

from vendor.public.log import get_logger
from vendor.constants.COMMON import BDP_STATUS, TABLE_STATUS, COLUMN_STATUS, OPERATE_TYPE, SCHEMA_STATUS

logger = get_logger("apps.origin")


class MaxwellParse(object):
    """Parse maxwell Json packet

    Arguments:
    packet: maxwell json packet.
    hash_ord: hash ord for json sting
    operate_type: ddl or dml operate, get from packet["type"] or classify from packet["type"].
    database: source database, get from packet["database"].
    table: source table, get from packet["table"].
    sql: operate sql, get from packet["sql"] or None.
    old_def: old table structure or old table record, get from packet["old"] or None.
    new_def: new table structure, get from packet["def"] or None.
    data: new table record, get from packet["data"] or None.
    bdp_updated_time: last update time, get from packet["ts"].
    bdp_status: table record status, 0, 1 or 2.
    """
    def __init__(self, packet, hash_ord):
        assert isinstance(packet, dict), 'packet:%s must be instance of dict' % packet
        self.packet = packet
        self.hash_ord = hash_ord
        self.operate_type = packet.get("type").replace("-", "_")
        self.database = packet.get("database")
        self.table = packet.get("table")
        self.sql = packet.get("sql", '')
        self.old_def = packet.get("old")
        self.new_def = packet.get("def")
        self.data = packet.get("data")
        self.charset = packet.get("charset")
        self.collation_name = ''
        self.xid = packet.get("xid", 0)
        self.bdp_updated_time = self.get_bdp_updated_time()
        self.bdp_status = BDP_STATUS["BUSINESS"]
        self.result = {}

    def parse(self):
        opt, parse_data = self.operate_type, self.packet
        parse_method = getattr(self, "parse_" + self.operate_type.lower(), None)
        if callable(parse_method):
            opt, parse_data = parse_method()
        else:
            logger.error("operate_type:%s can't parsed, return origin packet", self.operate_type)
        self.fill_database_name(self.database, self.table)

        self.result.update(
            database=self.database,
            table=self.table,
            data=parse_data,
            sql=self.sql
        )
        logger.info("Parse opt:%s result:%s", opt, self.result)

        return opt, self.result

    def parse_insert(self):
        """Parse insert json packet from maxwell
        """
        assert self.data and isinstance(self.data, dict), 'Insert data:%s must be not None and instance of dict' \
                                                          % self.data
        self.data.update(
            bdp_updated_time=self.bdp_updated_time,
            bdp_status=self.bdp_status,
        )

        return self.operate_type, self.data

    def parse_update(self):
        """Parse update json packet from maxwell
        """
        assert self.data and isinstance(self.data, dict), 'After update data:%s must be not None and instance of dict' \
                                                          % self.data
        assert self.old_def and isinstance(self.old_def, dict), 'Updated data:%s must be not None and instance of dict'\
                                                                % self.old_def
        new_data = copy.deepcopy(self.data)
        new_data.update({
            "bdp_updated_time": self.bdp_updated_time,
            "bdp_status": self.bdp_status
        })
        old_data = copy.deepcopy(self.data)
        old_data.update(self.old_def)
        old_data.update({
            "bdp_updated_time": self.bdp_updated_time,
            "bdp_status": BDP_STATUS["UPDATED"]
        })

        return self.operate_type, {"new_data": new_data, "old_data": old_data}

    def parse_delete(self):
        """Parse delete json packet from maxwell
        """
        assert self.data and isinstance(self.data, dict), 'Deleted data:%s must be not None and instance of dict' \
                                                          % self.data
        self.data.update(
            bdp_updated_time=self.bdp_updated_time,
            bdp_status=BDP_STATUS["DELETED"],
        )

        return self.operate_type, self.data

    def parse_table_create(self):
        """Parse table create json packet from maxwell
        """
        assert self.new_def and isinstance(self.new_def, dict), 'Create data:%s must be not None and instance of dict'\
                                                                % self.new_def
        assert self.sql, 'Packet:%s sql is None' % self.packet
        table_add = dict(
            table_schema=self.database,
            table_name=self.table,
            table_status=TABLE_STATUS["BUSINESS"],
            created_time=self.bdp_updated_time
        )
        column_add_list = []
        primary_columns = []
        for col in self.new_def["columns"]:
            if col["name"] in self.new_def["primary-key"]:
                primary_key = "PRI"
                primary_columns.append(col["name"])
            else:
                primary_key = ""
            column_add_list.append(dict(
                table_schema=self.database,
                table_name=self.table,
                column_name=col["name"],
                column_status=COLUMN_STATUS["BUSINESS"],
                column_type=col["type"],
                column_key=primary_key,
                created_time=self.bdp_updated_time
            ))
        column_add_list.append(dict(
            table_schema=self.database,
            table_name=self.table,
            column_name="bdp_updated_time",
            column_status=COLUMN_STATUS["BUSINESS"],
            column_type="int",
            column_key="",
            created_time=self.bdp_updated_time
        ))
        column_add_list.append(dict(
            table_schema=self.database,
            table_name=self.table,
            column_name="bdp_status",
            column_status=COLUMN_STATUS["BUSINESS"],
            column_type="tinyint",
            column_key="",
            created_time=self.bdp_updated_time
        ))
        sql_ext = ", bdp_updated_time bigint(13) DEFAULT 0, bdp_status tinyint(1) DEFAULT 0"
        if primary_columns:
            pk_reg = re.compile("primary\s+key", re.I)
            mut_pk_reg_mid = re.compile("primary\s+key\s+\(.*\)\s*,", re.I)
            mut_pk_reg_end = re.compile(",\s*primary\s+key\s+\(.*\)\s*\)", re.I)
            if mut_pk_reg_mid.search(self.sql):
                self.sql = mut_pk_reg_mid.sub(' ', self.sql)
            elif mut_pk_reg_end.search(self.sql):
                self.sql = mut_pk_reg_end.sub(' )', self.sql)
            elif pk_reg.search(self.sql):
                self.sql = pk_reg.sub(' ', self.sql)
            primary_columns.append("bdp_updated_time")
            primary_columns.append("bdp_status")
            sql_ext += ", PRIMARY KEY (%s)" % ','.join(primary_columns)
        self.sql = self.sql[:self.sql.rfind(")")] + sql_ext + self.sql[self.sql.rfind(")"):]

        return self.operate_type, {"table_add": table_add, "column_add_list": column_add_list}

    def parse_table_alter(self):
        """Parse table alter json packet from maxwell,
           include operation is add_column, change_column, delete_column, rename_table
        """
        assert self.new_def and isinstance(self.new_def, dict), 'New_def data:%s must be instance of dict' \
                                                                % self.new_def
        assert self.old_def and isinstance(self.old_def, dict), 'Old_def data:%s must be instance of dict' \
                                                                % self.old_def
        operate_type = self.operate_type
        data = None
        sql = self.sql.lower()
        if "add" in sql:
            operate_type, data = self.parse_add_column()
        elif "change" in sql or ("modify" in sql and "column" in sql):
            operate_type, data = self.parse_change_column()
        elif "drop" in sql:
            operate_type, data = self.parse_delete_column()
        elif "rename" in sql:
            operate_type, data = self.parse_rename_table()
        else:
            logger.error("Can't handle operate_type:%s and data:%s", self.operate_type, self.packet)

        return operate_type, data

    def parse_table_drop(self):
        assert self.sql, 'Packet:%s sql is None' % self.packet
        table_update = dict(
            bdp_status=COLUMN_STATUS["DELETED"],
            bdp_updated_time=self.bdp_updated_time,
        )
        pdb_table_update = dict(
            table_schema=self.database,
            table_name=self.table,
            table_status=TABLE_STATUS["DELETED"],
            updated_time=self.bdp_updated_time
        )

        return self.operate_type, {"table_update": table_update, "pdb_table_update": pdb_table_update}

    @staticmethod
    def get_update_columns(full_columns, part_columns):
        """Get add or update and delete columns name from maxwell json packets columns,
            columns is list, and item of list is dict
            For example:
            "columns": [{
                    "type": "varchar",
                    "name": "username",
                    "charset": "utf8"
                    },
                    {
                        "type": "varchar",
                        "name": "email",
                        "charset": "utf8"
                    }
                ]
            :param full_columns, full columns like after add columns or before delete columns
            :param part_columns, a part of full_columns, or has different column with full_columns
            :return name list of update columns
        """
        full = [c["name"] for c in full_columns]
        part = [c["name"] for c in part_columns]
        update_columns = list(set(full).difference(set(part)))

        return update_columns

    def parse_add_column(self):
        operate_type = OPERATE_TYPE["TABLE_ALTER"]["ADD_COLUMN"]
        data = []
        add_columns = self.get_update_columns(self.new_def["columns"], self.old_def["columns"])
        for col in self.new_def["columns"]:
            if col["name"] in add_columns:
                if col["name"] in self.new_def["primary-key"]:
                    primary_key = "PRI"
                else:
                    primary_key = ""
                data.append(dict(
                        column_name=col["name"],
                        table_schema=self.database,
                        table_name=self.table,
                        column_key=primary_key,
                        column_status=COLUMN_STATUS["BUSINESS"],
                        column_type=col["type"],
                        created_time=self.bdp_updated_time))

        return operate_type, data

    def parse_change_column(self):
        operate_type = OPERATE_TYPE["TABLE_ALTER"]["CHANGE_COLUMN"]
        new_column = self.get_update_columns(self.new_def["columns"], self.old_def["columns"])
        old_column = self.get_update_columns(self.old_def["columns"], self.new_def["columns"])
        new_add = []
        old_update = []
        change_map = {}

        if "CHANGE" in self.sql.upper():
            if len(new_column) == 1:
                change_map[new_column[0]] = old_column[0]
            else:
                change_list = self.sql.split(",")
                for ccm in change_list:
                    if "CHANGE" in ccm:
                        columns = ccm[ccm.rfind("CHANGE"):].split()
                    elif "change" in ccm:
                        columns = ccm[ccm.rfind("change"):].split()
                    if columns[1].upper() == "COLUMN":
                        del columns[1]
                    oc = columns[1].strip().strip("\`")
                    nc = columns[2].strip().strip("\`")
                    change_map[nc] = oc

        for old in old_column:
            old_update.append(dict(
                    table_schema=self.database,
                    table_name=self.table,
                    column_status=COLUMN_STATUS["DELETED"],
                    updated_time=self.bdp_updated_time,
                    column_name=old
            ))
        for col in new_column:
            for _col in self.new_def["columns"]:
                if _col["name"] == col:
                    if _col["name"] in self.new_def["primary-key"]:
                        primary_key = "PRI"
                    else:
                        primary_key = ""
                    new_add.append(dict(
                            rename_from=change_map.get(_col["name"], ""),
                            column_name=_col["name"],
                            table_schema=self.database,
                            table_name=self.table,
                            column_key=primary_key,
                            column_status=COLUMN_STATUS["BUSINESS"],
                            column_type=_col["type"],
                            created_time=self.bdp_updated_time
                    ))

        data = {"old_update": old_update, "new_add": new_add, "change_map": change_map}

        return operate_type, data

    def parse_delete_column(self):
        operate_type = OPERATE_TYPE["TABLE_ALTER"]["DELETE_COLUMN"]
        delete_columns = self.get_update_columns(self.old_def["columns"], self.new_def["columns"])[0]
        data = dict(
            table_schema=self.database,
            table_name=self.table,
            column_name=delete_columns,
            updated_time=self.bdp_updated_time,
            column_status=COLUMN_STATUS["DELETED"],
        )

        return operate_type, data

    def parse_rename_table(self):
        operate_type = OPERATE_TYPE["TABLE_ALTER"]["RENAME_TABLE"]
        tables = self.sql[self.sql.lower().rfind("table"):]
        tables_split = tables.split()
        old_table = tables_split[1].strip().strip("\`")
        new_table = tables_split[-1].strip().strip("\`")
        old_update = dict(
            table_schema=self.database,
            table_name=old_table,
            updated_time=self.bdp_updated_time,
            table_status=TABLE_STATUS["UPDATED"]
        )
        new_add = dict(
            table_name=new_table,
            table_schema=self.database,
            table_status=TABLE_STATUS["BUSINESS"],
            rename_from=old_table,
            created_time=self.bdp_updated_time
        )
        data = {"old_update": old_update, "new_add": new_add}
        self.fill_database_name(self.database, new_table)

        return operate_type, data

    def parse_database_create(self):
        data = dict(
            schema_name=self.database,
            character_set=self.charset,
            collation_name=self.collation_name,
            schema_status=SCHEMA_STATUS["BUSINESS"],
            comment='',
            created_time=self.bdp_updated_time
        )
        return self.operate_type, data

    def fill_database_name(self, database, table, count=1):
        if database and table and '{0}.{1}'.format(database, table) not in self.sql \
                and '`{0}`.`{1}`'.format(database, table) not in self.sql:
            if '`{0}`'.format(table) in self.sql:
                replace_table = '`{0}`'.format(table)
            else:
                replace_table = table
            self.sql = self.sql.replace(replace_table, database + "." + table, count)

    def get_bdp_updated_time(self):
        bdp_updated_time = self.packet["ts"] if len(str(self.packet.get("ts"))) == 13 else self.packet["ts"] * 1000
        logger.info("bdp_updated_time from %s plus hash_ord:%s", bdp_updated_time, self.hash_ord % 1000)
        bdp_updated_time += self.hash_ord % 1000

        return bdp_updated_time
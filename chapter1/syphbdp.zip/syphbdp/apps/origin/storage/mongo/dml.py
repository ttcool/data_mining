# -*- coding: utf-8 -*-

import copy

from vendor.constants.COMMON import BDP_STATUS
from vendor.public.log import get_logger

logger = get_logger("apps.origin")


class DMLHandler(object):
    """Handle origin dml operation from mongodb dml operation,
       is different from mongodb dml operation, wrapped from mongodb dml operation,
       handle data from maxwell.MaxwellParse.
    """
    @staticmethod
    def execute_insert(coll, data):
        """Execute insert operation for bdp origin.

        :param coll: mongodb collection object,
        :param data: insert data from Maxwell json packet,
           data["data"] is insert data
           data:
           {
               "database": database,
               "table": table,
               "data": {
                   k:v,
               }
           }
        """
        assert data and isinstance(data["data"], dict) and coll
        logger.info("Collection:%s, insert data:%s", coll.name, data["data"])
        coll.insert_one(data["data"])

    @staticmethod
    def execute_update(coll, data):
        """Execute update operation for bdp origin.

        :param coll: mongodb collection object,
        :param data: insert data from Maxwell json packet,
           data["data"] is insert data
           data:
           {
               "database": database,
               "table": table,
               "data":{
                   "new_data": {
                       "bdp_status": 0,
                       k:v,
                   },
                   "old_data": {
                       "bdp_status": 1,
                       k:v,
                   }
               }
           }
        """
        assert data and isinstance(data, dict) and coll
        assert data["data"]["new_data"] and isinstance(data["data"]["new_data"], dict)
        assert data["data"]["old_data"] and isinstance(data["data"]["old_data"], dict)
        filter_data = copy.deepcopy(data["data"]["old_data"])
        filter_data.pop("bdp_updated_time")
        filter_data.update({"bdp_status": BDP_STATUS["BUSINESS"]})
        coll.update_one(filter_data, {"$set": data["data"]["old_data"]})
        logger.info("Collection:%s, update data:%s, filter_data:%s",
                    coll.name, data["data"]["old_data"], filter_data)
        coll.insert_one(data["data"]["new_data"])
        logger.info("Collection:%s, insert data:%s", coll.name, data["data"]["new_data"])

    @staticmethod
    def execute_delete(coll, data):
        """Execute delete operation for bdp origin.

        :param coll: mongodb collection object,
        :param data: insert data from Maxwell json packet,
           data["data"] is updated data
           data:
           {
               "database": database,
               "table": table,
               "data": {
                   k:v,
               }
           }
        """
        assert data and isinstance(data, dict) and coll
        filter_data = copy.deepcopy(data["data"])
        filter_data.pop("bdp_updated_time")
        filter_data.update({"bdp_status": BDP_STATUS["BUSINESS"]})
        coll.update_many(filter_data, {"$set": data["data"]})
        logger.info("Collection:%s, update data:%s, filter_data:%s",
                    coll.name, data["data"], filter_data)

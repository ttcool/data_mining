# -*- coding: utf-8 -*-

from dml import DMLHandler
from ddl import DDLHandler


class Handler(DDLHandler, DMLHandler):
    pass


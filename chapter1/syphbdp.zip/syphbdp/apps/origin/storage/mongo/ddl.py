# -*- coding: utf-8 -*-

import copy

from pymongo.errors import CollectionInvalid

from vendor.constants.COMMON import BDP_TABLES, COLUMN_STATUS, TABLE_STATUS, BDP_STATUS
from vendor.public.log import get_logger
from vendor.public.method import get_collection_name, transform_db_and_table

logger = get_logger("apps.origin")


class DDLHandler(object):
    """Handle origin ddl operation from mongodb dml operation,
       is different from mongodb ddl operation, wrapped from mongodb ddl operation,
       handle data from maxwell.MaxwellParse.
    """
    @staticmethod
    def execute_table_create(coll, data, db):
        """Execute table_create operation for bdp origin.

        :param coll: mongodb collection object,
        :param data: table_create data from Maxwell json packet,
        :param db: mongodb database object
           data:
           {
               "database": database,
               "table": table,
               "sql": sql,
               "data": {
                   "table_add": {},
                   "column_add_list": [
                       {k:v,}
                   ]
                   k:v,
               }
           }
        """
        assert data and isinstance(data["data"], dict)

        coll_name = get_collection_name(data["database"], data["table"])
        try:
            db.create_collection(coll_name)
            bdp_tables = getattr(db, BDP_TABLES["TABLES"])
            bdp_columns = getattr(db, BDP_TABLES["COLUMNS"])
            table_add = transform_db_and_table(data["data"]["table_add"], data["database"], data["table"])
            bdp_tables.insert_one(table_add)
            logger.info("Collection:%s, insert data:%s", bdp_tables.name, table_add)
            column_add_list = transform_db_and_table(data["data"]["column_add_list"], data["database"], data["table"])
            bdp_columns.insert_many(column_add_list)
            logger.info("Collection:%s, insert data:%s", bdp_columns.name, column_add_list)
        except CollectionInvalid:
            logger.warn("Collection:%s already exists", coll_name)

    @staticmethod
    def execute_add_column(coll, data, db):
        """Execute add_column operation for bdp origin.

        :param coll: mongodb collection object,
        :param data: add_column data from Maxwell json packet,
        :param db: mongodb database object
           data["data"] is insert data
           data:
           {
               "database": database,
               "table": table,
               "sql": sql,
               "data": [
                   {
                       k:v,
                   }
               ]
           }
        """
        assert data and isinstance(data["data"], list) and coll

        bdp_columns = getattr(db, BDP_TABLES["COLUMNS"])
        columns_add = transform_db_and_table(data["data"], data["database"], data["table"])
        bdp_columns.insert_many(columns_add)
        logger.info("Collection:%s, insert data:%s", bdp_columns.name, columns_add)

    @staticmethod
    def execute_change_column(coll, data, db):
        """Execute change_column operation for bdp origin.

        :param coll: mongodb collection object,
        :param data: change_column data from Maxwell json packet,
        :param db: mongodb database object
           data["data"]["new_add"] is insert data
           data:
           {
               "database": database,
               "table": table,
               "sql": sql,
               "data": {
                   "old_update": [
                        {k:v,}
                   ],
                   "new_add": [
                        {k:v,}
                   ],
                   "change_map": {
                        "old_column":"",
                        "new_column":""
                   }
                   k:v,
               }
           }
        """
        assert data and isinstance(data["data"], dict) and coll

        for k, v in data["data"]["change_map"].iteritems():
            coll.update({}, {'$rename': {v: k}}, False, multi=True)
            logger.info("Collection:%s change column:%s to %s",
                        coll.name, v, k)
        bdp_columns = getattr(db, BDP_TABLES["COLUMNS"])
        new_add = transform_db_and_table(data["data"]["new_add"], data["database"], data["table"])
        bdp_columns.insert_many(new_add)
        logger.info("Collection:%s, insert data:%s", bdp_columns.name, new_add)
        old_update = transform_db_and_table(data["data"]["old_update"], data["database"], data["table"])
        for old in old_update:
            filter_data = copy.deepcopy(old)
            filter_data.pop("updated_time")
            filter_data.update({"column_status": COLUMN_STATUS["BUSINESS"]})
            bdp_columns.update_one(filter_data, {"$set": old})
            logger.info("Collection:%s, update data:%s, filter_data:%s",
                        bdp_columns.name, old, filter_data)

    @staticmethod
    def execute_delete_column(coll, data, db):
        """Execute delete_column operation for bdp origin.

        :param coll: mongodb collection object,
        :param data: delete_column data from Maxwell json packet,
        :param db: mongodb database object
           data:
           {
               "database": database,
               "table": table,
               "sql": sql,
               "data": {
                   k:v,
               }
           }
        """
        assert data and isinstance(data["data"], dict) and coll
        assert data["sql"]

        delete_column = transform_db_and_table(data["data"], data["database"], data["table"])
        filter_data = copy.deepcopy(delete_column)
        filter_data.pop("updated_time")
        filter_data.update({"column_status": COLUMN_STATUS["BUSINESS"]})
        bdp_columns = getattr(db, BDP_TABLES["COLUMNS"])
        bdp_columns.update_one(filter_data, {"$set": delete_column})
        logger.info("Collection:%s, update data:%s, filter_data:%s",
                    bdp_columns.name, delete_column, filter_data)

    @staticmethod
    def execute_rename_table(coll, data, db):
        """Execute rename_table operation for bdp origin.

        :param coll: mongodb collection object,
        :param data: rename_table data from Maxwell json packet,
        :param db: mongodb database object
           data:
           {
               "database": database,
               "table": table,
               "sql": sql,
               "data": {
                   "old_update": {},
                   "new_add": {k:v,}
                   k:v,
               }
           }
        """
        assert data and isinstance(data["data"], dict) and coll

        new_coll_name = get_collection_name(data["database"], data["data"]["new_add"]["table_name"])
        coll.rename(new_coll_name)
        logger.info("Collection:%s rename to :%s", coll.name, new_coll_name)
        old_update = transform_db_and_table(data["data"]["old_update"], data["database"], data["table"])
        filter_data = copy.deepcopy(old_update)
        filter_data.pop("updated_time")
        filter_data.update({"table_status": TABLE_STATUS["BUSINESS"]})
        bdp_tables = getattr(db, BDP_TABLES["TABLES"])
        new_add = transform_db_and_table(data["data"]["new_add"], data["database"], data["table"])
        bdp_tables.insert_one(new_add)
        logger.info("Collection:%s, insert data:%s", bdp_tables.name, new_add)
        bdp_tables.update_one(filter_data, {"$set": old_update})
        logger.info("Collection:%s, update data:%s, filter_data:%s",
                    bdp_tables.name, old_update, filter_data)

    @staticmethod
    def execute_table_drop(coll, data, db):
        """Execute table_drop operation for bdp origin.

        :param coll: mongodb collection object,
        :param data: table_drop data from Maxwell json packet,
        :param db: mongodb database object
           data:
           {
               "database": database,
               "table": table,
               "sql": sql,
               "data": {
                   "table_update": {},
                   "pdb_table_update": {k:v,}
                   k:v,
               }
           }
        """
        assert data and isinstance(data["data"], dict) and coll

        coll.update_many({"bdp_status": BDP_STATUS["BUSINESS"]}, {"$set": data["data"]["table_update"]})
        logger.info("Collection:%s, update data:%s, filter_data:%s",
                    coll.name, data["data"]["table_update"], {"bdp_status": BDP_STATUS["BUSINESS"]})
        pdb_table_update = transform_db_and_table(data["data"]["pdb_table_update"], data["database"], data["table"])
        filter_data = copy.deepcopy(pdb_table_update)
        filter_data.pop("updated_time")
        filter_data.update({"table_status": TABLE_STATUS["BUSINESS"]})
        bdp_tables = getattr(db, BDP_TABLES["TABLES"])
        bdp_tables.update_one(filter_data, {"$set": pdb_table_update})
        logger.info("Collection:%s, update data:%s, filter_data:%s",
                    bdp_tables.name, pdb_table_update, filter_data)

    @staticmethod
    def execute_database_create(coll, data, db):
        """Execute database_create operation for bdp origin.

        :param coll: mongodb collection object,
        :param data: database_create data from Maxwell json packet,
        :param db: mongodb database object
           data:
           {
               "database": database,
               "table": table,
               "sql": sql,
               "data": {
                   "schema_name": "",
                   "character_set": '',
                   k:v,
               }
           }
        """
        assert data and isinstance(data["data"], dict) and coll

        logger.info("mongodb origin ignore database create packet:%s", data)




# -*- coding: utf-8 -*-

import copy

from MySQLdb.connections import IntegrityError

from vendor.public.sql import mysql_insert, mysql_update, mysql_delete
from vendor.constants.COMMON import BDP_STATUS
from vendor.public.log import get_logger

logger = get_logger("apps.origin")


class DMLHandler(object):
    """Handle origin dml operation from MySQL dml operation,
       is different from MySQL dml operation, wrapped from MySQL dml operation,
       handle data from maxwell.MaxwellParse.
    """
    @staticmethod
    def execute_insert(cur, data):
        """Execute insert operation for bdp origin.

        :param cur: MySQL connection cursor,
        :param data: insert data from Maxwell json packet
           data["data"] is insert data
           data:
           {
               "database": database,
               "table": table,
               "data": {
                   k:v,
               }
           }
        """
        assert data and isinstance(data["data"], dict) and cur
        mysql_insert(cur, data["database"], data["table"], data["data"])

    @staticmethod
    def execute_update(cur, data):
        """Execute update operation for bdp origin.

        :param cur: MySQL connection cursor,
        :param data: insert data from Maxwell json packet
           data["data"] is insert data
           data:
           {
               "database": database,
               "table": table,
               "data":{
                   "new_data": {
                       "bdp_status": 0,
                       k:v,
                   },
                   "old_data": {
                       "bdp_status": 1,
                       k:v,
                   }
               }
           }
        """
        assert data and isinstance(data, dict) and cur
        assert data["data"]["new_data"] and isinstance(data["data"]["new_data"], dict)
        assert data["data"]["old_data"] and isinstance(data["data"]["old_data"], dict)
        filter_data = copy.deepcopy(data["data"]["old_data"])
        filter_data.pop("bdp_updated_time")
        filter_data.update({"bdp_status": BDP_STATUS["BUSINESS"]})
        try:
            mysql_update(cur, data["database"], data["table"], data["data"]["old_data"], filter_data)
            mysql_insert(cur, data["database"], data["table"], data["data"]["new_data"])
        except IntegrityError:
            # delete duplicate
            logger.warn("Delete duplicate filter_data:%s", filter_data)
            mysql_delete(cur, data["database"], data["table"], filter_data)

    @staticmethod
    def execute_delete(cur, data):
        """Execute delete operation for bdp origin.

        :param cur: MySQL connection cursor,
        :param data: insert data from Maxwell json packet
           data["data"] is updated data
           data:
           {
               "database": database,
               "table": table,
               "data": {
                   k:v,
               }
           }
        """
        assert data and isinstance(data, dict) and cur
        filter_data = copy.deepcopy(data["data"])
        filter_data.pop("bdp_updated_time")
        filter_data.update({"bdp_status": BDP_STATUS["BUSINESS"]})
        mysql_update(cur, data["database"], data["table"], data["data"], filter_data)



# -*- coding: utf-8 -*-

import copy

from vendor.public.sql import mysql_insert, mysql_insert_many, mysql_update
from vendor.constants.COMMON import BDP_TABLES, COLUMN_STATUS, TABLE_STATUS, BDP_STATUS
from conf.settings import BDP_METADATA_DATABASE
from vendor.public.log import get_logger

logger = get_logger("apps.origin")


class DDLHandler(object):
    """Handle origin ddl operation from MySQL dml operation,
       is different from MySQL ddl operation, wrapped from MySQL ddl operation,
       handle data from maxwell.MaxwellParse.
    """
    @staticmethod
    def execute_table_create(cur, data):
        """Execute table_create operation for bdp origin.

        :param cur: MySQL connection cursor,
        :param data: table_create data from Maxwell json packet
           data:
           {
               "database": database,
               "table": table,
               "sql": sql,
               "data": {
                   "table_add": {},
                   "column_add_list": [
                       {k:v,}
                   ]
                   k:v,
               }
           }
        """
        assert data and isinstance(data["data"], dict) and cur
        assert data["sql"]

        logger.info("Execute SQL:%s", data["sql"])
        cur.execute(data["sql"])
        mysql_insert(cur, BDP_METADATA_DATABASE, BDP_TABLES["TABLES"], data["data"]["table_add"])
        mysql_insert_many(cur, BDP_METADATA_DATABASE, BDP_TABLES["COLUMNS"], data["data"]["column_add_list"])

    @staticmethod
    def execute_add_column(cur, data):
        """Execute add_column operation for bdp origin.

        :param cur: MySQL connection cursor,
        :param data: add_column data from Maxwell json packet
           data["data"] is insert data
           data:
           {
               "database": database,
               "table": table,
               "sql": sql,
               "data": [
                   {
                       k:v,
                   }
               ]
           }
        """
        assert data and isinstance(data["data"], list) and cur
        assert data["sql"]

        logger.info("Execute SQL:%s", data["sql"])
        cur.execute(data["sql"])
        mysql_insert_many(cur, BDP_METADATA_DATABASE, BDP_TABLES["COLUMNS"], data["data"])

    @staticmethod
    def execute_change_column(cur, data):
        """Execute change_column operation for bdp origin.

        :param cur: MySQL connection cursor,
        :param data: change_column data from Maxwell json packet
           data["data"]["new_add"] is insert data
           data:
           {
               "database": database,
               "table": table,
               "sql": sql,
               "data": {
                   "old_update": [
                        {k:v,}
                   ],
                   "new_add": [
                        {k:v,}
                   ]
                   k:v,
               }
           }
        """
        assert data and isinstance(data["data"], dict) and cur
        assert data["sql"]

        logger.info("Execute SQL:%s", data["sql"])
        cur.execute(data["sql"])
        mysql_insert_many(cur, BDP_METADATA_DATABASE, BDP_TABLES["COLUMNS"], data["data"]["new_add"])
        for old in data["data"]["old_update"]:
            filter_data = copy.deepcopy(old)
            filter_data.pop("updated_time")
            filter_data.update({"column_status": COLUMN_STATUS["BUSINESS"]})
            mysql_update(cur,  BDP_METADATA_DATABASE, BDP_TABLES["COLUMNS"], old, filter_data)

    @staticmethod
    def execute_delete_column(cur, data):
        """Execute delete_column operation for bdp origin.

        :param cur: MySQL connection cursor,
        :param data: delete_column data from Maxwell json packet
           data:
           {
               "database": database,
               "table": table,
               "sql": sql,
               "data": {
                   k:v,
               }
           }
        """
        assert data and isinstance(data["data"], dict) and cur
        assert data["sql"]

        filter_data = copy.deepcopy(data["data"])
        filter_data.pop("updated_time")
        filter_data.update({"column_status": COLUMN_STATUS["BUSINESS"]})
        mysql_update(cur,  BDP_METADATA_DATABASE, BDP_TABLES["COLUMNS"], data["data"], filter_data)

    @staticmethod
    def execute_rename_table(cur, data):
        """Execute rename_table operation for bdp origin.

        :param cur: MySQL connection cursor,
        :param data: rename_table data from Maxwell json packet
           data:
           {
               "database": database,
               "table": table,
               "sql": sql,
               "data": {
                   "old_update": {},
                   "new_add": {k:v,}
                   k:v,
               }
           }
        """
        assert data and isinstance(data["data"], dict) and cur
        assert data["sql"]

        logger.info("Execute SQL:%s", data["sql"])
        cur.execute(data["sql"])
        mysql_insert(cur, BDP_METADATA_DATABASE, BDP_TABLES["TABLES"], data["data"]["new_add"])
        filter_data = copy.deepcopy(data["data"]["old_update"])
        filter_data.pop("updated_time")
        filter_data.update({"table_status": TABLE_STATUS["BUSINESS"]})
        mysql_update(cur,  BDP_METADATA_DATABASE, BDP_TABLES["TABLES"], data["data"]["old_update"], filter_data)

    @staticmethod
    def execute_table_drop(cur, data):
        """Execute table_drop operation for bdp origin.

        :param cur: MySQL connection cursor,
        :param data: table_drop data from Maxwell json packet
           data:
           {
               "database": database,
               "table": table,
               "sql": sql,
               "data": {
                   "table_update": {},
                   "pdb_table_update": {k:v,}
                   k:v,
               }
           }
        """
        assert data and isinstance(data["data"], dict) and cur
        assert data["sql"]

        mysql_update(cur,  data["database"], data["table"], data["data"]["table_update"],
                     {"bdp_status": BDP_STATUS["BUSINESS"]})
        filter_data = copy.deepcopy(data["data"]["pdb_table_update"])
        filter_data.pop("updated_time")
        filter_data.update({"table_status": TABLE_STATUS["BUSINESS"]})
        mysql_update(cur,  BDP_METADATA_DATABASE, BDP_TABLES["TABLES"], data["data"]["pdb_table_update"], filter_data)

    @staticmethod
    def execute_database_create(cur, data):
        """Execute database_create operation for bdp origin.

        :param cur: MySQL connection cursor,
        :param data: database_create data from Maxwell json packet
           data:
           {
               "database": database,
               "table": table,
               "sql": sql,
               "data": {
                   "schema_name": "",
                   "character_set": '',
                   k:v,
               }
           }
        """
        assert data and isinstance(data["data"], dict) and cur
        assert data["sql"]

        logger.info("Execute SQL:%s", data["sql"])
        cur.execute(data["sql"])
        mysql_insert(cur, BDP_METADATA_DATABASE, BDP_TABLES["DATABASE"], data["data"])